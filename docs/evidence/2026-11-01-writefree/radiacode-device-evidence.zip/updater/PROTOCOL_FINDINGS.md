# Firmware-update path — findings without performing an update

Evidence files: `official_packages.json` (APK/EXE inventory + strings actually found),
`firmware_md_update_path.md` (the repository’s reviewed description, sections 17-18),
`deployment_cli_*.json` (the offline CLI answers), `repo_unit_tests.txt`.

## Package for this exact hardware + firmware

| item | value |
| --- | --- |
| filename | `rc-102z.bin` |
| origin | `assets/HardSoft/rc-102z.bin` inside `official/apk.bin` (stored, uncompressed) |
| size | 130 148 B |
| SHA-256 | `67a43a50372622140ec5604f97d81be9042ae6291fa5f689f147db4f1ce5e392` |
| identical to repository container | yes, same size and SHA-256 |
| container magic | `Phyton\0\0`, header 52 B, header CRC `8573b5f0`, whole-file CRC `0x13095ABB` |
| header fields | `date_time 0x5AE7428A` (MS-DOS packed → 2025-07-07 08:20:20), `buffer_size 32768`, `version 4.14`, `compressed 1`, 8 blocks, `serial` field = 16 zero bytes |
| sibling assets in the same APK | `rc-101_v01.bin` (188 576), `rc-101_v01z.bin` (130 388), `rc-103z.bin` (130 132), `rc-103gz.bin` (130 444), `rc-110z.bin` (133 312), `rc-410z.bin` (140 836) |

The `exe.bin` (Windows app) contains no `Phyton\0\0` marker (`phyton_marker_count: 0`), i.e. the
containers are not embedded raw in the PE; the same six names appear in its printable strings.

## How the model image is selected

Observed strings: asset folder `HardSoft/` + per-model file names (`rc-102z.bin` etc.). The device’s
own descriptor (`RD_SIGNAT 0x0101`) reports the file name `rc-102.bin` and the product
`RadiaCode RC-102`, and `0x0012` reports `{size, buffer_size, date_time, crc32}` for the image the
device currently runs. The app compares those four values with the packaged asset
(`Firmware image signature match, CRC32 match` / `…, CRC32 mismatch, resetting`).
**Inference, not proof:** the per-model file name is the selection key; no version-compatibility
table was found in the strings, so downgrade behaviour is unknown.

## Integrity checks: what exists and what does not

* CRC-32/MPEG-2 (poly `0x04C11DB7`, tables at `0x0801F424`, `0x0802ACD8`, `0x0802D748`) over the whole
  file, plus per-block CRCs (`blocks.json`, all verified) — **evidenced**.
* Frame validation on four independent fields (`Error: S1..S4 Data frame corrupted!`, strings at
  `0x08037267`-`0x08037354`) — **evidenced**.
* The 4-byte exchange sign `0xFF12FF01` (`0x08027DA0`, `0x08028EEC`; the parser string is
  `Valid sign corrupted! Sgn = 0x%08X`) — **evidenced**, and it is a session marker, not a
  cryptographic signature.
* `FLASH_INVALID_SIGN` in the device’s flash-status enum names that same sign check. No public-key
  or HMAC verification is evidenced anywhere in the strings or the decompiled code. **Conclusion:
  integrity = CRC + the constant exchange sign; there is no separate authenticity signature.**

## Transport and framing

* BLE: NUS service `e63215e5-…b901`, write `…e6`, notify `…e7`; host writes are chopped into 18-byte
  GATT writes; frame = `u32 LE length | cmd u16 LE | 0x00 | seq | args`; `seq = 0x80 + (n mod 32)`.
* USB: vendor-specific interface (class FF/FF/FF), endpoint `0x01` OUT / `0x81` IN
  (`radiacode/transports/usb.py`), same frame bytes.
* Update ids: `0x0012 FW_IMAGE_GET_INFO`, `0x0013 FW_IMAGE_UPDATE` (staging session, sized by
  `buffer_size`), `0x0014 FW_IMAGE_WRITE` (`FW Image: Writing %d bytes at offset %d`; NAK becomes
  `FW_IMAGE_WRITE returned error #%d` with the numbered `FLASH_*` code). Progress is surfaced by
  `FWProgressUpdater::Update(%.1f)` / `EVT_FW_WRITE`. 130 148 / 4096 ≈ 32 chunks.

## Bootloader entry, address limits, and what the bootloader does

* All 8 blocks of the rc-102 container start at `0x08010000` or above; the same is true for the other
  five registered builds ⇒ the update path as shipped never writes `0x08000000`-`0x0800FFFF`, so the
  vendor bootloader survives an application update **as far as the container data shows**.
* Application entry requirements observed in the image: vector table at `0x08010000` with 98 entries,
  `InitialSP 0x20000800`, `Reset 0x0803BA71` (Thumb, so the entry point is `0x0803BA70`); the boot
  code jumps into that table.
* After the last chunk the device re-computes the CRCs and the app resets itself with
  `SCB->AIRCR = 0x05FA0004` (constant present at `0x08027DC4`); the BLE link drops and the app
  reconnects (`RECONNECTION_TIMED_OUT_DURING_UPDATE` if not).
* Not established from read-only evidence: whether the bootloader accepts a second image copy,
  whether activation is atomic, whether a partially written image is resumed or restarted, whether a
  lower version is accepted, and what happens if power is lost between chunks.

## Calibration/settings preservation

The two `RD_FLASH_AREA` records (indexes 0 and 1) have their own seed and XOR keystream and are only
written via the VS/VSFR ids, so they are independent of the code image. The `[DeviceParams]` /
`[DataStructure]` text, by contrast, is *compiled into* the application at `0x0802F9F0` — a different
application build can therefore report different configuration while the areas survive unchanged.
Whether the factory energy-calibration set lives in the areas, in the `DEVICE_INFO` record, or both,
is only partly resolved: the same `A0` appears in VS `0x202` and inside the 76-byte record at VS
`0x0F0`, and `RC_VSFR_DPOT_RDAC_EEPROM` (`0xC005`) in the VSFR map indicates a digital
potentiometer with an EEPROM-backed value.
