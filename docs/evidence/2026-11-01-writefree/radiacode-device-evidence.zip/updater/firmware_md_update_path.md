## 17. How a firmware update works

The protocol's own names come from the vendor SDK (`classes.dex` of the official APK, package
`ru.almacode.vk.corelib`): `SET_EXCHANGE`, `SET_BT_EXCHANGE_ID`, `SET_LOCAL_TIME`, `GET_STATUS`,
`GET_VERSION`, `GET_SERIAL`, `RD_FLASH_AREA`, `RD_HW_CONFIG`, `RD_SIGNAT`, `RD_VIRT_SFR`,
`RD_VIRT_SFR_BATCH`, `RD_VIRT_STRING`, `RD_VIRT_STRING_BATCH`, `FW_IMAGE_GET_INFO`, `FW_IMAGE_UPDATE`,
`FW_IMAGE_WRITE`, plus a flash status enum (`FLASH_OK`, `FLASH_PROG`, `FLASH_NOT_BLANK`, `FLASH_WR_PROT`,
`FLASH_RDP_ERROR`, `FLASH_INVALID_CRC`, `FLASH_INVALID_SIGN`, `FLASH_INVALID_TARGET`, `FLASH_INV_ADDR`,
`FLASH_REQUIRED`, `FLASH_VERIFY`, `FLASH_STATE`, …).

Three layers, only one of which is the "firmware":

| layer | content | replaced by an update? |
| --- | --- | --- |
| vendor bootloader | `0x08000000`-`0x0800FFFF` (64 KiB) | **no** — no block in any container starts below `0x08010000`, so the programmer itself survives |
| application image | `0x08010000`-`0x0803CA00`, i.e. `flash.bin` | **yes**, wholesale — it is a complete program (vectors, code, literal pools) with the config text compiled in |
| parameter areas | the two `RD_FLASH_AREA` records (0 and 1), XOR-obfuscated, seeded | no — separate, calibration/id-bearing, so per-unit data survives |

So: the *code* really is reflashed (a full image, not a data file), while the *device parameters* behave
like data: read via `0x081C`, written only through the VSFR/parameter commands.

### Step-by-step

1. **Open the session.** `SET_EXCHANGE` (`0x0007`) with the 4-byte sign `01 FF 12 FF`. The compiled-in
   copy of that constant is at `0x08027DA0` and `0x08028EEC` (word `0xFF12FF01`). Before it is accepted,
   most ids stay silent — verified: `0x0012` only answered after step 1. The sign is what the parser
   checks as `"Valid sign corrupted! Sgn = 0x%08X"`.
2. **Compare versions.** `FW_IMAGE_GET_INFO` (`0x0012`) returns `{u32 size, u32 buffer_size,
   u32 date_time, u32 crc32}` = `130148, 4096, 0x5AE7428A, 0x13095ABB`. The app holds the identical file
   as `assets/HardSoft/rc-102z.bin` inside the APK (130148 B — same length, so the app never needs the
   network during an update). Two decisions, straight from the app's strings:
   * `Firmware image signature match, CRC32 match` → nothing to do;
   * `Firmware image signature match, CRC32 mismatch, resetting` → start the transfer.
3. **Open the image session.** `FW_IMAGE_UPDATE` (one `0x0013`-style id in the same numeric block) —
   starts a staging session sized by `buffer_size` (4096).
4. **Stream the container.** Repeated `FW_IMAGE_WRITE`, each = offset + up-to-4096-byte chunk; the app
   logs `FW Image: Writing %d bytes at offset %d` per chunk, and any NAK becomes
   `FW_IMAGE_WRITE returned error #%d` where `#` is one of the `FLASH_*` codes above.
   130148 B / 4096 ≈ 32 chunks.
5. **Verify.** The device recomputes the whole-file CRC-32/MPEG-2 (poly `0x04C11DB7` is baked into the
   image at `0x0801F424`, `0x0802ACD8`, `0x0802D748`) and the per-block CRCs; mismatch is reported with
   `CRC Error: 0x%08X != 0x%08X` (`0x08027294`). Only a CRC-verified image is activated.
6. **Reboot into the new image.** The app issues the boot step (failure string `Failed to boot device`);
   on the device the reset is the standard `SCB->AIRCR = 0x05FA0004` (VECTKEY | SYSRESETREQ) — that
   constant pair sits in pools at `0x0801E330`, `0x08022724`, `0x08027DC0`. The BLE link drops, and the
   app reconnects; if it does not come back the app reports `RECONNECTION_TIMED_OUT_DURING_UPDATE`.
   The bootloader then re-validates and jumps to `0x08010001`; the app's own vector table at
   `0x08010000` is what makes that relocation work.

Progress is surfaced per chunk through `FWProgressUpdater` / `EVT_FW_WRITE`.

### Where the numbered ids come from

The device keeps a 91-entry table at `0x08035A64` of `{u32 id, u32 getter, u32 setter}` with ids
`0x00`-`0x5A` (getters `0x0801BB1F`+, setters `0x0801BD95`+) — that is the index space the
`RD_VIRT_SFR`/`RD_VIRT_STRING` batch commands use, and it is why the small wire ids (`0x0005`, `0x0007`,
`0x000A`, `0x000B`, `0x0012`, `0x0013`) answer at all. Larger ids (`0x0101`, `0x0807`, `0x081C`,
`0x0824`-`0x082B`, `0x0A04`) are handled by second-level switches, and per-item access ultimately goes
through the VSFR address chain in `sub_080275C4` (§7).



## 18. Integrity / anti-brick properties

| control | evidence |
| --- | --- |
| Every frame is length-prefixed and validated on 4 independent fields (packet size, command, sign, data frame) before anything is executed | `Error: S%d …` strings @ `0x08037267`-`0x08037354` |
| A session must be opened before state-changing ids take effect, so a stray packet cannot half-program the device | `SET_EXCHANGE` gating (observed), sign constant `0xFF12FF01` |
| Whole-image CRC-32/MPEG-2 **and** per-block CRCs must match before activation | `CRC Error: 0x%08X != 0x%08X`, poly in 3 places, `FLASH_INVALID_CRC` |
| The write path checks the flash controller's own error bits and reports them as numbered errors | `FLASH_PROG`, `FLASH_NOT_BLANK`, `FLASH_WR_PROT`, `FLASH_RDP_ERROR`, `FLASH_VERIFY` |
| The bootloader is outside every container, so it is never overwritten by an update | all 8 blocks start at `0x08010000` or higher |
| A failed/timed-out transfer leaves the previous image active: activation happens only after the CRC check, and reconnect failures are reported rather than assumed | `RECONNECTION_TIMED_OUT_DURING_UPDATE` |
| Parameter/calibration records are separate from the code image | the two `0x081C` areas keep their own seed + XOR stream |
| Only 13 ids accept anything at all (full `0x0000`-`0x0FFF` sweep) — a small, closed surface | `analysis/sweep_noarg.json`, `analysis/sweep_witharg.json` |

Practical consequences for this repo's read-only workflow: `0x0005`, `0x000A`, `0x000B`, `0x0012`,
`0x0013`, `0x0101`, `0x0807`, `0x081C`, `0x0824`-`0x082B` are pure reads; `0x0007` (sign) and `0x0A04`
(wall-clock) are the only idempotent writes that were exercised. Nothing else was needed to reproduce
`flash.bin` bit-for-bit (§1 identity table).


