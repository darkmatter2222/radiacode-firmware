"""Updater evidence from the official vendor packages held locally (no network needed).

  * official/apk.bin  = the vendor Android APK (ZIP), 10 440 075 B
  * official/exe.bin  = the vendor Windows app,            46 148 616 B

Collects: entry inventory, the packaged firmware container per model with its SHA-256 and
ZIP metadata, and the update-related strings actually present in the code (classes.dex for
the APK, printable-string scan for the PE). Nothing is inferred from the container alone.
"""

import hashlib
import io
import json
import os
import re
import zipfile

ROOT = r"C:\Users\ryans\source\repos\radiacode"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
UPD = os.path.join(OUT, "updater")
os.makedirs(UPD, exist_ok=True)
os.makedirs(os.path.join(UPD, "apk_assets"), exist_ok=True)

MARKS = [b"Firmware image signature", b"FW Image: Writing", b"FW_IMAGE_WRITE returned error",
         b"RECONNECTION_TIMED_OUT_DURING_UPDATE", b"FLASH_OK", b"FLASH_INVALID_CRC",
         b"FLASH_INVALID_SIGN", b"FLASH_INVALID_TARGET", b"FLASH_NOT_BLANK", b"FLASH_WR_PROT",
         b"FLASH_RDP_ERROR", b"FWProgressUpdater", b"EVT_FW_WRITE", b"rc-102z.bin",
         b"HardSoft", b"Phyton", b"SET_EXCHANGE", b"FW_IMAGE_UPDATE", b"FW_IMAGE_GET_INFO",
         b"FW_IMAGE_WRITE", b"SET_LOCAL_TIME", b"SET_BT_EXCHANGE_ID", b"GET_VERSION",
         b"CRC Error", b"Failed to boot device", b"Valid sign corrupted"]


def strings_of(blob, min_len=6):
    return re.findall(rb"[\x20-\x7e]{%d,}" % min_len, blob)


def main():
    apk = os.path.join(ROOT, "official", "apk.bin")
    exe = os.path.join(ROOT, "official", "exe.bin")
    result = {}

    # --- APK (ZIP) inventory + packaged firmware assets
    with zipfile.ZipFile(apk) as zf:
        infos = zf.infolist()
        result["apk"] = {"path": apk, "size": os.path.getsize(apk),
                         "entries": len(infos),
                         "sha256": hashlib.sha256(open(apk, "rb").read()).hexdigest()}
        fw_entries = []
        for i in infos:
            name = i.filename
            if re.search(r"(?i)\.(bin|json)$", name) or "HardSoft" in name:
                data = zf.read(i)
                rec = {"entry": name, "size": i.file_size, "compress_type": i.compress_type,
                       "date_time": list(i.date_time), "sha256": hashlib.sha256(data).hexdigest()}
                if data[:8] == b"Phyton\x00\x00":
                    rec["container_marker"] = "Phyton"
                    rec["first_words_hex"] = data[:32].hex()
                fw_entries.append(rec)
                if name.lower().endswith(".bin") and len(data) <= 400000:
                    with open(os.path.join(UPD, "apk_assets", os.path.basename(name)), "wb") as fh:
                        fh.write(data)
        result["apk"]["firmware_like_assets"] = fw_entries
        dex = None
        for cand in ("classes.dex",):
            if cand in zf.namelist():
                dex = zf.read(cand)
        if dex:
            result["apk"]["classes_dex"] = {"size": len(dex),
                                            "sha256": hashlib.sha256(dex).hexdigest()}
            found = {}
            for m in MARKS:
                pos = dex.find(m)
                if pos >= 0:
                    end = dex.find(b"\x00", pos)
                    found[m.decode()] = dex[pos:end if end > 0 else pos + 120][:200].decode(
                        "latin-1")
            result["apk"]["update_strings"] = found

    # --- Windows app: printable-string scan of the PE for the same markers
    blob = open(exe, "rb").read()
    result["exe"] = {"path": exe, "size": len(blob),
                     "sha256": hashlib.sha256(blob).hexdigest()}
    strs = strings_of(blob, 6)
    joined = b"\x00".join(strs)
    found = {}
    for m in MARKS:
        idx = [i for i, s in enumerate(strs) if s.startswith(m)][:6]
        if idx:
            found[m.decode()] = [strs[i].decode("latin-1") for i in idx]
    result["exe"]["update_strings"] = found
    # Phyton containers embedded in the PE
    offs, start = [], 0
    while True:
        p = blob.find(b"Phyton\x00\x00", start)
        if p < 0:
            break
        offs.append(p)
        start = p + 1
    result["exe"]["phyton_marker_offsets"] = offs[:20]
    result["exe"]["phyton_marker_count"] = len(offs)
    # container header fields for the first embedded container, if any
    if offs:
        result["exe"]["first_container_header_hex"] = blob[offs[0]:offs[0] + 52].hex()

    # --- cross-check against the repository's registered container for rc-102
    repo_container = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14", "rc-102z.bin")
    result["repo_container"] = {"path": "firmware/rc-102/hw1-fw4.14/rc-102z.bin",
                                "size": os.path.getsize(repo_container),
                                "sha256": hashlib.sha256(open(repo_container, "rb").read())
                                .hexdigest()}
    with open(os.path.join(UPD, "official_packages.json"), "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2)
    print(json.dumps({k: (v if not isinstance(v, dict) else
                          {kk: v[kk] for kk in list(v)[:8]}) for k, v in result.items()},
                     indent=2)[:3000])


main()
