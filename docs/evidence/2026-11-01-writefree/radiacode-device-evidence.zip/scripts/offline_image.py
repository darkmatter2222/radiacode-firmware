"""Offline evidence: image/container structure, address-coverage map, repo-artifact summary.

Reads only files that already exist in the repository checkout. Writes
    firmware/…  -> copied original bytes (see files section)
    memory-map.csv, decoded/image_structure.json, hardware/*.json
"""

import hashlib
import json
import os

ROOT = r"C:\Users\ryans\source\repos\radiacode"
TARGET = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14")
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def main():
    os.makedirs(os.path.join(OUT, "hardware"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "decoded"), exist_ok=True)

    # --- 1. structure of the padded application image (flash.bin)
    img = open(os.path.join(TARGET, "flash.bin"), "rb").read()
    base = 0x08000000
    runs = []
    # non-zero scan at 16-byte granularity (an all-zero 16-byte window inside data
    # splits a run; the scan describes the file, not the linker layout)
    s = None
    for k in range(0, len(img), 16):
        chunk = img[k:k + 16]
        nz = any(chunk)
        if nz and s is None:
            s = k
        if not nz and s is not None:
            runs.append((s, k))
            s = None
    if s is not None:
        runs.append((s, len(img)))

    vec = json.load(open(os.path.join(TARGET, "analysis", "vectors.json"), encoding="utf-8"))
    blocks = json.load(open(os.path.join(TARGET, "blocks.json"), encoding="utf-8"))

    # --- 2. vector-table facts (first 16 entries)
    import struct
    words = struct.unpack_from("<16I", img, 0x10000)

    structure = {
        "flash_bin": {
            "path_relative_to_repo": "firmware/rc-102/hw1-fw4.14/flash.bin",
            "size": len(img), "sha256": sha(os.path.join(TARGET, "flash.bin")),
            "load_base": hex(base),
            "leading_zero_padding_bytes": 0x10000,
            "nonzero_runs": [{"file_offset": "0x%05X" % a, "address": "0x%08X" % (base + a),
                              "length": b - a} for a, b in runs],
            "first_vector_words": [hex(w) for w in words],
            "initial_sp": hex(words[0]), "reset_vector": hex(words[1]),
        },
        "container": {
            "path_relative_to_repo": "firmware/rc-102/hw1-fw4.14/rc-102z.bin",
            "size": os.path.getsize(os.path.join(TARGET, "rc-102z.bin")),
            "sha256": sha(os.path.join(TARGET, "rc-102z.bin")),
            "header": blocks["header"], "whole_file_crc": blocks["whole_file_crc"],
            "blocks": blocks["blocks"],
        },
        "coverage_note": ("block addresses cover 0x08010000..0x0803CA00; 0x08000000-0x0800FFFF "
                          "is zero padding in flash.bin and is NOT an acquired bootloader"),
    }
    with open(os.path.join(OUT, "decoded", "image_structure.json"), "w", encoding="utf-8") as fh:
        json.dump(structure, fh, indent=2)

    # --- 3. address coverage map
    rows = ["region,start,length_bytes,acquisition_status,evidence"]
    rows.append("bootloader_gap,0x08000000,65536,NOT ACQUIRED,"
                "zero-filled in flash.bin; no supported read-only memory-read command exists")
    for b in blocks["blocks"]:
        rows.append("application_block_%d,%s,%d,ACQUIRED_FROM_VENDOR_CONTAINER,"
                    "rc-102z.bin block %d, per-block CRC %s verified"
                    % (b["index"], b["addr"], b["plain_size"], b["index"], b["crc"]))
    end = 0x0803CA00
    rows.append("application_tail_padding,%s,%d,ZERO_IN_CONTAINER (state unknown),"
                "image ends here; physical content beyond it is not reported by any command"
                % (hex(end), 0x08040000 - end))
    rows.append("sram,0x20000000,unknown,NOT ACQUIRED,InitialSP 0x20000800 from the vector table")
    rows.append("option_bytes,0x1FFF7800,unknown,NOT ACQUIRED,no read-only id exposes them")
    rows.append("flash_areas_via_0x081C,see decoded/flash_areas,indexed,ACQUIRED (XOR-obfuscated),"
                "RD_FLASH_AREA indexes 0 and 1 answer, 2 and 3 return status 12")
    with open(os.path.join(OUT, "memory-map.csv"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(rows) + "\n")

    # --- 4. repo-artifact summary for the report
    keys = ["stats", "verification", "container_check", "roundtrip", "crosscheck",
            "differential", "formal", "confidence", "tables", "vectors", "capture"]
    summary = {}
    for k in keys:
        p = os.path.join(TARGET, "analysis", k + ".json")
        d = json.load(open(p, encoding="utf-8"))
        if k == "stats":
            summary[k] = {x: d[x] for x in d if not isinstance(d[x], (dict, list))}
        elif k == "verification":
            summary[k] = d["checks"]
        elif k == "container_check":
            summary[k] = d
        elif k == "roundtrip":
            summary[k] = {x: d[x] for x in ("byte_exact",) if x in d}
            summary[k].update({kk: d.get(kk) for kk in ("carried", "lzss")})
        elif k == "crosscheck":
            summary[k] = {"tiers": d.get("tiers"), "agreement": d.get("agreement")}
        elif k == "differential":
            cs = d.get("cases", [])
            summary[k] = {"cases": len(cs),
                          "r0_match": sum(1 for c in cs if c.get("r0_match")),
                          "write_bytes_match": sum(1 for c in cs if c.get("write_bytes_match")),
                          "names": [c.get("name") for c in cs]}
        elif k == "formal":
            summary[k] = {x: d.get(x) for x in ("proved", "counterexamples", "unknown")}
        elif k == "confidence":
            summary[k] = {"categories": d.get("categories"), "unresolved": d.get("unresolved")}
        elif k == "tables":
            summary[k] = {"tables": [{"address": t["address"], "entries": len(t["entries"])}
                                     for t in d["tables"]]}
        elif k == "vectors":
            summary[k] = {"count": len(d) if isinstance(d, list) else len(d.get("vectors", []))}
        elif k == "capture":
            summary[k] = {"taken": d.get("taken"), "address": d.get("address"),
                          "identity_keys": sorted(d.get("identity", {})),
                          "virtual_strings": sorted(d.get("virtual_strings", {})),
                          "flash_areas": sorted(d.get("flash_areas", {}))}
    with open(os.path.join(OUT, "hardware", "repo_artifact_summary.json"), "w",
              encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    print(json.dumps(summary, indent=2)[:4000])


main()
