import json
import re

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()
BASE = 0x08000000


def word(off):
    return int.from_bytes(img[off:off + 4], "little")


def find_word(val, lo=0x10000):
    hits = []
    for off in range(lo, len(img) - 3, 4):
        if word(off) == val:
            hits.append((BASE + off, word(off - 4), word(off + 4)))
    return hits


print("== id->handler pairs containing handler 0x08027490 (word) ==")
for a, prev, nxt in find_word(0x08027490):
    print("  word@0x%08X  prev=0x%08X next=0x%08X" % (a, prev & 0xFFFFFFFF, nxt & 0xFFFFFFFF))
print("== pairs containing 0x08027518 ==")
for a, prev, nxt in find_word(0x08027518):
    print("  word@0x%08X  prev=0x%08X next=0x%08X" % (a, prev, nxt))

print("== magic literal ==")
for a, prev, nxt in find_word(0xFF12FF01):
    print("  0xFF12FF01 at 0x%08X (prev 0x%08X next 0x%08X)" % (a, prev, nxt))

print("== dispatch region 0x08037838..0x080378D0 as {id,handler} pairs ==")
start = 0x08037838 - BASE
for i in range(start, start + 0x98, 8):
    a = BASE + i
    print("  [%d] id=0x%04X handler=0x%08X" % ((i - start) // 8, word(i), word(i + 4)))

print("== listing rows covering the handler bytes ==")
lines = open(T + r"\listing.s", encoding="utf-8", errors="replace").read().split("\n")
pat = re.compile(r"^([0-9A-Fa-f]{8})\s\s(.*)$")
for l in lines:
    m = pat.match(l)
    if not m:
        continue
    v = int(m.group(1), 16)
    if 0x08027490 <= v <= 0x080274B8 or v in (0x08027504, 0x0802750C, 0x08029086, 0x08029360,
                                              0x08029370, 0x08022E60, 0x08016780):
        print(" ", l[:120])
