"""Write-free collection, single-connection variant (mirrors pipeline/rcsession.py).

Difference from collect_writefree2.py: one GATT connection for the whole sequence with one
persistent notification buffer, and a frame whose 4-byte header echoes the request is
accepted whenever it appears inside the window (the device interleaves its `06 00 00 xx`
frames with real answers, so a per-connection buffer that survives the previous command is
what makes the answers match). No write id is issued.
"""

import asyncio
import datetime
import hashlib
import json
import os
import struct
import sys

from bleak import BleakClient

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from protocol import (CMD, VS, decode_calib, decode_flash_area, decode_image_info,  # noqa: E402
                      decode_signature, decode_versions, serial_from_address, split)

ROOT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
RAW = os.path.join(ROOT, "raw")
WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = r"e63215e7-7003-49d8-96b0-b024798fb901"
SERVICE_UUID = "e63215e5-7003-49d8-96b0-b024798fb901"
ADDRESS = "52:43:06:60:20:24"
PATH = os.path.join(RAW, "session_single_connection.json")

VS_IDS = [0x002, 0x003, 0x008, 0x00D, 0x00F, 0x0F0, 0x100, 0x101, 0x200, 0x202,
          0x203, 0x205, 0x206, 0x207, 0x208, 0x220]
VSFRS = [("DEVICE_CTRL", 0x0500), ("DEVICE_LANG", 0x0502), ("DEVICE_ON", 0x0503),
         ("DEVICE_TIME", 0x0504), ("BLE_TX_PWR", 0x0700), ("DISP_CTRL", 0x0510),
         ("DISP_BRT", 0x0511), ("DISP_CONTR", 0x0512), ("DISP_OFF_TIME", 0x0513),
         ("SOUND_VOL", 0x0521), ("VIBRO_ON", 0x0531), ("MS_RUN", 0x0603),
         ("CPS", 0x8020), ("DR_uR_h", 0x8021), ("DS_uR", 0x8022), ("TEMP_degC", 0x8024),
         ("ACC_X", 0x8025), ("CHARGER_STATE", 0xC200), ("VBIAS_mV", 0xC000),
         ("COMP_LEV", 0xC001), ("CALIB_MODE", 0xC002),
         ("MCU_ID0", 0xFFFF0000), ("MCU_ID1", 0xFFFF0001), ("MCU_ID2", 0xFFFF0002),
         ("DEVICE_ID", 0xFFFF0005), ("SIGNATURE", 0xFFFF0006), ("RX_SIZE", 0xFFFF0007),
         ("TX_SIZE", 0xFFFF0008), ("BOOT_VERSION", 0xFFFF0009),
         ("TARGET_VERSION", 0xFFFF000A), ("STATUS", 0xFFFF000B), ("MCU_VREF", 0xFFFF000C),
         ("MCU_TEMP", 0xFFFF000D)]

STATE = {"buf": b"", "seq": 0}
EX = []


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="milliseconds")


def sha(b):
    return hashlib.sha256(b).hexdigest() if b else None


def on_notify(handle, data):
    STATE["buf"] += bytes(data)


def decoded_for(cmd, data):
    try:
        if cmd == 0x000A:
            return decode_versions(data)
        if cmd == 0x0012:
            return decode_image_info(data)
        if cmd == 0x0101:
            return decode_signature(data)
        if cmd == 0x081C:
            return decode_flash_area(data)
        if cmd == 0x0824 and len(data) >= 8:
            return {"u32": struct.unpack_from("<I", data, 4)[0],
                    "f32": struct.unpack_from("<f", data, 4)[0]}
        if cmd == 0x0824 and len(data) == 4:
            return {"u32": struct.unpack("<I", data)[0], "f32": struct.unpack("<f", data)[0]}
    except Exception as exc:  # noqa: BLE001
        return {"decode_error": repr(exc)}
    return None


async def xfer(client, cmd, args=b"", window=3.0, label="", note=""):
    seq = 0x80 + (STATE["seq"] % 32)
    STATE["seq"] += 1
    request = struct.pack("<HBB", cmd, 0, seq) + bytes(args)
    full = struct.pack("<I", len(request)) + request
    t0 = now()
    for pos in range(0, len(full), 18):
        await client.write_gatt_char(WRITE_UUID, full[pos:pos + 18])
    loop = asyncio.get_running_loop()
    deadline = loop.time() + window
    frames, matched = [], None
    while loop.time() < deadline:
        buf = STATE["buf"]
        while len(buf) >= 4:
            total = 4 + struct.unpack_from("<I", buf)[0]
            if len(buf) < total:
                break
            frames.append(buf[:total].hex())
            buf = buf[total:]
        STATE["buf"] = buf
        for f in frames:
            payload = bytes.fromhex(f)[4:]
            if len(payload) >= 4 and payload[:4] == request[:4]:
                matched = payload[4:]
                break
        if matched is not None:
            break
        await asyncio.sleep(0.005)
    t1 = now()
    rec = {"t_request": t0, "t_response": t1, "transport": "bluetooth-le/gatt",
           "address": ADDRESS, "service": SERVICE_UUID, "write_char": WRITE_UUID,
           "notify_char": NOTIFY_UUID, "cmd_id": "0x%04X" % cmd,
           "cmd_name": CMD.get(cmd, "?"), "seq": "0x%02X" % seq,
           "args_hex": bytes(args).hex(), "request_wire_hex": full.hex(),
           "frames_hex": frames, "header_echo_ok": matched is not None,
           "payload_hex": matched.hex() if matched is not None else None,
           "payload_len": len(matched) if matched is not None else 0,
           "payload_sha256": sha(matched), "label": label, "note": note,
           "decoded": decoded_for(cmd, matched) if matched else None}
    EX.append(rec)
    return rec


async def main():
    baseline_seconds = int(sys.argv[sys.argv.index("--baseline") + 1]) \
        if "--baseline" in sys.argv else 60
    os.makedirs(RAW, exist_ok=True)
    strings, areas, vsfrs, stability = {}, {}, {}, []
    box = {}

    def flush():
        box.update({"collected": now(), "address": ADDRESS,
                    "ble_name_from_address": serial_from_address(ADDRESS),
                    "writes_issued": [], "virtual_strings": strings, "flash_areas": areas,
                    "vsfr": vsfrs, "repeat_stability": stability,
                    "baseline": box.get("baseline"), "exchanges": EX})
        with open(PATH, "w", encoding="utf-8") as fh:
            json.dump(box, fh, indent=2, ensure_ascii=False)

    client = BleakClient(ADDRESS, timeout=15.0)
    await client.connect()
    await client.start_notify(NOTIFY_UUID, on_notify)
    try:
        for cid in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
            await xfer(client, cid, label=CMD[cid])
        flush()
        for vs in VS_IDS:
            rec = await xfer(client, 0x0826, struct.pack("<I", vs), label="VS_%03X" % vs,
                             note="VS 0x%03X %s" % (vs, VS.get(vs, "?")))
            if rec["payload_hex"]:
                _, size, body = split(bytes.fromhex(rec["payload_hex"]))
                entry = {"vs": "0x%03X" % vs, "name": VS.get(vs, "?"), "declared_size": size,
                         "body_bytes": len(body), "body_hex": body.hex(),
                         "body_sha256": sha(body)}
                if VS.get(vs) in ("CONFIGURATION", "SERIAL_NUMBER", "EVENT_LOG"):
                    entry["text"] = body.split(b"\x00")[0].decode("cp1251", "replace")
                if vs == 0x202:
                    entry["calib"] = decode_calib(body)
                strings[entry["vs"]] = entry
            flush()
        for area in range(4):
            rec = await xfer(client, 0x081C, struct.pack("<I", area), label="area%d" % area)
            areas[str(area)] = {"payload_hex": rec["payload_hex"], "decoded": rec["decoded"]}
            flush()
        for label, addr in VSFRS:
            rec = await xfer(client, 0x0824, struct.pack("<I", addr), label="VSFR_" + label,
                             note="VSFR 0x%08X" % addr, window=1.5)
            if rec["decoded"]:
                vsfrs[label] = {"addr": "0x%08X" % addr, "payload_hex": rec["payload_hex"],
                                **rec["decoded"]}
            flush()
        for i in range(2):
            snap = {}
            for cid in (0x0005, 0x000A, 0x0012, 0x0101, 0x0807):
                snap[CMD[cid]] = (await xfer(client, cid, label="repeat%d %s" % (i, CMD[cid])))["payload_sha256"]
            for vs in (0x002, 0x008, 0x202, 0x0F0):
                snap["VS_%03X" % vs] = (await xfer(client, 0x0826, struct.pack("<I", vs),
                                                   label="repeat%d VS_%03X" % (i, vs)))["payload_sha256"]
            stability.append(snap)
            flush()
        samples, k = [], 0
        t0 = asyncio.get_running_loop().time()
        while asyncio.get_running_loop().time() - t0 < baseline_seconds:
            s = {"sample": k, "t": now(),
                 "elapsed_s": round(asyncio.get_running_loop().time() - t0, 3)}
            s["GET_STATUS"] = (await xfer(client, 0x0005, label="baseline%d status" % k))["payload_hex"]
            for label, addr in (("CPS", 0x8020), ("DR", 0x8021), ("DS", 0x8022),
                                ("TEMP", 0x8024), ("CHARGER", 0xC200), ("DEV_TIME", 0x0504),
                                ("MS_RUN", 0x0603)):
                r = await xfer(client, 0x0824, struct.pack("<I", addr), window=1.5,
                               label="baseline%d %s" % (k, label))
                s[label] = r["decoded"] or r["payload_hex"]
            for vs, key in ((0x220, "LIVE_WINDOW"), (0x200, "SPECTRUM"), (0x100, "DATA_BUF")):
                r = await xfer(client, 0x0826, struct.pack("<I", vs),
                               label="baseline%d %s" % (k, key))
                if r["payload_hex"]:
                    _, size, body = split(bytes.fromhex(r["payload_hex"]))
                    s[key] = {"declared_size": size, "hex": body.hex(), "sha256": sha(body)}
                    if vs == 0x220 and len(body) >= 12:
                        s[key]["counts_ms_us"] = list(struct.unpack_from("<III", body, 0))
            samples.append(s)
            box["baseline"] = {"seconds": baseline_seconds, "samples": samples}
            flush()
            k += 1
    finally:
        try:
            await client.disconnect()
        except Exception:  # noqa: BLE001
            pass
    print(json.dumps({"exchanges": len(EX),
                      "answered": sum(1 for e in EX if e["header_echo_ok"]),
                      "vs": len(strings), "vsfr": len(vsfrs),
                      "baseline_samples": len((box.get('baseline') or {}).get('samples', []))}))


asyncio.run(main())
