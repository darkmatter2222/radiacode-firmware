"""Write-free evidence collection from the connected RadiaCode unit over BLE.

Observed transport behaviour (probed, see raw/probe_*): the unit answers exactly one
command per BLE connection while no exchange session has been opened, so this script
opens one connection per command. No write id is issued at any point: 0x0007
(SET_EXCHANGE), 0x0A04 (SET_LOCAL_TIME), 0x0825/0x0827/0x082B (the WR_* ids) and 0x0013
(firmware-update staging) are all deliberately excluded.

    python collect_writefree.py            # identity + state + areas + VSFRs + repeats
    python collect_writefree.py --baseline 60
"""

import asyncio
import datetime
import hashlib
import json
import os
import struct
import sys

from bleak import BleakClient

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from protocol import (CMD, VS, decode_calib, decode_flash_area, decode_image_info,  # noqa: E402
                      decode_signature, decode_versions, serial_from_address, split)

ROOT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
RAW = os.path.join(ROOT, "raw")
DEC = os.path.join(ROOT, "decoded")
WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = "e63215e7-7003-49d8-96b0-b024798fb901"
SERVICE_UUID = "e63215e5-7003-49d8-96b0-b024798fb901"
ADDRESS = "52:43:06:60:20:24"

VS_IDS = [0x002, 0x003, 0x008, 0x00D, 0x00F, 0x0F0, 0x100, 0x101, 0x200, 0x202,
          0x203, 0x205, 0x206, 0x207, 0x208, 0x220]
VSFRS = [
    ("VSFR_DEVICE_CTRL", 0x00000500), ("VSFR_DEVICE_LANG", 0x00000502),
    ("VSFR_DEVICE_ON", 0x00000503), ("VSFR_DEVICE_TIME", 0x00000504),
    ("VSFR_BLE_TX_PWR", 0x00000700), ("VSFR_DISP_CTRL", 0x00000510),
    ("VSFR_DISP_BRT", 0x00000511), ("VSFR_DISP_CONTR", 0x00000512),
    ("VSFR_DISP_OFF_TIME", 0x00000513), ("VSFR_DISP_ON", 0x00000514),
    ("VSFR_DISP_DIR", 0x00000515), ("VSFR_DISP_BACKLT_ON", 0x00000516),
    ("VSFR_SOUND_CTRL", 0x00000520), ("VSFR_SOUND_VOL", 0x00000521),
    ("VSFR_SOUND_ON", 0x00000522), ("VSFR_VIBRO_CTRL", 0x00000530),
    ("VSFR_VIBRO_ON", 0x00000531), ("VSFR_ALARM_MODE", 0x000005E0),
    ("VSFR_MS_RUN", 0x00000603), ("VSFR_CHARGER_STATE", 0x0000C200),
    ("RC_VSFR_DR_LEV1_uR_h", 0x00008000), ("RC_VSFR_DR_LEV2_uR_h", 0x00008001),
    ("RC_VSFR_DS_LEV1_100uR", 0x00008002), ("RC_VSFR_DS_LEV2_100uR", 0x00008003),
    ("RC_VSFR_DS_UNITS", 0x00008004), ("RC_VSFR_CPS_FILTER", 0x00008005),
    ("RC_VSFR_DOSE_RESET", 0x00008007), ("RC_VSFR_CR_LEV1_cp10s", 0x00008008),
    ("RC_VSFR_CR_LEV2_cp10s", 0x00008009), ("RC_VSFR_USE_nSv_h", 0x0000800C),
    ("RC_VSFR_CHN_TO_keV_A0", 0x00008010), ("RC_VSFR_CHN_TO_keV_A1", 0x00008011),
    ("RC_VSFR_CHN_TO_keV_A2", 0x00008012), ("RC_VSFR_CR_UNITS", 0x00008013),
    ("RC_VSFR_DS_LEV1_uR", 0x00008014), ("RC_VSFR_DS_LEV2_uR", 0x00008015),
    ("RC_VSFR_TEMP_UNITS", 0x00008016),
    ("RC_VSFR_CPS", 0x00008020), ("RC_VSFR_DR_uR_h", 0x00008021),
    ("RC_VSFR_DS_uR", 0x00008022), ("RC_VSFR_TEMP_degC", 0x00008024),
    ("RC_VSFR_ACC_X", 0x00008025), ("RC_VSFR_ACC_Y", 0x00008026),
    ("RC_VSFR_ACC_Z", 0x00008027), ("RC_VSFR_OPT", 0x00008028),
    ("RC_VSFR_RAW_TEMP_degC", 0x00008033), ("RC_VSFR_TEMP_UP_degC", 0x00008034),
    ("RC_VSFR_TEMP_DN_degC", 0x00008035),
    ("RC_VSFR_VBIAS_mV", 0x0000C000), ("RC_VSFR_COMP_LEV", 0x0000C001),
    ("RC_VSFR_CALIB_MODE", 0x0000C002), ("RC_VSFR_DPOT_RDAC", 0x0000C004),
    ("RC_VSFR_DPOT_RDAC_EEPROM", 0x0000C005), ("RC_VSFR_DPOT_TOLER", 0x0000C006),
    ("VSFR_SYS_MCU_ID0", 0xFFFF0000), ("VSFR_SYS_MCU_ID1", 0xFFFF0001),
    ("VSFR_SYS_MCU_ID2", 0xFFFF0002), ("VSFR_SYS_DEVICE_ID", 0xFFFF0005),
    ("VSFR_SYS_SIGNATURE", 0xFFFF0006), ("VSFR_SYS_RX_SIZE", 0xFFFF0007),
    ("VSFR_SYS_TX_SIZE", 0xFFFF0008), ("VSFR_SYS_BOOT_VERSION", 0xFFFF0009),
    ("VSFR_SYS_TARGET_VERSION", 0xFFFF000A), ("VSFR_SYS_STATUS", 0xFFFF000B),
    ("VSFR_SYS_MCU_VREF", 0xFFFF000C), ("VSFR_SYS_MCU_TEMP", 0xFFFF000D),
]


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="milliseconds")


def sha(b):
    return hashlib.sha256(b).hexdigest() if b else None


async def read_one(cmd, args=b"", timeout=0.9, attempts=2):
    """One connection, one command, every received frame logged. No writes issued.

    Windows caches GATT services per device, and a reconnect that arrives before the
    stack has re-published the characteristics raises BleakCharacteristicNotFoundError;
    the small retry loop is what pipeline/rcsession.py does for the same reason.
    """
    base = {"t_request": None, "t_response": None, "transport": "bluetooth-le/gatt",
            "address": ADDRESS, "service": SERVICE_UUID, "write_char": WRITE_UUID,
            "notify_char": NOTIFY_UUID, "cmd_id": "0x%04X" % int(cmd),
            "cmd_name": CMD.get(int(cmd), "?"), "args_hex": bytes(args).hex(),
            "request_wire_hex": None, "frames_hex": [], "header_echo_ok": False,
            "payload_hex": None, "payload_len": 0, "payload_sha256": None}
    rec = base
    for try_no in range(attempts):
        try:
            rec = await _read_once(cmd, args, timeout)
        except Exception as exc:  # noqa: BLE001
            rec = dict(base)
            rec["error"] = repr(exc)
            rec["attempt"] = try_no
        if rec.get("header_echo_ok"):
            return rec
        if try_no != attempts - 1:
            await asyncio.sleep(0.2)
    rec["attempts"] = attempts
    return rec


async def _read_once(cmd, args=b"", timeout=0.9):
    state = {"buf": b""}

    def on_notify(handle, data):
        state["buf"] += bytes(data)

    client = BleakClient(ADDRESS, timeout=10.0)
    t0 = now()
    await client.connect()
    await client.start_notify(NOTIFY_UUID, on_notify)
    request = struct.pack("<HBB", int(cmd), 0, 0x80) + bytes(args)
    full = struct.pack("<I", len(request)) + request
    for pos in range(0, len(full), 18):
        await client.write_gatt_char(WRITE_UUID, full[pos:pos + 18])
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    frames = []
    matched = None
    while loop.time() < deadline:
        buf = state["buf"]
        while len(buf) >= 4:
            total = 4 + struct.unpack_from("<I", buf)[0]
            if len(buf) < total:
                break
            frames.append(buf[:total].hex())
            buf = buf[total:]
        state["buf"] = buf
        for f in frames:  # the matching frame may follow an interleaved one
            payload = bytes.fromhex(f)[4:]
            if len(payload) >= 4 and payload[:4] == request[:4]:
                matched = payload[4:]
                break
        if matched is not None:
            break
        await asyncio.sleep(0.005)
    t1 = now()
    try:
        await client.disconnect()
    except Exception:  # noqa: BLE001
        pass
    answered = matched
    return {"t_request": t0, "t_response": t1, "transport": "bluetooth-le/gatt",
            "address": ADDRESS, "service": SERVICE_UUID, "write_char": WRITE_UUID,
            "notify_char": NOTIFY_UUID, "cmd_id": "0x%04X" % int(cmd),
            "cmd_name": CMD.get(int(cmd), "?"), "args_hex": bytes(args).hex(),
            "request_wire_hex": full.hex(), "frames_hex": frames,
            "header_echo_ok": answered is not None,
            "payload_hex": answered.hex() if answered is not None else None,
            "payload_len": len(answered) if answered is not None else 0,
            "payload_sha256": sha(answered)}


def decode(cmd, payload_hex):
    if payload_hex is None:
        return None
    data = bytes.fromhex(payload_hex)
    try:
        if cmd == 0x000A:
            return decode_versions(data)
        if cmd == 0x0012:
            return decode_image_info(data)
        if cmd == 0x0101:
            return decode_signature(data)
        if cmd == 0x081C:
            return decode_flash_area(data)
        if cmd == 0x0824 and len(data) in (4, 8):
            off = len(data) - 4
            return {"u32": struct.unpack_from("<I", data, off)[0],
                    "f32": struct.unpack_from("<f", data, off)[0]}
    except Exception as exc:  # noqa: BLE001
        return {"decode_error": repr(exc)}
    return None


def parse_data_buf(body):
    """Best-effort decode of VS 0x100 per firmware.md SS20 (45 B / 21 B alternating)."""
    out, pos, kind, n = [], 0, (45, 21), 0
    while pos + kind[n % 2] <= len(body):
        ln = kind[n % 2]
        rec = body[pos:pos + ln]
        item = {"index": n, "stride": ln, "seq": rec[0], "groupId": rec[1],
                "channelId": rec[2], "tag": rec[3],
                "tick": int.from_bytes(rec[4:7], "little"), "hex": rec.hex()}
        if ln == 45:
            item["pairs"] = [
                {"raw": struct.unpack_from("<I", rec, 13)[0],
                 "f32": struct.unpack_from("<f", rec, 17)[0],
                 "ripple": struct.unpack_from("<f", rec, 21)[0],
                 "stamp": struct.unpack_from("<I", rec, 25)[0]},
                {"raw": struct.unpack_from("<I", rec, 29)[0],
                 "f32": struct.unpack_from("<f", rec, 33)[0],
                 "ripple": struct.unpack_from("<f", rec, 37)[0],
                 "stamp": struct.unpack_from("<I", rec, 41)[0]}]
        else:
            item["window_word"] = struct.unpack_from("<I", rec, 7)[0]
            item["f32"] = struct.unpack_from("<f", rec, 11)[0]
            item["flags"] = rec[15]
            item["tail"] = rec[16:21].hex()
        out.append(item)
        pos += ln
        n += 1
    return {"grammar": "firmware.md SS20 (45B A-record / 21B B-record alternating)",
            "records": out, "unparsed_tail": len(body) - pos}


async def main():
    os.makedirs(RAW, exist_ok=True)
    os.makedirs(DEC, exist_ok=True)
    baseline_seconds = 0
    if "--baseline" in sys.argv:
        baseline_seconds = int(sys.argv[sys.argv.index("--baseline") + 1])
    ex = []
    path = os.path.join(RAW, "session_reads_writefree.json")
    state_box = {}

    def flush():
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(state_box, fh, indent=2, ensure_ascii=False)

    async def go(label, cmd, args=b"", note=""):
        rec = await read_one(cmd, args)
        rec["label"] = label
        rec["decoded"] = decode(cmd, rec["payload_hex"])
        if note:
            rec["note"] = note
        ex.append(rec)
        return rec

    strings, areas, vsfrs, stability, baseline = {}, {}, {}, [], None

    def snapshot():
        state_box.update({
            "collected": now(), "address": ADDRESS,
            "ble_name_from_address": serial_from_address(ADDRESS),
            "writes_issued": [], "one_answered_command_per_connection": True,
            "identity": {e["cmd_name"]: e for e in ex if e["cmd_id"] in
                         ("0x0005", "0x000A", "0x000B", "0x0012", "0x0101", "0x0807")},
            "virtual_strings": strings, "flash_areas": areas, "vsfr": vsfrs,
            "repeat_stability": stability, "baseline": baseline, "exchanges": ex})

    # 1. identity (documented read-only ids only; 0x0013 excluded by instruction)
    for cid in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
        await go(CMD[cid], cid)
    snapshot()
    flush()

    # 2. virtual strings
    for vs in VS_IDS:
        rec = await go("VS_%03X" % vs, 0x0826, struct.pack("<I", vs),
                       note="VS 0x%03X %s" % (vs, VS.get(vs, "?")))
        if rec["payload_hex"]:
            _, size, body = split(bytes.fromhex(rec["payload_hex"]))
            entry = {"vs": "0x%03X" % vs, "name": VS.get(vs, "?"), "version": None,
                     "declared_size": size, "body_bytes": len(body),
                     "body_hex": body.hex(), "body_sha256": sha(body)}
            if VS.get(vs) in ("CONFIGURATION", "SERIAL_NUMBER", "EVENT_LOG"):
                entry["text"] = body.split(b"\x00")[0].decode("cp1251", "replace")
            if vs == 0x100:
                entry["parsed"] = parse_data_buf(body)
            if vs == 0x202:
                entry["calib"] = decode_calib(body)
            strings[entry["vs"]] = entry

    # 3. parameter areas
    snapshot()
    flush()
    for area in range(4):
        rec = await go("area%d" % area, 0x081C, struct.pack("<I", area),
                       note="RD_FLASH_AREA index %d" % area)
        areas[str(area)] = {"payload_hex": rec["payload_hex"], "decoded": rec["decoded"]}

    # 4. VSFR single reads
    snapshot()
    flush()
    for label, addr in VSFRS:
        rec = await go(label, 0x0824, struct.pack("<I", addr),
                       note="VSFR 0x%08X" % addr)
        if rec["decoded"]:
            vsfrs[label] = {"addr": "0x%08X" % addr, "payload_hex": rec["payload_hex"],
                            **rec["decoded"]}

    # 5. stability: the same stable regions three times
    stability = []
    for i in range(3):
        snap = {}
        for cid in (0x0005, 0x000A, 0x0012, 0x0101, 0x0807):
            snap[CMD[cid]] = (await go("repeat%d %s" % (i, CMD[cid]), cid))["payload_sha256"]
        for vs in (0x002, 0x008, 0x202, 0x0F0):
            snap["VS_%03X" % vs] = (await go("repeat%d VS_%03X" % (i, vs), 0x0826,
                                             struct.pack("<I", vs)))["payload_sha256"]
        for area in (0, 1):
            snap["area%d" % area] = (await go("repeat%d area%d" % (i, area), 0x081C,
                                              struct.pack("<I", area)))["payload_sha256"]
        stability.append(snap)

    # 6. baseline of already-available outputs, one connection per read
    if baseline_seconds:
        samples, k = [], 0
        t0 = asyncio.get_running_loop().time()
        while asyncio.get_running_loop().time() - t0 < baseline_seconds:
            s = {"t": now(), "elapsed_s": round(asyncio.get_running_loop().time() - t0, 3),
                 "sample": k}
            r = await go("baseline%d status" % k, 0x0005)
            s["GET_STATUS"] = r["payload_hex"]
            for label, addr in (("CPS_0x8020", 0x8020), ("DR_uR_h_0x8021", 0x8021),
                                ("DS_uR_0x8022", 0x8022), ("TEMP_degC_0x8024", 0x8024),
                                ("CHARGER_0xC200", 0xC200), ("DEVICE_TIME_0x0504", 0x0504),
                                ("MS_RUN_0x0603", 0x0603)):
                r = await go("baseline%d %s" % (k, label), 0x0824, struct.pack("<I", addr))
                s[label] = r["decoded"] or r["payload_hex"]
            for vs, key in ((0x220, "LIVE_WINDOW_0x220"), (0x200, "SPECTRUM_0x200"),
                            (0x202, "ENERGY_CALIB_0x202"), (0x100, "DATA_BUF_0x100")):
                r = await go("baseline%d %s" % (k, key), 0x0826, struct.pack("<I", vs))
                if r["payload_hex"]:
                    _, size, body = split(bytes.fromhex(r["payload_hex"]))
                    s[key] = {"declared_size": size, "hex": body.hex(), "sha256": sha(body)}
                    if vs == 0x202:
                        s[key]["calib"] = decode_calib(body)
                    if vs == 0x220 and len(body) >= 12:
                        s[key]["decoded"] = dict(zip(("counts", "ms", "us"),
                                                     struct.unpack_from("<III", body, 0)))
            samples.append(s)
            baseline = {"seconds": baseline_seconds, "interval_target_s": 2.0,
                        "samples": samples}
            snapshot()
            flush()
            k += 1

    snapshot()
    flush()
    out = state_box

    # decoded artifacts
    cfg = strings.get("0x002", {})
    if cfg.get("text"):
        with open(os.path.join(DEC, "configuration_text.txt"), "w", encoding="utf-8") as fh:
            fh.write(cfg["text"])
    cal = strings.get("0x202")
    if cal:
        with open(os.path.join(DEC, "energy_calibration.json"), "w", encoding="utf-8") as fh:
            json.dump({"source": "RD_VIRT_STRING 0x0826 VS 0x202, write-free pass",
                       "collected": out["collected"], "raw_hex": cal["body_hex"],
                       "decoded": cal.get("calib")}, fh, indent=2)
    if baseline:
        rows = ["sample,elapsed_s,t,GET_STATUS,CPS_0x8020,DR_uR_h_0x8021,DS_uR_0x8022,"
                "TEMP_degC_0x8024,CHARGER_0xC200,DEVICE_TIME_0x0504,MS_RUN_0x0603,"
                "DATA_BUF_bytes,LIVE_WINDOW_counts,LIVE_WINDOW_ms,LIVE_WINDOW_us,"
                "SPECTRUM_bytes"]
        for s in baseline["samples"]:
            def g(key, sub=None):
                v = s.get(key)
                if isinstance(v, dict):
                    return v.get(sub) if sub else v.get("hex")
                return v
            def num(key):
                v = s.get(key)
                if isinstance(v, dict):
                    return v.get("u32", "")
                return v or ""
            lw = s.get("LIVE_WINDOW_0x220", {}).get("decoded", {})
            rows.append(",".join(str(x) for x in [
                s["sample"], s["elapsed_s"], s["t"], s.get("GET_STATUS", ""),
                num("CPS_0x8020"), num("DR_uR_h_0x8021"), num("DS_uR_0x8022"),
                num("TEMP_degC_0x8024"), num("CHARGER_0xC200"), num("DEVICE_TIME_0x0504"),
                num("MS_RUN_0x0603"),
                len(bytes.fromhex(s.get("DATA_BUF_0x100", {}).get("hex", ""))),
                lw.get("counts", ""), lw.get("ms", ""), lw.get("us", ""),
                len(bytes.fromhex(s.get("SPECTRUM_0x200", {}).get("hex", "")))]))
        with open(os.path.join(DEC, "baseline_measurements.csv"), "w", encoding="utf-8") as fh:
            fh.write("\n".join(rows) + "\n")
        with open(os.path.join(DEC, "baseline_measurements.json"), "w", encoding="utf-8") as fh:
            json.dump(baseline, fh, indent=2, ensure_ascii=False)
    print(json.dumps({"exchanges": len(ex),
                      "answered": sum(1 for e in ex if e["header_echo_ok"]),
                      "vs": sorted(strings), "vsfr": len(vsfrs),
                      "baseline_samples": len(baseline["samples"]) if baseline else 0},
                     indent=2))


asyncio.run(main())
