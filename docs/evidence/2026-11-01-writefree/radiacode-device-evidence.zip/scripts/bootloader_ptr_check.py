"""Decide, for every 0x0800xxxx word found in the image, whether the disassembly treats it
as an instruction or as a data item - i.e. whether the application really holds pointers
into the missing bootloader region.

listing.s is 16-byte (4-word) rows: `<addr>  <item> <item> <item> <item>` where items are
`.byte …` (whole row), `.word 0x…`, `.fill n ; …`, or instructions.
"""

import json
import os
import re
import struct
from collections import Counter

ROOT = r"C:\Users\ryans\source\repos\radiacode"
TARGET = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14")
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\hardware"

img = open(os.path.join(TARGET, "flash.bin"), "rb").read()
BASE = 0x08000000

rows = {}
pat = re.compile(r"^\s*([0-9A-Fa-f]{8})\s+(.*)$")
with open(os.path.join(TARGET, "listing.s"), encoding="utf-8", errors="replace") as fh:
    for line in fh:
        m = pat.match(line)
        if m:
            rows[int(m.group(1), 16)] = m.group(2).strip()

words = {}
for off in range(0x10000, len(img) - 3, 4):
    w = struct.unpack_from("<I", img, off)[0]
    if 0x08000000 <= w < 0x08010000:
        words[BASE + off] = w

items = []
for addr in sorted(words):
    row_addr = addr & ~0xF
    text = rows.get(row_addr, "")
    pos = (addr & 0xF) // 4
    kind, detail = "unknown", ""
    if text.startswith(".fill"):
        kind, detail = "padding(.fill)", text
    elif text.startswith(".byte"):
        kind = "unclassified_data(.byte)"
        toks = re.findall(r"\.byte\s+(0x[0-9a-f]{2})\s*,\s*(0x[0-9a-f]{2})\s*,\s*"
                          r"(0x[0-9a-f]{2})\s*,\s*(0x[0-9a-f]{2})", text)
        if toks and len(toks) > pos:
            b = [int(x, 16) for x in toks[pos]]
            detail = "bytes %s -> %s" % ([hex(x) for x in b],
                                         struct.pack("<4B", *b).hex())
    elif text.startswith(".word"):
        kind = "data(.word)"
        detail = text
    else:
        kind = "instruction_row"
        detail = text
    items.append({"address": "0x%08X" % addr, "word": "0x%08X" % words[addr],
                  "kind": kind, "row_address": "0x%08X" % row_addr, "detail": detail})

out = {"total_words_in_bootloader_range": len(items),
       "by_kind": dict(Counter(i["kind"] for i in items)),
       "items": items}
with open(os.path.join(OUT, "bootloader_pointers_check.json"), "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=2)
print(json.dumps(out["by_kind"], indent=1))
for i in items[:10]:
    print(i["address"], i["word"], i["kind"], i["detail"][:110])
