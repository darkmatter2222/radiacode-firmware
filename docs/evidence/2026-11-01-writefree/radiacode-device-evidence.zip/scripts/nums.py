import hashlib
import json
import os
import struct

E = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
j = json.load(open(os.path.join(E, "raw", "handshake_experiment.json"), encoding="utf-8"))

# temp range
def f32(hexp):
    return struct.unpack("<f", bytes.fromhex(hexp))[0] if hexp else None

temps = [f32(s["TEMP_degC"][8:]) for s in j["baseline"]["samples"] if s.get("TEMP_degC")]
print("TEMP min/max:", min(temps), max(temps), "n", len(temps))
dt = [int.from_bytes(bytes.fromhex(s["DEVICE_TIME"][8:]), "little") for s in j["baseline"]["samples"]]
print("DEVICE_TIME first/last:", dt[0], dt[-1], "delta", dt[-1] - dt[0], "s over window", j["baseline"]["samples"][-1]["elapsed_s"])
print("DEVICE_TIME initial read:", j["vsfr"]["DEVICE_TIME"]["hex"])

# identity_repeat payload sha vs first-read payload sha
first = {}
for e in j["exchanges"]:
    if e["phase"] in ("identity", "virtual_strings"):
        key = e["label"] if e["cmd"] != "0x0826" else e["label"]
        first.setdefault(key, e["payload_sha256"])
bad = {k: (v["sha256"], first.get(k)) for k, v in j["identity_repeat"].items() if v["sha256"] != first.get(k)}
print("repeat mismatches vs first-read payload sha:", bad)

# config bytes vs in-image blob
cfg = bytes.fromhex(j["virtual_strings"]["0x002"]["body_hex"])
blob = open(os.path.join(E, "decoded", "image_config_text_0x0802F9F0.txt"), "rb").read()
print("cfg len", len(cfg), "sha", hashlib.sha256(cfg).hexdigest())
print("in-image blob first 3256 == cfg:", blob[:3256] == cfg, "blob len", len(blob))

# areas: decoded hex prefix
for k, v in j["flash_areas"].items():
    print("area", k, "status", v.get("status"), "size", v.get("size"), "hex head", (v.get("hex") or "")[:64])

# VS raw for 0x003, 0x00D, 0x101
for vs in ("0x003", "0x00D", "0x101"):
    print("VS", vs, j["virtual_strings"].get(vs))

# word0/word1 of every 0x0824 reply to verify prefix constancy
pref = {e["label"]: e["payload_hex"][:8] for e in j["exchanges"] if e["cmd"] == "0x0824"}
print("0824 prefixes:", sorted(set(pref.values())), "n labels", len(pref))

# GET_VERSION decode check + serial
print("serial:", j["identity"].get("GET_SERIAL"))
print("hw:", j["identity"].get("RD_HW_CONFIG"))
print("imginfo:", j["identity"].get("FW_IMAGE_GET_INFO", {}).get("decoded"))
print("signat:", j["identity"].get("RD_SIGNAT", {}).get("decoded"))
