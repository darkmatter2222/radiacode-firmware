import hashlib
import json
import os
import struct
import sys

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from protocol import decode_calib  # noqa: E402

E = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
j = json.load(open(os.path.join(E, "raw", "handshake_experiment.json"), encoding="utf-8"))
PRIOR = json.load(open(r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
                       r"\analysis\capture.json", encoding="utf-8"))

print("== identity: fresh vs prior ==")
for k, v in j["identity"].items():
    p = PRIOR["identity"].get(k) or PRIOR["identity"].get(k.lower())
    phex = p.get("hex") if isinstance(p, dict) else p
    same = (phex == v["hex"]) if phex else None
    print(" ", k, "len", v["len"], "same_as_prior:", same)
    if not same:
        print("    fresh:", (v["hex"] or "")[:100])
        print("    prior:", str(phex)[:100])

print("\n== GET_STATUS pre/post/baseline variation ==")
st = [e["payload_hex"] for e in j["exchanges"] if e["label"] == "GET_STATUS"]
print("  distinct:", sorted(set(st)), "count", len(st))

print("\n== virtual strings: fresh vs prior body sha ==")
for vs, v in sorted(j["virtual_strings"].items()):
    p = PRIOR["virtual_strings"].get(vs)
    pbody = p["hex"] if p else None
    same = pbody is not None and pbody == v.get("body_hex")
    txt = v.get("text_utf8") or ""
    print(" ", vs, "declared", v.get("declared_size"), "body", v.get("body_bytes"),
          "same_as_prior:", same, "utf8_ok:", bool(txt), "|", txt[:60].replace("\n", "\\n"))
    if v.get("calib"):
        print("      calib:", json.dumps(v["calib"]))
        if vs == "0x202" and p:
            print("      prior calib:", json.dumps(decode_calib(bytes.fromhex(p["hex"]))))

print("\n== config text UTF-8 check ==")
cfg = bytes.fromhex(j["virtual_strings"]["0x002"]["body_hex"])
try:
    t = cfg.decode("utf-8")
    print("  utf-8 strict OK, len", len(t), "sha", hashlib.sha256(cfg).hexdigest()[:16])
except UnicodeDecodeError as exc:
    print("  strict FAIL", exc)
    bad = [i for i, b in enumerate(cfg) if b > 127]
    print("  non-ascii byte positions:", bad[:10], "values:", [hex(cfg[i]) for i in bad[:10]])
print("  same as prior 0x002:", PRIOR["virtual_strings"]["0x002"]["hex"] ==
      j["virtual_strings"]["0x002"]["body_hex"])

print("\n== flash areas fresh vs prior ==")
for k, v in j["flash_areas"].items():
    p = (PRIOR.get("flash_areas") or {}).get(k)
    print(" area", k, {kk: (str(vv)[:70] if isinstance(vv, str) else vv)
                      for kk, vv in v.items() if kk != "raw_payload_hex"},
          "same_raw_as_prior:", p and p.get("raw_payload_hex") == v.get("raw_payload_hex"))

print("\n== vsfr: nonzero and vs prior readout ==")
try:
    OLDV = json.load(open(r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
                          r"\analysis\vsfr_readout.json", encoding="utf-8"))
except FileNotFoundError:
    OLDV = {}
single = OLDV.get("single_nonzero") or {}
for name, v in j["vsfr"].items():
    if v["u32le"]:
        print(" ", name, v["addr"], "u32", v["u32le"], "hex", v["hex"],
              "prior:", json.dumps(single.get(name))[:60])

print("\n== baseline variation ==")
bs = j["baseline"]["samples"]
for key in ("GET_STATUS", "CPS", "DR_uR_h", "DS_uR", "TEMP_degC", "CHARGER_STATE",
            "DEVICE_TIME", "MS_RUN", "VS_220", "VS_200"):
    vals = [s.get(key) for s in bs]
    distinct = sorted({v for v in vals})
    print(" ", key, "distinct:", len(distinct), distinct[:4])

print("\n== identity_repeat consistency ==")
for k, v in j["identity_repeat"].items():
    first = (j["identity"].get(k) or {}).get("sha256") or (
        j["virtual_strings"].get("0x002" if k == "VS_002" else "0x202", {}).get("body_sha256"))
    print(" ", k, "repeat_sha==first_sha:", first == v["sha256"])

print("\n== writes + counts ==", j["writes_issued"], j["counts"])
