"""Patient write-free collection (v2): scan-then-connect, per-command connection, no writes.

Same command set as collect_writefree.py but tolerant of a device that briefly stops
advertising, and it flushes the JSON after every phase.
"""

import asyncio
import datetime
import hashlib
import json
import os
import struct
import sys

from bleak import BleakClient, BleakScanner

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from protocol import (CMD, VS, decode_calib, decode_flash_area, decode_image_info,  # noqa: E402
                      decode_signature, decode_versions, serial_from_address, split)

ROOT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
RAW = os.path.join(ROOT, "raw")
WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = "e63215e7-7003-49d8-96b0-b024798fb901"
SERVICE_UUID = "e63215e5-7003-49d8-96b0-b024798fb901"
ADDRESS = "52:43:06:60:20:24"
PATH = os.path.join(RAW, "session_writefree_v2.json")

VS_IDS = [0x002, 0x003, 0x008, 0x00D, 0x00F, 0x0F0, 0x100, 0x101, 0x200, 0x202,
          0x203, 0x205, 0x206, 0x207, 0x208, 0x220]
VSFRS = [("DEVICE_CTRL", 0x0500), ("DEVICE_TIME", 0x0504), ("MS_RUN", 0x0603),
         ("BLE_TX_PWR", 0x0700), ("CPS", 0x8020), ("DR_uR_h", 0x8021), ("DS_uR", 0x8022),
         ("TEMP_degC", 0x8024), ("CHARGER_STATE", 0xC200), ("MCU_ID0", 0xFFFF0000),
         ("MCU_ID1", 0xFFFF0001), ("MCU_ID2", 0xFFFF0002), ("BOOT_VERSION", 0xFFFF0009),
         ("TARGET_VERSION", 0xFFFF000A), ("MCU_TEMP", 0xFFFF000D)]


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="milliseconds")


def sha(b):
    return hashlib.sha256(b).hexdigest() if b else None


def decoded_for(cmd, data):
    try:
        if cmd == 0x000A:
            return decode_versions(data)
        if cmd == 0x0012:
            return decode_image_info(data)
        if cmd == 0x0101:
            return decode_signature(data)
        if cmd == 0x081C:
            return decode_flash_area(data)
        if cmd == 0x0824 and len(data) >= 8:
            return {"u32": struct.unpack_from("<I", data, 4)[0],
                    "f32": struct.unpack_from("<f", data, 4)[0]}
        if cmd == 0x0824 and len(data) == 4:
            return {"u32": struct.unpack("<I", data)[0],
                    "f32": struct.unpack("<f", data)[0]}
    except Exception as exc:  # noqa: BLE001
        return {"decode_error": repr(exc)}
    return None


async def read_once(cmd, args=b"", window=1.0, tries=3):
    base = {"t_request": None, "t_response": None, "transport": "bluetooth-le/gatt",
            "address": ADDRESS, "service": SERVICE_UUID, "write_char": WRITE_UUID,
            "notify_char": NOTIFY_UUID, "cmd_id": "0x%04X" % cmd,
            "cmd_name": CMD.get(cmd, "?"), "args_hex": bytes(args).hex(),
            "request_wire_hex": None, "frames_hex": [], "header_echo_ok": False,
            "payload_hex": None, "payload_len": 0, "payload_sha256": None}
    rec = base
    for attempt in range(tries):
        state = {"buf": b""}

        def on_notify(handle, data):
            state["buf"] += bytes(data)

        try:
            dev = await BleakScanner.find_device_by_address(ADDRESS, timeout=6.0)
            if dev is None:
                rec = dict(base)
                rec["error"] = "scan-miss"
                rec["attempt"] = attempt
                await asyncio.sleep(0.4)
                continue
            client = BleakClient(dev, timeout=15.0)
            await client.connect()
            await client.start_notify(NOTIFY_UUID, on_notify)
            request = struct.pack("<HBB", cmd, 0, 0x80) + bytes(args)
            full = struct.pack("<I", len(request)) + request
            t0 = now()
            for pos in range(0, len(full), 18):
                await client.write_gatt_char(WRITE_UUID, full[pos:pos + 18])
            loop = asyncio.get_running_loop()
            deadline = loop.time() + window
            frames, matched = [], None
            while loop.time() < deadline:
                buf = state["buf"]
                while len(buf) >= 4:
                    total = 4 + struct.unpack_from("<I", buf)[0]
                    if len(buf) < total:
                        break
                    frames.append(buf[:total].hex())
                    buf = buf[total:]
                state["buf"] = buf
                for f in frames:
                    payload = bytes.fromhex(f)[4:]
                    if len(payload) >= 4 and payload[:4] == request[:4]:
                        matched = payload[4:]
                        break
                if matched is not None:
                    break
                await asyncio.sleep(0.005)
            t1 = now()
            rec = dict(base)
            rec.update({"t_request": t0, "t_response": t1, "request_wire_hex": full.hex(),
                        "frames_hex": frames, "header_echo_ok": matched is not None,
                        "payload_hex": matched.hex() if matched is not None else None,
                        "payload_len": len(matched) if matched is not None else 0,
                        "payload_sha256": sha(matched), "attempt": attempt})
            try:
                await client.disconnect()
            except Exception:  # noqa: BLE001
                pass
            if matched is not None:
                return rec
        except Exception as exc:  # noqa: BLE001
            rec = dict(base)
            rec["error"] = repr(exc)
            rec["attempt"] = attempt
            await asyncio.sleep(0.4)
    return rec


async def main():
    baseline_seconds = int(sys.argv[sys.argv.index("--baseline") + 1]) \
        if "--baseline" in sys.argv else 60
    ex, strings, areas, vsfrs, stability = [], {}, {}, {}, []
    box = {}

    def flush():
        box.update({"collected": now(), "address": ADDRESS,
                    "ble_name_from_address": serial_from_address(ADDRESS),
                    "writes_issued": [], "virtual_strings": strings, "flash_areas": areas,
                    "vsfr": vsfrs, "repeat_stability": stability,
                    "baseline": box.get("baseline"), "exchanges": ex})
        with open(PATH, "w", encoding="utf-8") as fh:
            json.dump(box, fh, indent=2, ensure_ascii=False)

    async def go(label, cmd, args=b"", note=""):
        rec = await read_once(cmd, args)
        rec["label"] = label
        rec["decoded"] = decoded_for(cmd, bytes.fromhex(rec["payload_hex"])) \
            if rec["payload_hex"] else None
        if note:
            rec["note"] = note
        ex.append(rec)
        return rec

    for cid in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
        await go(CMD[cid], cid)
    flush()
    for vs in VS_IDS:
        rec = await go("VS_%03X" % vs, 0x0826, struct.pack("<I", vs),
                       note="VS 0x%03X %s" % (vs, VS.get(vs, "?")))
        if rec["payload_hex"]:
            _, size, body = split(bytes.fromhex(rec["payload_hex"]))
            entry = {"vs": "0x%03X" % vs, "name": VS.get(vs, "?"), "declared_size": size,
                     "body_bytes": len(body), "body_hex": body.hex(),
                     "body_sha256": sha(body)}
            if VS.get(vs) in ("CONFIGURATION", "SERIAL_NUMBER", "EVENT_LOG"):
                entry["text"] = body.split(b"\x00")[0].decode("cp1251", "replace")
            if vs == 0x202:
                entry["calib"] = decode_calib(body)
            strings[entry["vs"]] = entry
        flush()
    for area in range(4):
        rec = await go("area%d" % area, 0x081C, struct.pack("<I", area))
        areas[str(area)] = {"payload_hex": rec["payload_hex"], "decoded": rec["decoded"]}
        flush()
    for label, addr in VSFRS:
        rec = await go(label, 0x0824, struct.pack("<I", addr), note="VSFR 0x%08X" % addr)
        if rec["decoded"]:
            vsfrs[label] = {"addr": "0x%08X" % addr, "payload_hex": rec["payload_hex"],
                            **rec["decoded"]}
        flush()
    for i in range(2):
        snap = {}
        for cid in (0x0005, 0x000A, 0x0012, 0x0101, 0x0807):
            snap[CMD[cid]] = (await go("repeat%d %s" % (i, CMD[cid]), cid))["payload_sha256"]
        for vs in (0x002, 0x008, 0x202, 0x0F0):
            snap["VS_%03X" % vs] = (await go("repeat%d VS_%03X" % (i, vs), 0x0826,
                                             struct.pack("<I", vs)))["payload_sha256"]
        stability.append(snap)
        flush()
    samples, k = [], 0
    t0 = asyncio.get_running_loop().time()
    while asyncio.get_running_loop().time() - t0 < baseline_seconds:
        s = {"sample": k, "t": now(),
             "elapsed_s": round(asyncio.get_running_loop().time() - t0, 3)}
        for label, cmd, args in (("GET_STATUS", 0x0005, b""),):
            r = await go("baseline%d %s" % (k, label), cmd, args)
            s[label] = r["payload_hex"]
        for label, addr in (("CPS", 0x8020), ("DR", 0x8021), ("DS", 0x8022),
                            ("TEMP", 0x8024), ("CHARGER", 0xC200), ("DEV_TIME", 0x0504),
                            ("MS_RUN", 0x0603)):
            r = await go("baseline%d %s" % (k, label), 0x0824, struct.pack("<I", addr))
            s[label] = r["decoded"] or r["payload_hex"]
        for vs, key in ((0x220, "LIVE_WINDOW"), (0x200, "SPECTRUM"), (0x100, "DATA_BUF")):
            r = await go("baseline%d %s" % (k, key), 0x0826, struct.pack("<I", vs))
            if r["payload_hex"]:
                _, size, body = split(bytes.fromhex(r["payload_hex"]))
                s[key] = {"declared_size": size, "hex": body.hex(), "sha256": sha(body)}
                if vs == 0x220 and len(body) >= 12:
                    s[key]["counts_ms_us"] = list(struct.unpack_from("<III", body, 0))
        samples.append(s)
        box["baseline"] = {"seconds": baseline_seconds, "samples": samples}
        flush()
        k += 1
    print(json.dumps({"exchanges": len(ex),
                      "answered": sum(1 for e in ex if e["header_echo_ok"]),
                      "vs": len(strings), "vsfr": len(vsfrs), "samples": k}))


asyncio.run(main())
