"""Hypothesis test, still with zero device writes: does the unit answer exactly one
command per BLE connection (so that reconnecting per command yields real data)?

Connection 1: 0x0005 then 0x0005 again   -> is only the first answered?
Connection 2: 0x000A as the first command -> does a non-0x0005 id answer when first?
Connection 3: 0x0826 VS 0x008 as first    -> does the bulk channel answer when first?

Only the documented read ids are used (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807,
0x081C, 0x0824, 0x0826). No write id (0x0007, 0x0A04, 0x0825, 0x0827, 0x082B) is issued.
"""

import asyncio
import json
import struct
import sys

from bleak import BleakClient

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from protocol import decode_flash_area, decode_image_info, decode_signature, \
    decode_versions, split  # noqa: E402

WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = "e63215e7-7003-49d8-96b0-b024798fb901"
ADDRESS = "52:43:06:60:20:24"

OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\raw\probe_one_command_per_connection.json"


async def one_exchange(client, state, cmd, args=b"", timeout=2.5):
    seq = 0x80 + state[0]
    state[0] = (state[0] + 1) % 32
    request = struct.pack("<HBB", int(cmd), 0, seq) + bytes(args)
    full = struct.pack("<I", len(request)) + request
    for pos in range(0, len(full), 18):
        await client.write_gatt_char(WRITE_UUID, full[pos:pos + 18])
    buf = b""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    frames = []
    while loop.time() < deadline:
        while state[1]:
            buf += state[1].pop(0)
        while len(buf) >= 4:
            total = 4 + struct.unpack_from("<I", buf)[0]
            if len(buf) < total:
                break
            frames.append(buf[:total].hex())
            buf = buf[total:]
        if frames:
            break
        await asyncio.sleep(0.005)
    return {"cmd": "0x%04X" % int(cmd), "request": full.hex(), "frames": frames}


async def run_connection(plan):
    """plan: list of (label, cmd, args). One connection, N commands, all frames logged."""
    state = [0, []]

    def on_notify(handle, data):
        state[1].append(bytes(data))

    client = BleakClient(ADDRESS, timeout=10.0)
    await client.connect()
    await client.start_notify(NOTIFY_UUID, on_notify)
    steps = []
    for label, cmd, args in plan:
        rec = await one_exchange(client, state, cmd, args)
        rec["label"] = label
        steps.append(rec)
        await asyncio.sleep(0.05)
    await client.disconnect()
    return {"steps": steps}


def try_decode(cmd, frame_hex):
    """Attach the repo's decoders to a frame whose 4-byte header echoed the request."""
    raw = bytes.fromhex(frame_hex)
    if len(raw) < 8:
        return None
    payload = raw[4:]
    data = payload[4:]
    try:
        if cmd == 0x000A:
            return decode_versions(data)
        if cmd == 0x0012:
            return decode_image_info(data)
        if cmd == 0x0101:
            return decode_signature(data)
        if cmd == 0x081C:
            return decode_flash_area(data)
    except Exception as exc:  # noqa: BLE001
        return {"decode_error": repr(exc)}
    return None


async def main():
    result = {}
    result["conn1_status_twice"] = await run_connection(
        [("1st 0x0005", 0x0005, b""), ("2nd 0x0005", 0x0005, b"")])
    result["conn2_version_first"] = await run_connection([("1st 0x000A", 0x000A, b"")])
    result["conn3_vs008_first"] = await run_connection(
        [("1st 0x0826 VS8", 0x0826, struct.pack("<I", 0x008))])
    result["conn4_serial_first"] = await run_connection([("1st 0x000B", 0x000B, b"")])
    result["conn5_sigat_first"] = await run_connection([("1st 0x0101", 0x0101, b"")])
    result["conn6_areainfo_first"] = await run_connection([("1st 0x0012", 0x0012, b"")])
    result["conn7_hwcfg_first"] = await run_connection([("1st 0x0807", 0x0807, b"")])
    result["conn8_area0_first"] = await run_connection(
        [("1st 0x081C a0", 0x081C, struct.pack("<I", 0))])
    result["conn9_vsfr_first"] = await run_connection(
        [("1st 0x0824 0x8020", 0x0824, struct.pack("<I", 0x8020))])
    # decoded views of the answered frames
    for key, block in result.items():
        for step in block["steps"]:
            cmd = int(step["cmd"], 16)
            dec = [try_decode(cmd, f) for f in step["frames"]]
            step["decoded_frames"] = dec
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)
    print(json.dumps(result, indent=2)[:2600])


asyncio.run(main())
