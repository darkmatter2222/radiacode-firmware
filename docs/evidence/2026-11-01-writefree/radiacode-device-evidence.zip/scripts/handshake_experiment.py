"""One-shot handshake experiment + read-only collection (single BLE connection).

Fixed order; the handshake frame is written exactly once and never retried.
No library constructor is used, so no implicit 0x0A04 / 0x0825 traffic exists.
"""

import asyncio
import datetime
import hashlib
import json
import os
import struct
import sys
import time

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
from bleak import BleakClient  # noqa: E402

from protocol import (CMD, decode_calib, decode_flash_area, decode_image_info,  # noqa: E402
                      decode_signature, decode_versions, split)

ADDRESS = "52:43:06:60:20:24"
SERVICE = "e63215e5-7003-49d8-96b0-b024798fb901"
WRITE = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY = "e63215e7-7003-49d8-96b0-b024798fb901"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\raw\handshake_experiment.json"

VS_IDS = [0x002, 0x003, 0x008, 0x00D, 0x00F, 0x0F0, 0x100, 0x101, 0x200, 0x202, 0x203,
          0x205, 0x206, 0x207, 0x208, 0x220]
VSFRS = {"DEVICE_CTRL": 0x500, "DEVICE_LANG": 0x502, "DEVICE_ON": 0x503, "DEVICE_TIME": 0x504,
         "BLE_TX_PWR": 0x700, "DISP_CTRL": 0x510, "DISP_BRT": 0x511, "MS_RUN": 0x603,
         "CPS": 0x8020, "DR_uR_h": 0x8021, "DS_uR": 0x8022, "TEMP_degC": 0x8024,
         "ACC_X": 0x8025, "CHARGER_STATE": 0xC200, "VBIAS_mV": 0xC000, "COMP_LEV": 0xC001,
         "CALIB_MODE": 0xC002, "MCU_ID0": 0xFFFF0000, "MCU_ID1": 0xFFFF0001,
         "MCU_ID2": 0xFFFF0002, "DEVICE_ID": 0xFFFF0005, "SIGNATURE": 0xFFFF0006,
         "RX_SIZE": 0xFFFF0007, "TX_SIZE": 0xFFFF0008, "BOOT_VERSION": 0xFFFF0009,
         "TARGET_VERSION": 0xFFFF000A, "STATUS": 0xFFFF000B, "MCU_VREF": 0xFFFF000C,
         "MCU_TEMP": 0xFFFF000D}
BASELINE_VSFRS = ("CPS", "DR_uR_h", "DS_uR", "TEMP_degC", "CHARGER_STATE", "DEVICE_TIME", "MS_RUN")


def now():
    return datetime.datetime.now().isoformat(timespec="milliseconds")


class Bus:
    def __init__(self, client):
        self.client = client
        self.buf = b""
        self.seq = 0
        self.frames = 0

    def on_notify(self, _handle, data):
        self.buf += bytes(data)

    async def request(self, label, cmd, args=b"", attempts=2, window=3.0, phase=""):
        rec = {"label": label, "cmd": "0x%04X" % cmd, "cmd_name": CMD.get(cmd, "?"),
               "phase": phase, "args_hex": bytes(args).hex(), "attempts": []}
        for n in range(max(1, attempts)):
            seq = 0x80 + (self.seq % 32)
            self.seq += 1
            req = struct.pack("<HBB", int(cmd), 0, seq) + bytes(args)
            wire = struct.pack("<I", len(req)) + req
            t0 = now()
            self.buf = b""
            for pos in range(0, len(wire), 18):
                await self.client.write_gatt_char(WRITE, wire[pos:pos + 18])
            got, frames = None, []
            deadline = asyncio.get_running_loop().time() + window
            header = req[:4]
            while asyncio.get_running_loop().time() < deadline:
                while len(self.buf) >= 4:
                    total = 4 + struct.unpack_from("<I", self.buf)[0]
                    if len(self.buf) < total:
                        break
                    payload = self.buf[4:total]
                    self.buf = self.buf[total:]
                    frames.append(payload.hex())
                    self.frames += 1
                    if len(payload) >= 4 and payload[:4] == header:
                        got = payload[4:]
                if got is not None:
                    break
                await asyncio.sleep(0.005)
            rec["attempts"].append({"attempt": n, "seq": "0x%02X" % seq, "t_request": t0,
                                    "request_wire_hex": wire.hex(), "frames_hex": frames,
                                    "header_echo_ok": got is not None,
                                    "payload_hex": got.hex() if got else None,
                                    "payload_len": len(got) if got else 0,
                                    "payload_sha256": hashlib.sha256(got).hexdigest() if got else None})
            if got is not None:
                break
        last = rec["attempts"][-1]
        rec["answered"] = last["header_echo_ok"]
        rec["payload_hex"] = last["payload_hex"]
        rec["payload_len"] = last["payload_len"]
        rec["payload_sha256"] = last["payload_sha256"]
        return rec


def interpret(cmd, payload_hex):
    if not payload_hex:
        return None
    data = bytes.fromhex(payload_hex)
    try:
        if cmd == 0x000A:
            return decode_versions(data)
        if cmd == 0x0012:
            return decode_image_info(data)
        if cmd == 0x0101:
            return decode_signature(data)
        if cmd == 0x081C:
            return decode_flash_area(data)
    except Exception as exc:  # noqa: BLE001
        return {"decode_error": repr(exc)}
    return None


async def run(baseline_seconds):
    ex = []                     # every exchange, in order, with its phase
    out = {"started": now(), "address": ADDRESS,
           "service_uuids": {"service": SERVICE, "write": WRITE, "notify": NOTIFY},
           "chunk_bytes": 18, "handshake": None, "identity": {}, "identity_repeat": {},
           "virtual_strings": {}, "flash_areas": {}, "vsfr": {}, "baseline": None,
           "writes_issued": [], "notes": [], "exchanges": ex}
    try:
        await _collect(out, baseline_seconds)
    except Exception as exc:  # noqa: BLE001
        out["notes"].append("aborted: %r" % (exc,))
        _dump(out)
        raise
    _dump(out)
    return out


async def _collect(out, baseline_seconds):
    ex = out["exchanges"]
    async with BleakClient(ADDRESS, timeout=15.0) as client:
        bus = Bus(client)
        await client.start_notify(NOTIFY, bus.on_notify)

        for label, cmd in (("GET_STATUS", 0x0005), ("GET_VERSION", 0x000A)):
            r = await bus.request(label, cmd, phase="pre_handshake")
            r["decoded"] = interpret(cmd, r["payload_hex"])
            ex.append(r)

        hs = await bus.request("SET_EXCHANGE", 0x0007, bytes.fromhex("01ff12ff"),
                               attempts=1, window=4.0, phase="handshake")
        hs["expected_from_repo_probe"] = "0501dada2010001001020000"
        hs["matches_repo_probe"] = (hs["payload_hex"] == hs["expected_from_repo_probe"])
        ex.append(hs)
        out["handshake"] = hs
        if not hs["answered"]:
            out["notes"].append("handshake unanswered -> inconclusive; no further reads issued")
            out["finished"] = now()
            _dump(out)
            return out

        for label, cmd in (("GET_STATUS", 0x0005), ("GET_VERSION", 0x000A)):
            r = await bus.request(label, cmd, phase="post_handshake")
            r["decoded"] = interpret(cmd, r["payload_hex"])
            ex.append(r)

        for cmd in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
            name = CMD.get(cmd, "0x%04X" % cmd)
            r = await bus.request(name, cmd, phase="identity")
            r["decoded"] = interpret(cmd, r["payload_hex"])
            ex.append(r)
            if r["answered"]:
                out["identity"][name] = {"hex": r["payload_hex"], "len": r["payload_len"],
                                         "sha256": r["payload_sha256"], "decoded": r["decoded"]}

        for vs in VS_IDS:
            r = await bus.request("VS_%03X" % vs, 0x0826, struct.pack("<I", vs),
                                  phase="virtual_strings")
            ex.append(r)
            if not r["answered"]:
                continue
            data = bytes.fromhex(r["payload_hex"])
            entry = {"raw_hex": r["payload_hex"], "raw_sha256": r["payload_sha256"]}
            if len(data) >= 8:
                version, size, body = split(data)
                entry.update({"version": version, "declared_size": size,
                              "body_bytes": len(body), "body_hex": body.hex(),
                              "body_sha256": hashlib.sha256(body).hexdigest()})
                head = body.split(b"\x00")[0]
                if head:
                    entry["text_utf8"] = head.decode("utf-8", "replace")
                if vs in (0x200, 0x202, 0x205):
                    try:
                        entry["calib"] = decode_calib(body[-12:] if vs == 0x200 else body)
                    except Exception as exc:  # noqa: BLE001
                        entry["calib_error"] = repr(exc)
            out["virtual_strings"]["0x%03X" % vs] = entry

        for area in range(4):
            r = await bus.request("AREA%d" % area, 0x081C, struct.pack("<I", area),
                                  phase="flash_areas")
            ex.append(r)
            if r["answered"]:
                try:
                    out["flash_areas"][str(area)] = dict(
                        decode_flash_area(bytes.fromhex(r["payload_hex"])),
                        raw_payload_hex=r["payload_hex"])
                except Exception as exc:  # noqa: BLE001
                    out["notes"].append("area %d decode error %r" % (area, exc))

        for name, addr in VSFRS.items():
            r = await bus.request("VSFR_" + name, 0x0824, struct.pack("<I", addr), phase="vsfr")
            ex.append(r)
            if r["answered"]:
                raw = bytes.fromhex(r["payload_hex"])
                out["vsfr"][name] = {"hex": r["payload_hex"], "addr": "0x%08X" % addr,
                                     "u32le": struct.unpack_from("<I", raw + b"\0\0\0\0", 0)[0]
                                     if len(raw) >= 4 else None}

        rep = {}
        for cmd in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
            name = CMD.get(cmd, "0x%04X" % cmd)
            r = await bus.request(name, cmd, phase="identity_repeat")
            ex.append(r)
            rep[name] = r
        for vs in (0x002, 0x202):
            r = await bus.request("VS_%03X" % vs, 0x0826, struct.pack("<I", vs),
                                  phase="identity_repeat")
            ex.append(r)
            rep["VS_%03X" % vs] = r
        out["identity_repeat"] = {k: {"answered": v["answered"], "sha256": v["payload_sha256"]}
                                  for k, v in rep.items()}

        t0 = time.monotonic()
        samples = []
        while time.monotonic() - t0 < baseline_seconds:
            s = {"sample": len(samples), "t": now(), "elapsed_s": round(time.monotonic() - t0, 3)}
            r = await bus.request("GET_STATUS", 0x0005, phase="baseline")
            s["GET_STATUS"] = r["payload_hex"]
            ex.append(r)
            for name in BASELINE_VSFRS:
                r = await bus.request("VSFR_" + name, 0x0824, struct.pack("<I", VSFRS[name]),
                                      phase="baseline")
                s[name] = r["payload_hex"]
                ex.append(r)
            for vs in (0x220, 0x200):
                r = await bus.request("VS_%03X" % vs, 0x0826, struct.pack("<I", vs),
                                      phase="baseline")
                s["VS_%03X" % vs] = r["payload_hex"]
                ex.append(r)
            samples.append(s)
        out["baseline"] = {"seconds": baseline_seconds, "samples": samples}
        try:
            await client.stop_notify(NOTIFY)
        except Exception:  # noqa: BLE001
            pass

    out["finished"] = now()
    out["counts"] = {"requests": len(ex), "answered": sum(1 for e in ex if e.get("answered")),
                     "frames": bus.frames}
    out["writes_issued"] = [{"cmd": "0x0007", "name": "SET_EXCHANGE", "args_hex": "01ff12ff",
                             "count": 1}]
    _dump(out)
    return out


def _dump(obj):
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    base = 60
    if "--baseline" in sys.argv:
        base = int(sys.argv[sys.argv.index("--baseline") + 1])
    res = asyncio.run(run(base))
    per = {}
    for e in res["exchanges"]:
        per.setdefault(e["phase"], [0, 0])
        per[e["phase"]][0] += 1
        per[e["phase"]][1] += 1 if e.get("answered") else 0
    print(json.dumps({"counts": res.get("counts"), "per_phase_requests_answered": per,
                      "handshake_answered": res["handshake"]["answered"],
                      "handshake_matches_repo_probe": res["handshake"].get("matches_repo_probe"),
                      "handshake_payload": res["handshake"]["payload_hex"],
                      "identity_ids": sorted(res["identity"]),
                      "vs": len(res["virtual_strings"]), "vsfr": len(res["vsfr"]),
                      "areas": sorted(res["flash_areas"]),
                      "baseline_samples": len((res.get("baseline") or {}).get("samples", [])),
                      "notes": res["notes"]}, indent=1))
