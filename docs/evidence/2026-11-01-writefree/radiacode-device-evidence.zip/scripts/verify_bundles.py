import hashlib
import json
import os
import zipfile

REPO = r"C:\Users\ryans\source\repos\radiacode\docs\evidence"
for d, zname in (("2026-11-01-writefree", "radiacode-device-evidence.zip"),
                 ("2026-11-01-handshake", "radiacode-device-evidence-followup.zip")):
    root = os.path.join(REPO, d)
    man = json.load(open(os.path.join(root, "manifest.json"), encoding="utf-8"))
    z = zipfile.ZipFile(os.path.join(root, zname))
    names = set(z.namelist())
    ents = {e["path"]: e for e in man["files"]}
    print("==", d, "| files:", len(ents), "| self in entries:", "manifest.json" in ents,
          "| zip has manifest:", "manifest.json" in names)
    bad = [p for p, e in ents.items()
           if hashlib.sha256(z.read(p)).hexdigest() != e["sha256"]]
    print("   hash mismatches:", bad[:5], "of", len(ents))
    # unzipped copies match zip bytes (after LF normalisation both ways)
    def norm(b):
        return b.replace(b"\r\n", b"\n")
    mism = [p for p in ents if norm(open(os.path.join(root, p), "rb").read()) !=
            norm(z.read(p))]
    print("   unzipped-vs-zip mismatches:", mism[:5], "of", len(ents))
    chk = open(os.path.join(root, "CHECKSUMS256.txt"), encoding="utf-8").read().split("\n")
    for line in chk:
        if not line.strip():
            continue
        want, path = line.split()
        got = hashlib.sha256(open(os.path.join(root, path), "rb").read()).hexdigest()
        print("   checksum", path, "OK" if got == want else "MISMATCH")
    # labels
    for p in sorted(ents):
        if p.startswith(("raw/", "decoded/")):
            print("   ", p, "->", ents[p]["source"])
    if d == "2026-11-01-handshake":
        for p in ("decoded/consistency_report.json",):
            print(json.dumps(json.loads(z.read(p)), indent=1)[:1200])
