"""Assemble the evidence package: decoded artifacts, identity.json, manifest.json, ZIP.

Provenance labels are explicit: "fresh-writefree" = collected by the write-free passes on
2026-11-01 (no device writes), "prior-repo-capture" = the repository artifact produced by
pipeline/step2_probe.py on 2026-10-31T12:17:54 (the two documented session writes), and
"offline" = computed from files already in the checkout.
"""

import hashlib
import json
import os
import platform
import shutil
import struct
import subprocess
import sys
import zipfile

ROOT = r"C:\Users\ryans\source\repos\radiacode"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
TARGET = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14")
sys.path.insert(0, os.path.join(ROOT, "pipeline"))
from protocol import decode_calib, split  # noqa: E402

PRIOR = json.load(open(os.path.join(TARGET, "analysis", "capture.json"), encoding="utf-8"))
REG = [t for t in json.load(open(os.path.join(ROOT, "pipeline", "devices.json"),
                                 encoding="utf-8"))["targets"]
       if t["key"] == "rc-102/hw1-fw4.14"][0]

PASSES = {  # label -> raw file written by the write-free collectors
    "A_one_connection_per_command": "session_reads_writefree.json",
    "B_reused_connection_drain_per_request": "session_writefree_v2.json",
    "C_single_connection_persistent_buffer": "session_single_connection.json",
    "D_earliest_partial": "session_reads.json",
}


def load_json(path):
    raw = open(path, "rb").read()
    return json.loads(raw.decode("utf-16") if raw[:2] == b"\xff\xfe" else raw.decode("utf-8"))


PASS = {k: (load_json(os.path.join(OUT, "raw", v)) if os.path.exists(os.path.join(OUT, "raw", v))
            else None) for k, v in PASSES.items()}
FRESH = PASS["C_single_connection_persistent_buffer"] or PASS["B_reused_connection_drain_per_request"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def jdump(rel, obj):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
    return p


def stats(recs):
    """Answer/NAK/no-frame tally plus per-id table for one pass."""
    table = {}
    total = {"requests": 0, "data_answers": 0, "nak_frames": 0, "no_frame": 0}
    for r in recs:
        cid = r.get("cmd_id")
        e = table.setdefault(cid, {"name": r.get("cmd_name"), "requests": 0,
                                   "data_answers": 0, "nak_frames": 0, "no_frame": 0,
                                   "payload_values": []})
        e["requests"] += 1
        total["requests"] += 1
        frame = (r.get("frames_hex") or [""])[0]
        if r.get("header_echo_ok") and r.get("payload_hex"):
            e["data_answers"] += 1
            total["data_answers"] += 1
            if r["payload_hex"] not in e["payload_values"]:
                e["payload_values"].append(r["payload_hex"])
        elif frame.startswith("0400000006"):
            e["nak_frames"] += 1
            total["nak_frames"] += 1
        elif frame == "":
            e["no_frame"] += 1
            total["no_frame"] += 1
        else:
            e.setdefault("other_frames", []).append(frame)
    return total, table


# ------------------------------------------------------------- fresh pass artifacts
pass_summaries = {}
for label, doc in PASS.items():
    if not doc:
        continue
    recs = doc.get("exchanges") or []
    total, table = stats(recs)
    pass_summaries[label] = {
        "file": "raw/" + PASSES[label],
        "collected": doc.get("collected"),
        "writes_issued": doc.get("writes_issued", []),
        "requests": total["requests"],
        "data_answers": total["data_answers"],
        "nak_frames": total["nak_frames"],
        "no_frame": total["no_frame"],
        "per_id": table,
    }
jdump("decoded/fresh_writefree_answer_table.json",
      {"source": "fresh-writefree (no device writes), four passes on 2026-11-01",
       "note": ("data_answer = reply header equals the request header, so the record id and the "
                "seq byte echo the request; nak_frame = the 4-byte body 06 00 00 (seq|0x60); "
                "no_frame = nothing arrived inside the read window"),
       "passes": pass_summaries})

# NAK record pattern: body = [id u16, n u8, i u8]; i == (request seq | 0x60)?
nak_rows, nak_ok, nak_bad, shapes = [], 0, 0, {}
for label, doc in PASS.items():
    for r in (doc or {}).get("exchanges") or []:
        frame = (r.get("frames_hex") or [""])[0]
        if not frame.startswith("0400000006"):
            continue
        body = bytes.fromhex(frame[8:])
        i = body[3]
        # the seq byte is the 4th byte of the request (wire = u32 len | cmd u16 | 0x00 | seq | args)
        wire = r.get("request_wire_hex") or ""
        seq = int(r["seq"], 16) if r.get("seq") else (int(wire[14:16], 16) if len(wire) >= 16 else None)
        expect = None if seq is None else (seq | 0x60)
        ok = expect is not None and i == expect
        nak_ok += ok
        nak_bad += not ok
        shapes[frame] = shapes.get(frame, 0) + 1
        if len(nak_rows) < 12:
            nak_rows.append({"cmd_id": r["cmd_id"], "seq": r.get("seq"),
                             "frame_hex": frame, "body_hex": body.hex(),
                             "record_id": "0x%04X" % struct.unpack_from("<H", body, 0)[0],
                             "n": body[2], "i": "0x%02X" % i,
                             "seq_or_0x60": None if expect is None else "0x%02X" % expect,
                             "i_matches_seq_or_0x60": ok})
jdump("decoded/fresh_nak_record.json",
      {"source": "fresh-writefree, all four passes",
       "frame_hex_example": "04000000060000e0",
       "decode": {"length_word": "04 00 00 00 = 4 body bytes",
                  "body": {"id_u16_le": "0x0006", "n_u8": 0, "i_u8": "0xE0 (= seq | 0x60)"},
                  "field_layout_source": ("firmware.md section 8: reply body = id u16, n u8 (item "
                                          "count), i u8 (index), optional t u16, value; the "
                                          "GET_VERSION data record observed in the prior capture is "
                                          "0a 00 06 9d = id 0x000A, n 6, i 0x9d"),
                  "index_byte_observed": ("0xE0..0xFF here = (request seq | 0x60) on every frame; "
                                          "the same field held 0x9d (= the request seq) in the prior "
                                          "capture, so the field is the request index in whatever "
                                          "numbering the session ended up in")},
       "verified": {"nak_frames": nak_ok + nak_bad, "i_equals_seq_or_0x60": nak_ok,
                    "i_differs": nak_bad,
                    "distinct_frame_shapes": len(shapes)},
       "examples": nak_rows,
       "answer_for_comparison": {
           "frame_hex": "080000000500009b00000000",
           "decode": "length 8, id 0x0005, n 0, i 0x9b (= seq), value u32 0x00000000"},
       "interpretation": ("observed pattern only: the NAK carries one index byte that equals the "
                          "request's seq byte with 0x60 OR-ed in, so it is request-indexed, not a "
                          "periodic push. A drain-only wait with no request produced no frame.")})

# compact per-exchange view of the single-connection pass (99 requests)
if PASS["C_single_connection_persistent_buffer"]:
    jdump("decoded/fresh_exchanges_compact.json",
          {"source": "fresh-writefree pass C (raw/session_single_connection.json)",
           "records": [{"id": r.get("cmd_id"), "name": r.get("cmd_name"),
                        "label": r.get("label"), "seq": r.get("seq"),
                        "args_hex": r.get("args_hex"),
                        "request_wire_hex": r.get("request_wire_hex"),
                        "frame_hex": (r.get("frames_hex") or [""])[0],
                        "echo_ok": r.get("header_echo_ok"),
                        "payload_hex": r.get("payload_hex"),
                        "payload_sha256": r.get("payload_sha256"),
                        "t_request": r.get("t_request"), "t_response": r.get("t_response")}
                       for r in PASS["C_single_connection_persistent_buffer"]["exchanges"]]})

# baseline samples (write-free)
baselines = {}
for label, doc in PASS.items():
    if not doc or not doc.get("baseline"):
        continue
    baselines[label] = doc["baseline"]
jdump("decoded/fresh_baseline.json",
      {"source": "fresh-writefree, no device writes", "note": ("only GET_STATUS answered during the "
       "baseline window; the rate/temperature/charger/timestamp VSFR ids returned the 0x0006 NAK "
       "frame in every sample, so they are null here and are quoted from the prior capture in the "
       "report"),
       "baselines": baselines})

# ---------------------------------------------------------------- decoded, prior capture
prior_strings = {}
for vs, rec in PRIOR.get("virtual_strings", {}).items():
    body = bytes.fromhex(rec.get("hex", ""))
    entry = {"vs": vs, "name": rec.get("name"), "declared_size": rec.get("size"),
             "body_bytes": len(body), "raw_hex": rec.get("hex"),
             "body_sha256": sha_bytes(body) if body else None, "kind": "raw_then_decoded"}
    txt = body.split(b"\x00")[0]
    if txt and all(32 <= b < 127 or b in (9, 10, 13) for b in txt):
        entry["text"] = txt.decode("cp1251", "replace")
    if vs == "0x202":
        entry["decoded"] = decode_calib(body)
    if vs == "0x220" and len(body) >= 12:
        entry["decoded"] = dict(zip(("counts", "ms", "us"), struct.unpack_from("<III", body, 0)))
    prior_strings[vs] = entry
jdump("decoded/prior_capture_virtual_strings.json",
      {"source": "prior-repo-capture: pipeline/step2_probe.py, taken "
                 + str(PRIOR.get("taken")), "virtual_strings": prior_strings})

with open(os.path.join(OUT, "decoded", "prior_capture_configuration_text.txt"), "w",
          encoding="utf-8") as fh:
    fh.write(prior_strings.get("0x002", {}).get("text", ""))

jdump("decoded/prior_capture_flash_areas.json",
      {"source": "prior-repo-capture RD_FLASH_AREA 0x081C indexes 0..3, taken "
                 + str(PRIOR.get("taken")), "note": "decoded via protocol.decode_flash_area "
       "(Borland LCG keystream, 8 bits per byte); raw_payload_hex preserved verbatim",
       "areas": PRIOR.get("flash_areas") or {}})

# ---------------------------------------------------------------- identity.json
git_sha = subprocess.run(["git", "-C", ROOT, "rev-parse", "HEAD"],
                         capture_output=True, text=True).stdout.strip()
pip_versions = {}
for pkg in ("bleak", "capstone", "unicorn", "z3-solver", "radiacode"):
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "show", pkg], capture_output=True,
                           text=True)
        for line in r.stdout.splitlines():
            if line.startswith("Version:"):
                pip_versions[pkg] = line.split(":", 1)[1].strip()
    except Exception:  # noqa: BLE001
        pass

fresh_status = [r.get("payload_hex") for lbl, doc in PASS.items()
                for r in (doc or {}).get("exchanges") or []
                if r.get("cmd_id") == "0x0005" and r.get("payload_hex")]
identity = {
    "collected": FRESH["collected"],
    "connected_unit": {
        "model": "RadiaCode-102",
        "model_source_ble_advertisement": "name 'RadiaCode-102#RC-102-008228' "
                                          "(raw/ble_scan.json)",
        "model_source_usb": "iProduct 'RadiaCode-102', iSerialNumber 'RC-102-008228' "
                            "(hardware/usb_and_host_pnp.json)",
        "serial_number": "RC-102-008228",
        "serial_number_sources": ["BLE advertisement name", "USB iSerialNumber",
                                  "prior-capture VS 0x008"],
        "ble_address": "52:43:06:60:20:24",
        "ble_service_uuids": {"service": "e63215e5-7003-49d8-96b0-b024798fb901",
                              "write": "e63215e6-7003-49d8-96b0-b024798fb901",
                              "notify": "e63215e7-7003-49d8-96b0-b024798fb901",
                              "chunk_bytes": 18, "seq_base": 128},
        "usb": {"vid": "0x0483", "pid": "0xF123", "device_release_bcd": "0x0200",
                "instance_id": "USB\\VID_0483&PID_F123\\RC-102-008228",
                "class": "vendor-specific FF/FF/FF (no CDC COM port)",
                "driver": "PHUSBDEV (oem41.inf, Phyton)",
                "endpoints_from_library": ["0x01 OUT", "0x81 IN"]},
        "hardware_serial_record_prior_capture": PRIOR["identity"].get("GET_SERIAL"),
        "hw_config_reply_prior_capture": PRIOR["identity"].get("RD_HW_CONFIG"),
        "application_firmware": {"version": "4.14", "build_stamp": "Jul  7 2025 11:19:22",
                                 "GET_VERSION_raw": PRIOR["identity"]["GET_VERSION"]["hex"],
                                 "decode": "record {u16 minor, u16 major, u8 len, str} twice: "
                                           "boot 4.0 then target 4.14",
                                 "provenance": "prior-repo-capture (GET_VERSION answers only "
                                               "after the documented 0x0007 session write)"},
        "bootloader": {"version": "4.0", "build_stamp": "Feb  6 2023 15:49:14",
                       "provenance": "prior-repo-capture GET_VERSION id 0 + registry "
                                     "devices.json boot field",
                       "freshly_verified": False},
        "firmware_container": {"filename": "rc-102z.bin", "size": 130148,
                               "crc32_whole_file": "0x13095ABB",
                               "date_time_msdos": "0x5AE7428A",
                               "date_time_decoded": "2025-07-07 08:20:20",
                               "buffer_size": 32768, "write_chunk": 4096, "blocks": 8,
                               "header_crc32": "8573b5f0",
                               "sha256_container": sha(os.path.join(TARGET, "rc-102z.bin")),
                               "descriptor_field_RD_SIGNAT_prior":
                                   PRIOR["identity"]["RD_SIGNAT"],
                               "signature_field_note": "0x0101 RD_SIGNAT is an image "
                                                       "descriptor (date_time + file name + "
                                                       "product), not a cryptographic signature"},
        "fresh_read_only_status": {"GET_STATUS_payload_values_observed": sorted(set(fresh_status)),
                                   "GET_STATUS_answer_count": len(fresh_status),
                                   "prior_capture_GET_STATUS": PRIOR["identity"]
                                   ["GET_STATUS"]["hex"],
                                   "note": "mutable field, differs between passes"}},
    "fresh_writefree_passes": pass_summaries,
    "repository": {"url": "https://github.com/darkmatter2222/radiacode-firmware",
                   "commit": git_sha, "registered_target": "rc-102/hw1-fw4.14",
                   "registry_expected": REG["expected"], "registry_mcu": REG["mcu"]},
    "host": {"os": platform.system(), "os_version": platform.version(),
             "release": platform.release(), "python": platform.python_version(),
             "machine": platform.machine(),
             "ble_radio": "Realtek Bluetooth 5.4 Adapter (PnP, hardware/usb_and_host_pnp.json)"},
    "tools": {"pip_versions": pip_versions, "ghidra": "12.2 (per docs/REPRODUCING.md), "
              "JDK 25.0.5+8"},
    "device_writes_issued_in_this_pass": [],
    "unavailable_fields": [
        "bootloader bytes (no read-only memory-read command; 0x000A/0x000B/0x0012/0x0101/0x0807/"
        "0x081C/0x0824/0x0826 return the 0x0006 NAK record without the 0x0007 session write)",
        "battery/charge level (VSFR 0x0000C200 not served in the write-free pass)",
        "MCU DEV_ID / unique id via VSFR 0xFFFF0000+ (not served in the write-free pass)",
        "option bytes / RDP status (no supported read-only path)",
        "uptime: VSFR 0x00000504 not served in the write-free pass",
        "count rate / dose rate / spectrum during the baseline window (0x00008020-0x00008024, "
        "0x00000603 and VS 0x001/0x002/0x003/0x004 all NAK without the session write)",
    ],
}
jdump("identity.json", identity)

# ---------------------------------------------------------------- copy source files
copies = {
    "firmware/rc-102z.bin": os.path.join(TARGET, "rc-102z.bin"),
    "firmware/flash.bin": os.path.join(TARGET, "flash.bin"),
    "firmware/blocks.json": os.path.join(TARGET, "blocks.json"),
    "firmware/manifest.json": os.path.join(TARGET, "manifest.json"),
    "raw/prior_capture.json": os.path.join(TARGET, "analysis", "capture.json"),
    "raw/vsfr_readout_prior.json": os.path.join(TARGET, "analysis", "vsfr_readout.json"),
    "raw/sweep_noarg.json": os.path.join(TARGET, "analysis", "sweep_noarg.json"),
    "raw/sweep_witharg.json": os.path.join(TARGET, "analysis", "sweep_witharg.json"),
    "decoded/analysis_verification.json": os.path.join(TARGET, "analysis", "verification.json"),
    "decoded/analysis_container_check.json": os.path.join(TARGET, "analysis", "container_check.json"),
    "decoded/analysis_roundtrip.json": os.path.join(TARGET, "analysis", "roundtrip.json"),
    "decoded/analysis_crosscheck.json": os.path.join(TARGET, "analysis", "crosscheck.json"),
    "decoded/analysis_differential.json": os.path.join(TARGET, "analysis", "differential.json"),
    "decoded/analysis_formal.json": os.path.join(TARGET, "analysis", "formal.json"),
    "decoded/analysis_confidence.json": os.path.join(TARGET, "analysis", "confidence.json"),
    "decoded/analysis_stats.json": os.path.join(TARGET, "analysis", "stats.json"),
    "decoded/analysis_tables.json": os.path.join(TARGET, "analysis", "tables.json"),
    "decoded/analysis_vectors.json": os.path.join(TARGET, "analysis", "vectors.json"),
    "updater/firmware_md.md": os.path.join(ROOT, "firmware.md"),
}
for rel, src in copies.items():
    if os.path.exists(src):
        os.makedirs(os.path.dirname(os.path.join(OUT, rel)), exist_ok=True)
        shutil.copyfile(src, os.path.join(OUT, rel))

# ---------------------------------------------------------------- manifest + zip
entries = []
for dirpath, dirnames, filenames in os.walk(OUT):
    dirnames.sort()
    for fn in sorted(filenames):
        full = os.path.join(dirpath, fn)
        rel = os.path.relpath(full, OUT).replace("\\", "/")
        if rel.endswith(".zip"):
            continue
        source = ("fresh-writefree" if rel.startswith("raw/") or rel.startswith("decoded/fresh")
                  else "prior-repo-capture" if "prior_capture" in rel else
                  "offline-repo" if rel.startswith(("firmware/", "hardware/",
                                                    "updater/", "scripts/")) else "-")
        entries.append({"path": rel, "bytes": os.path.getsize(full), "sha256": sha(full),
                        "source": source})
with open(os.path.join(OUT, "manifest.json"), "w", encoding="utf-8") as fh:
    json.dump({"generated": FRESH["collected"], "files": entries}, fh, indent=2)

zip_path = os.path.join(OUT, "radiacode-device-evidence.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for e in entries:
        zf.write(os.path.join(OUT, e["path"]), e["path"])
print(json.dumps({
    "files": len(entries),
    "zip_bytes": os.path.getsize(zip_path),
    "passes": {k: {"requests": v["requests"], "data_answers": v["data_answers"],
                   "nak_frames": v["nak_frames"], "no_frame": v["no_frame"]}
               for k, v in pass_summaries.items()},
    "get_status_payloads": sorted(set(fresh_status)),
    "nak_frames_total": nak_ok + nak_bad,
    "nak_i_matches_seq_or_0x60": nak_ok,
}, indent=2))
