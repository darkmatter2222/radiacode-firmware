import io

p = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\REPORT.md"
lines = open(p, encoding="utf-8").read().split("\n")
assert lines[44].startswith("Observed (all frames are in"), lines[44][:40]
assert lines[57].strip().endswith("is labelled as such."), lines[57][-40:]

new = """Observed, consistently (tabulated in `decoded/fresh_writefree_answer_table.json`):

| pass | topology | requests | `0x0005` data answers | `0x0006` NAK frames | no frame |
| --- | --- | --- | --- | --- | --- |
| A `raw/session_reads_writefree.json` | one connection per command | 26 | 1 | 0 | 25 |
| B `raw/session_writefree_v2.json` | connection per section, drain per request | 70 | 4 | 53 | 13 |
| C `raw/session_single_connection.json` | one persistent connection, persistent buffer | 99 | 5 | 94 | 0 |
| D `raw/session_reads.json` | earliest variant, frame bytes not stored | 119 | 0 | 0 | 119 |

* `0x0005 GET_STATUS` is the **only** documented read id that returns a data record without the
  session write: 10 answers in the 195 logged requests of passes A-C, every one with payload
  `00000000` and a correct header echo (`080000000500008000000000`). The prior capture at 12:17:54
  had `02000000`; it is a mutable status word, not an identification field.
* `0x000A`, `0x000B`, `0x0012`, `0x0101`, `0x0807`, `0x081C`, `0x0824`, `0x0826` return the same
  4-byte record every time: on the wire `04000000060000e0`, i.e. body `06 00 00 (seq | 0x60)` =
  record id `0x0006`, `n = 6`, index byte = the request's `seq` with `0x60` OR-ed in. That mapping
  holds on **all 147** NAK frames of the three logged passes (`decoded/fresh_nak_record.json`); in
  pass C the index byte walks `e1, e2, e3, e5, …` with the request counter, so the record is
  request-indexed rather than a periodic push - a drain-only wait with no request produced no frame.
  Its meaning is **not established**; the bytes are recorded as observed.
* The split does not depend on connection topology (fresh connection per command and one persistent
  connection give the same result), so it is a property of the session state, not of the reader. The
  prior capture, which issues `0x0007` + `0x0A04` first, gets full records from the same ids - hence
  the inference (labelled as an inference) that `SET_EXCHANGE` is what arms the record reader. That
  has not been isolated further without writes.
* Every decoded value quoted later in this report therefore comes from the prior capture and is
  labelled as such; the fresh pass contributes the status word, the frame/NAK shapes and the
  transport facts."""
lines[44:58] = new.split("\n")
open(p, "w", encoding="utf-8", newline="\n").write("\n".join(lines))
print("section 2 patched,", len(lines), "lines")
