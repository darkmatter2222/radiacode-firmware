"""Extract the repository's own reviewed findings (firmware.md sections) as UTF-8 excerpts."""

import json
import os
import re

ROOT = r"C:\Users\ryans\source\repos\radiacode"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
for d in ("updater", "hardware", "decoded"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

text = open(os.path.join(ROOT, "firmware.md"), encoding="utf-8").read()
heads = [(m.group(0), m.start()) for m in re.finditer(r"^## \d+\..*$", text, re.M)]

sec = {}
for i, (h, start) in enumerate(heads):
    end = heads[i + 1][1] if i + 1 < len(heads) else len(text)
    sec[h.split(".", 1)[0].strip()] = text[start:end]

want = {
    "updater/firmware_md_update_path.md": ["## 17", "## 18"],
    "hardware/firmware_md_memory_model.md": ["## 2", "## 3", "## 4", "## 23", "## 24"],
    "hardware/firmware_md_identity_capability.md": ["## 1", "## 5", "## 6", "## 14", "## 25"],
    "decoded/firmware_md_protocol_sections.md": ["## 7", "## 8", "## 11", "## 20", "## 21", "## 22"],
}
for path, keys in want.items():
    body = "\n\n".join(sec[k] for k in keys if k in sec)
    with open(os.path.join(OUT, path), "w", encoding="utf-8") as fh:
        fh.write(body + "\n")
    print(path, len(body))

# command-set table as machine-readable pairs
cmds = {}
for m in re.finditer(r"^\|\s*`(0x[0-9A-Fa-f]{4})`?\s*\|\s*([^|]+)\|", sec.get("## 11", ""), re.M):
    cmds[m.group(1)] = m.group(2).strip()
with open(os.path.join(OUT, "decoded", "command_table_from_firmware_md.json"), "w",
          encoding="utf-8") as fh:
    json.dump({"source": "firmware.md SS11 (observed on the live unit)", "commands": cmds},
              fh, indent=2)
print("commands:", len(cmds))
