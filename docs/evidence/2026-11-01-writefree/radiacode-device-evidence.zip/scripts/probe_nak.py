"""Characterisation probe: is the 8-byte `06 00 00 xx` frame a NAK, a late reply, or
an unsolicited event push? Logs every notification arrival with a monotonic timestamp
and issues no writes at all (only read commands 0x0005 / 0x000A / 0x000B).
"""

import asyncio
import json
import struct
import sys

from bleak import BleakClient

sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")

WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = "e63215e7-7003-49d8-96b0-b024798fb901"
ADDRESS = "52:43:06:60:20:24"

LOG = []
T0 = 0.0


def on_notify(handle, data):
    LOG.append({"mono": round(asyncio.get_running_loop().time() - T0, 4),
                "hex": bytes(data).hex()})


async def send(client, cmd, args=b"", seq=0):
    request = struct.pack("<HBB", cmd, 0, 0x80 + seq) + args
    full = struct.pack("<I", len(request)) + request
    for pos in range(0, len(full), 18):
        await client.write_gatt_char(WRITE_UUID, full[pos:pos + 18])
    return full.hex()


async def main():
    global T0
    client = BleakClient(ADDRESS, timeout=10.0)
    await client.connect()
    T0 = asyncio.get_running_loop().time()
    await client.start_notify(NOTIFY_UUID, on_notify)
    timeline = []
    seq = 0
    plan = [
        ("GET_STATUS", 0x0005, b"", 2.0),
        ("GET_VERSION", 0x000A, b"", 3.0),
        ("GET_VERSION_again", 0x000A, b"", 3.0),
        ("drain_only_no_request", None, None, 3.0),
        ("GET_SERIAL", 0x000B, b"", 3.0),
        ("GET_VERSION_third", 0x000A, b"", 3.0),
    ]
    for label, cmd, args, wait in plan:
        start = len(LOG)
        sent = None
        if cmd is not None:
            sent = await send(client, cmd, args, seq)
            seq += 1
        mono = round(asyncio.get_running_loop().time() - T0, 4)
        await asyncio.sleep(wait)
        timeline.append({"label": label, "request_hex": sent, "mono_sent": mono,
                         "notifications_since": LOG[start:]})
    await client.disconnect()
    payload = json.dumps({"all_notifications": LOG, "timeline": timeline}, indent=2)
    out = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\raw\probe_nak_no_session_writes.json"
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(payload)
    print(payload[:1500])


asyncio.run(main())
