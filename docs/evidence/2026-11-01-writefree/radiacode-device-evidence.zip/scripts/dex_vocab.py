"""Vendor SDK vocabulary from the APK's classes.dex: the command/enum names the official
application actually uses, plus any numeric context around them. Primary source, no inference.
"""

import json
import os
import re
import zipfile

ROOT = r"C:\Users\ryans\source\repos\radiacode"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\updater"

PATTERNS = [
    re.compile(rb"^(GET|SET|RD|WR|EVT)_[A-Z0-9_]{2,30}$"),
    re.compile(rb"^FLASH_[A-Z0-9_]{2,30}$"),
    re.compile(rb"^(RECONNECTION|HardSoft)[A-Za-z0-9_/\.]*$"),
]

with zipfile.ZipFile(os.path.join(ROOT, "official", "apk.bin")) as zf:
    dex = zf.read("classes.dex")

found = {}
for s in re.findall(rb"[\x20-\x7e]{2,140}", dex):
    for pat in PATTERNS:
        if pat.match(s):
            found[s.decode()] = found.get(s.decode(), 0) + 1

groups = {"commands": {}, "flash_status_enum": {}, "other": {}}
for k in found:
    if k.startswith("FLASH_"):
        groups["flash_status_enum"][k] = found[k]
    elif k.startswith(("GET_", "SET_", "RD_", "WR_", "EVT_")):
        groups["commands"][k] = found[k]
    else:
        groups["other"][k] = found[k]

# update-related sentences (longer strings that contain a %d or a period)
sentences = [s.decode("latin-1") for s in re.findall(rb"[\x20-\x7e]{10,200}", dex)
             if b"Firmware" in s or b"FW " in s or b"boot device" in s or b"sign" in s.lower()]
out = {"source": "official/apk.bin -> classes.dex, printable-string scan",
       "dex_sha256": None, "counts": {k: len(v) for k, v in groups.items()},
       "commands": sorted(groups["commands"]), "flash_status_enum": sorted(groups["flash_status_enum"]),
       "other": sorted(groups["other"]), "update_sentences": sorted(set(sentences))[:60]}
import hashlib
out["dex_sha256"] = hashlib.sha256(dex).hexdigest()
with open(os.path.join(OUT, "apk_dex_command_vocabulary.json"), "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=2)
print(json.dumps(out, indent=1)[:2500])
