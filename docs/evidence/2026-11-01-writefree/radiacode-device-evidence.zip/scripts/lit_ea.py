import re
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()
BASE = 0x08000000
md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)


def w(a):
    return int.from_bytes(img[a - BASE:a - BASE + 4], "little")


def ea(addr, size, imm):
    # ARMv7-M: PC = instruction address + 8 (T16 and T32 alike)
    return addr + 8 + imm


for lo, hi in ((0x08029370, 0x08029388), (0x08027490, 0x08027518)):
    for ins in md.disasm(img[lo - BASE:hi - BASE], lo):
        m = re.search(r"\[pc, #0x([0-9a-f]+)\]", ins.op_str)
        if m:
            a = ea(ins.address, ins.size, int(m.group(1), 16))
            print("ins %08x  %s %s  ->  EA 0x%08X = 0x%08X" %
                  (ins.address, ins.mnemonic, ins.op_str, a, w(a)))
print("pool dump 0x08027D90-0x08027DD4:")
for a in range(0x08027D90, 0x08027DD4, 4):
    print("  %08X 0x%08X" % (a, w(a)))
