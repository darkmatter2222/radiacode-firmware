"""Refresh the repo-side evidence: documented test command, release gate, layer numbers."""
import json
import os
import subprocess
import sys

REPO = r"C:\Users\ryans\source\repos\radiacode"
STAGE = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
AN = os.path.join(REPO, "firmware", "rc-102", "hw1-fw4.14", "analysis")


def run(cmd):
    r = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, encoding="utf-8")
    return r.returncode, (r.stdout or "") + (r.stderr or "")


# 1. the documented validator test command
code, out = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
with open(os.path.join(STAGE, "updater", "repo_unit_tests.txt"), "w", encoding="utf-8",
          newline="\n") as fh:
    fh.write("$ python -m unittest discover -s tests -v\n")
    fh.write("# exit code: %d\n" % code)
    fh.write(out)

# 2. the release gate (fail-closed, expects 2 = evidence missing)
gate_code, gate_out = run([sys.executable, "pipeline/release_gate.py"])
with open(os.path.join(STAGE, "updater", "release_gate.txt"), "w", encoding="utf-8",
          newline="\n") as fh:
    fh.write("$ python pipeline/release_gate.py\n# exit code: %d\n" % gate_code)
    fh.write(gate_out)

# 3. numbers straight out of the current analysis JSON
def j(name):
    return json.load(open(os.path.join(AN, name), encoding="utf-8"))


diff, formal, conf, stats, rt, cc = (j("differential.json"), j("formal.json"), j("confidence.json"),
                                     j("stats.json"), j("roundtrip.json"), j("crosscheck.json"))
summary = {
    "release_gate": {"command": "python pipeline/release_gate.py", "exit_code": gate_code,
                     "stdout_first_lines": gate_out.strip().splitlines()[:6]},
    "unittest": {"command": "python -m unittest discover -s tests -v", "exit_code": code,
                 "tail": out.strip().splitlines()[-4:]},
    "differential": {"cases": len(diff.get("cases", [])),
                     "cases_passed": sum(1 for c in diff.get("cases", []) if c.get("r0_match")),
                     "instruction_budget_or_faults": [c.get("name") for c in diff.get("cases", [])
                                                      if c.get("fault") or c.get("budget_exhausted")],
                     "format_vectors": diff.get("format", {}).get("vectors")
                     if isinstance(diff.get("format"), dict) else None,
                     "applicability": diff.get("applicability") or diff.get("image_sha256")},
    "formal": {"checks": len(formal.get("checks", [])), "proved": formal.get("proved"),
               "counterexamples": formal.get("counterexamples"), "unknown": formal.get("unknown")},
    "confidence_categories": {k: v for k, v in (conf.get("categories") or {}).items()},
    "confidence_unresolved": len(conf.get("unresolved") or []),
    "stats": {k: stats.get(k) for k in ("instructions", "functions", "strings", "listing_lines",
                                        "unclassified_bytes")},
    "roundtrip_byte_exact": rt.get("byte_exact"),
    "crosscheck_agreement": cc.get("agreement"),
}
with open(os.path.join(STAGE, "updater", "repo_layer_status.json"), "w", encoding="utf-8") as fh:
    json.dump(summary, fh, indent=2, ensure_ascii=False)
print(json.dumps(summary, indent=2, ensure_ascii=False)[:2400])
