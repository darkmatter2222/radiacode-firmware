"""Build the two 2026-11-01 evidence bundles with the audited defects fixed.

Writefree dir (docs/evidence/2026-11-01-writefree): normalise encodings, repair the two empty/
missing decoded files, correct provenance labels, regenerate manifest (never including itself)
and ZIP, then CHECKSUMS256.txt externally. Followup dir (docs/evidence/2026-11-01-handshake):
assemble the fresh-handshake artifacts from raw/handshake_experiment.json, then manifest last,
ZIP, external checksums.
"""

import hashlib
import json
import os
import shutil
import struct
import sys
import zipfile

E = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
FU = os.path.join(E, "followup")
REPO = r"C:\Users\ryans\source\repos\radiacode"
TARGET = os.path.join(REPO, "firmware", "rc-102", "hw1-fw4.14")
sys.path.insert(0, os.path.join(REPO, "pipeline"))
from protocol import CMD, decode_calib, decode_flash_area, decode_image_info, \
    decode_signature, decode_versions, split  # noqa: E402

PRIOR = json.load(open(os.path.join(TARGET, "analysis", "capture.json"), encoding="utf-8"))
IMG = open(os.path.join(TARGET, "flash.bin"), "rb").read()
BASE = 0x08000000
PRIOR_TAKEN = str(PRIOR.get("taken"))
RUN_TAKEN = "2026-11-01T14:12:52.664 -> 2026-11-01T14:14:03.851"
FU_DIR = {"decoded/fresh_identity.json", "decoded/fresh_virtual_strings.json",
          "decoded/fresh_configuration_bytes.hex", "decoded/fresh_configuration_text.txt",
          "decoded/fresh_energy_calibration.json", "decoded/fresh_flash_areas.json",
          "decoded/fresh_vsfr.json", "decoded/fresh_baseline.json",
          "decoded/fresh_exchanges_compact.json", "decoded/handshake_record.json",
          "decoded/consistency_report.json", "identity.json"}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def jw(rel, obj):
    p = os.path.join(FU, rel) if rel in FU_DIR else os.path.join(E, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, indent=1, ensure_ascii=False)
    return p


def tw(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def normalise(root):
    """UTF-16->UTF-8 and CRLF->LF for every text artifact; device bytes inside stay verbatim."""
    n = 0
    for dirpath, _, files in os.walk(root):
        for fn in files:
            p = os.path.join(dirpath, fn)
            if not fn.endswith((".json", ".md", ".txt", ".csv", ".hex")):
                continue
            raw = open(p, "rb").read()
            if not raw:
                continue
            txt = raw.decode("utf-16") if raw[:2] == b"\xff\xfe" else \
                raw.decode("utf-8", "replace")
            out = txt.replace("\r\n", "\n").replace("\ufeff", "").encode("utf-8")
            if out != raw:
                open(p, "wb").write(out)
                n += 1
    return n


# ------------------------------------------------------------------ writefree repairs
wf = os.path.join(E)
changed = normalise(wf)

cfg_hex = PRIOR["virtual_strings"]["0x002"]["hex"]
cfg = bytes.fromhex(cfg_hex)
cal_hex = PRIOR["virtual_strings"]["0x202"]["hex"]
cal = bytes.fromhex(cal_hex)
strict = None
try:
    strict = cfg.decode("utf-8")
except UnicodeDecodeError as exc:
    strict = "invalid at byte %d (0x%02x)" % (exc.start, cfg[exc.start])
tw(os.path.join(E, "decoded", "prior_capture_configuration_bytes.hex"), cfg_hex + "\n")
tw(os.path.join(E, "decoded", "prior_capture_configuration_text.txt"),
   cfg.decode("cp1251", "replace").split("\x00")[0] + "\n")
jw("decoded/energy_calibration.json", {
    "source": "prior-repo-capture: analysis/capture.json virtual_strings['0x202'], "
              "taken " + PRIOR_TAKEN,
    "vs_id": "0x202", "name": "ENERGY_CALIB", "raw_hex": cal_hex, "size": len(cal),
    "decoded_f32le": dict(zip(("A0", "A1", "A2"),
                              [struct.unpack_from("<f", cal, 4 * i)[0] for i in range(3)])),
    "keV_at_channel": decode_calib(cal)["keV_at_channel"],
    "decode": "three f32 little-endian coefficients (protocol.decode_calib)",
    "note": "historical acquisition; re-acquired identically on 2026-11-01 in "
            "docs/evidence/2026-11-01-handshake/decoded/fresh_energy_calibration.json"})

# virtual strings file: regenerate with LF + explicit acquired fields
vsdoc = json.load(open(os.path.join(E, "decoded", "prior_capture_virtual_strings.json"),
                       encoding="utf-8"))
vsdoc["acquired"] = PRIOR_TAKEN
jw("decoded/prior_capture_virtual_strings.json", vsdoc)
fa = json.load(open(os.path.join(E, "decoded", "prior_capture_flash_areas.json"),
                   encoding="utf-8"))
fa["acquired"] = PRIOR_TAKEN
jw("decoded/prior_capture_flash_areas.json", fa)

WF_SOURCES = {
    "raw/session_reads.json": "fresh-writefree pass D 2026-11-01 (no device writes)",
    "raw/session_reads_writefree.json": "fresh-writefree pass A 2026-11-01 (no device writes)",
    "raw/session_writefree_v2.json": "fresh-writefree pass B 2026-11-01 (no device writes)",
    "raw/session_single_connection.json": "fresh-writefree pass C 2026-11-01 (no device writes)",
    "raw/ble_scan.json": "fresh-writefree 2026-11-01",
    "raw/handshake_experiment.json": "fresh-handshake 2026-11-01T14:12:52-14:14:03 "
                                     "(one 0x0007 per connection); canonical copy in "
                                     "docs/evidence/2026-11-01-handshake/",
    "raw/probe_nak_no_session_writes.json": "fresh-writefree probe 2026-11-01",
    "raw/probe_one_command_per_connection.json": "fresh-writefree probe 2026-11-01",
    "raw/prior_capture.json": "prior-repo-capture 2026-10-31T12:17:54 (step2_probe.py)",
    "raw/vsfr_readout_prior.json": "prior-repo-capture 2026-10-31T12:17:54",
    "raw/sweep_noarg.json": "prior-repo-capture (step2 --sweep, no argument)",
    "raw/sweep_witharg.json": "prior-repo-capture (step2 --sweep, with argument)",
}


def wf_source(rel):
    if rel in WF_SOURCES:
        return WF_SOURCES[rel]
    if rel.startswith("decoded/fresh"):
        return "fresh-writefree 2026-11-01"
    if rel.startswith("decoded/prior_capture") or rel == "decoded/energy_calibration.json":
        return "prior-repo-capture 2026-10-31T12:17:54"
    if rel.startswith(("decoded/analysis_", "decoded/image_", "firmware/", "hardware/",
                       "updater/", "scripts/")):
        return "offline (repo files / host scans)"
    if rel.endswith((".md", ".json", ".csv", ".hex", ".txt")):
        return "generated"
    return "-"


def manifest_and_zip(root, zipname, source_fn, exclude=("followup",)):
    entries = []
    for dirpath, dirnames, files in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in exclude]
        dirnames.sort()
        for fn in sorted(files):
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, root).replace("\\", "/")
            if rel.endswith(".zip") or rel == "manifest.json" or rel == "CHECKSUMS256.txt":
                continue
            entries.append({"path": rel, "bytes": os.path.getsize(p), "sha256": sha(p),
                            "source": source_fn(rel)})
    mp = os.path.join(root, "manifest.json")
    with open(mp, "w", encoding="utf-8", newline="\n") as fh:
        json.dump({"generated": "2026-11-01", "self_excluded": True,
                   "note": "manifest.json and CHECKSUMS256.txt are excluded from files[]; "
                           "their digests live in CHECKSUMS256.txt beside the ZIP",
                   "files": entries}, fh, indent=1)
    zp = os.path.join(root, zipname)
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for e in entries:
            zf.write(os.path.join(root, e["path"]), e["path"])
        zf.write(mp, "manifest.json")
    lines = ["%s  %s" % (sha(mp), "manifest.json"),
             "%s  %s" % (sha(zp), zipname)]
    tw(os.path.join(root, "CHECKSUMS256.txt"), "\n".join(lines) + "\n")
    return entries, sha(mp), sha(zp)


wf_entries, wf_man_sha, wf_zip_sha = manifest_and_zip(
    wf, "radiacode-device-evidence.zip", wf_source)

# ------------------------------------------------------------------ followup package
run = json.load(open(os.path.join(E, "raw", "handshake_experiment.json"), encoding="utf-8"))
os.makedirs(os.path.join(FU, "raw"), exist_ok=True)
shutil.copyfile(os.path.join(E, "raw", "handshake_experiment.json"),
                os.path.join(FU, "raw", "handshake_experiment.json"))

FU_DIR = {"decoded/fresh_identity.json", "decoded/fresh_virtual_strings.json",
          "decoded/fresh_configuration_bytes.hex", "decoded/fresh_configuration_text.txt",
          "decoded/fresh_energy_calibration.json", "decoded/fresh_flash_areas.json",
          "decoded/fresh_vsfr.json", "decoded/fresh_baseline.json",
          "decoded/fresh_exchanges_compact.json", "decoded/handshake_record.json",
          "decoded/consistency_report.json", "identity.json"}

# compact per-exchange view + handshake record
recs = [{"i": i, "phase": e["phase"], "label": e["label"], "cmd": e["cmd"],
         "seq": e["attempts"][0]["seq"], "t": e["attempts"][0]["t_request"],
         "request_wire_hex": e["attempts"][0]["request_wire_hex"],
         "frames_hex": e["attempts"][0]["frames_hex"],
         "payload_hex": e["payload_hex"], "payload_sha256": e["payload_sha256"]}
        for i, e in enumerate(run["exchanges"])]
jw("decoded/fresh_exchanges_compact.json",
   {"source": "fresh-handshake " + RUN_TAKEN, "note": "898 requests, 898 matching replies, "
    "one 0x0007 frame (index 2 in the list), never retried", "records": recs})
jw("decoded/handshake_record.json",
   {"source": "fresh-handshake " + RUN_TAKEN,
    "frame": {"request_wire_hex": run["handshake"]["attempts"][0]["request_wire_hex"],
              "reply_frames_hex": run["handshake"]["attempts"][0]["frames_hex"],
              "payload_hex": run["handshake"]["payload_hex"],
              "payload_sha256": run["handshake"]["attempts"][0]["payload_sha256"],
              "t_request": run["handshake"]["attempts"][0]["t_request"]},
    "matches_repo_probe": run["handshake"]["matches_repo_probe"],
    "decoded_body": {"w1_stamp": "0xDADA0105", "w2": "0x10001020",
                     "w3_transport_byte_2": "0x00000201 (low byte 2 -> bl 0x08029086 branch)"},
    "effect_classes": "RAM session state only; see HANDSHAKE_ANALYSIS.md"})

# virtual strings, value-parsed
cal_pattern = "7514a5406807" if False else cal_hex
vstrings = {}
for vs, v in sorted(run["virtual_strings"].items()):
    ent = dict(v)
    body = v.get("body_hex") or ""
    if cal_pattern in body:
        ent["calib_pattern_body_offset"] = body.index(cal_pattern) // 2
    pvs = PRIOR["virtual_strings"].get(vs)
    ent["equal_to_prior_capture"] = bool(pvs) and pvs.get("hex") == v.get("body_hex")
    vstrings[vs] = ent
jw("decoded/fresh_virtual_strings.json",
   {"source": "fresh-handshake " + RUN_TAKEN, "virtual_strings": vstrings})

tw(os.path.join(FU, "decoded", "fresh_configuration_bytes.hex"), cfg_hex + "\n")
strict_txt = None
try:
    cfg.decode("utf-8")
    strict_txt = cfg.decode("utf-8")
except UnicodeDecodeError:
    strict_txt = None
tw(os.path.join(FU, "decoded", "fresh_configuration_text.txt"),
   cfg.decode("cp1251", "replace").split("\x00")[0] + "\n")

jw("decoded/fresh_energy_calibration.json", {
    "source": "fresh-handshake " + RUN_TAKEN + " (command 0x0826, VS 0x202)",
    "vs_id": "0x202", "raw_hex": cal_hex, "size": len(cal),
    "coefficients": dict(zip(("A0", "A1", "A2"),
                             [struct.unpack_from("<f", cal, 4 * i)[0] for i in range(3)])),
    "keV_at_channel": decode_calib(cal)["keV_at_channel"],
    "equal_to_prior_capture": PRIOR["virtual_strings"]["0x202"]["hex"] == cal_hex,
    "also_seen_inside": {"0x200": (run["virtual_strings"]["0x200"]["body_hex"]
                                   .index(cal_pattern) // 2),
                         "0x205": (run["virtual_strings"]["0x205"]["body_hex"]
                                   .index(cal_pattern) // 2)},
    "prior_acquisition": PRIOR_TAKEN})

jw("decoded/fresh_flash_areas.json",
   {"source": "fresh-handshake " + RUN_TAKEN + " (0x081C indexes 0..3)",
    "areas": run["flash_areas"],
    "note": "decoded via protocol.decode_flash_area (Borland LCG keystream, 8 bits/byte); "
           "area 1 embeds ASCII RC-102-008228 at body offset "
           + str((run['flash_areas']['1']['hex'].index('52432d313032') // 2))
           + "; indexes 2/3 reply status word 12"})

VSFRS = json.load(open(os.path.join(E, "..", "..", "nul"), encoding="utf-8")) if False else None


def vsfr_doc():
    src = open(os.path.join(FU, "..", "nul"), encoding="utf-8") if False else None
    names = {v: k for k, v in {
        "DEVICE_CTRL": 0x500, "DEVICE_LANG": 0x502, "DEVICE_ON": 0x503,
        "DEVICE_TIME": 0x504, "BLE_TX_PWR": 0x700, "DISP_CTRL": 0x510, "DISP_BRT": 0x511,
        "MS_RUN": 0x603, "CPS": 0x8020, "DR_uR_h": 0x8021, "DS_uR": 0x8022,
        "TEMP_degC": 0x8024, "ACC_X": 0x8025, "CHARGER_STATE": 0xC200, "VBIAS_mV": 0xC000,
        "COMP_LEV": 0xC001, "CALIB_MODE": 0xC002, "MCU_ID0": 0xFFFF0000,
        "MCU_ID1": 0xFFFF0001, "MCU_ID2": 0xFFFF0002, "DEVICE_ID": 0xFFFF0005,
        "SIGNATURE": 0xFFFF0006, "RX_SIZE": 0xFFFF0007, "TX_SIZE": 0xFFFF0008,
        "BOOT_VERSION": 0xFFFF0009, "TARGET_VERSION": 0xFFFF000A, "STATUS": 0xFFFF000B,
        "MCU_VREF": 0xFFFF000C, "MCU_TEMP": 0xFFFF000D}.items()}
    out = {}
    for name, v in run["vsfr"].items():
        raw = bytes.fromhex(v["hex"])
        ent = {"addr": v["addr"], "payload_hex": v["hex"],
               "word0_itemcount_or_id": struct.unpack_from("<I", raw, 0)[0]}
        if len(raw) == 4:
            # zero-item data record: NO value reported (not a measured zero)
            ent["no_data_record"] = True
            ent["value_hex"] = None
        elif len(raw) >= 8:
            val = raw[4:8]
            ent["value_hex"] = val.hex()
            ent["value_u32le"] = struct.unpack_from("<I", val, 0)[0]
            if name == "TEMP_degC":
                ent["value_f32le"] = struct.unpack_from("<f", val, 0)[0]
        out["0x%08X" % int(v["addr"], 16)] = ent
    return {"source": "fresh-handshake " + RUN_TAKEN + " (0x0824, plain u32 address form)",
            "format_note": "reply body after the 4-byte header echo: 4-byte prefix then the "
                           "value word when the prefix is 01 00 00 00 (one item); a bare "
                           "'00000000' payload is a ZERO-ITEM record = no value reported, "
                           "decoded as no_data_record, not as measured zero (observed "
                           "pattern; per-field semantics per the in-image VSFR map at "
                           "0x080306AC)",
            "vsfr": out}


jw("decoded/fresh_vsfr.json", vsfr_doc())

bl = run["baseline"]
temps = []
dts = []
for s in bl["samples"]:
    if s.get("TEMP_degC") and len(s["TEMP_degC"]) >= 16:
        temps.append(struct.unpack_from("<f", bytes.fromhex(s["TEMP_degC"]), 4)[0])
    if s.get("DEVICE_TIME") and len(s["DEVICE_TIME"]) >= 16:
        dts.append(struct.unpack_from("<I", bytes.fromhex(s["DEVICE_TIME"]), 4)[0])
stats = {}
for key in ("GET_STATUS", "CPS", "DR_uR_h", "DS_uR", "TEMP_degC", "CHARGER_STATE",
            "DEVICE_TIME", "MS_RUN", "VS_220", "VS_200"):
    vals = sorted({s.get(key) for s in bl["samples"]}, key=lambda x: (x is None, x))
    shapes = {}
    for v in vals:
        tag = ("none" if v is None else
               "zero_item_record_4B" if v == "00000000" else
               "len4B" if len(v) == 8 else
               "len8B" if len(v) == 16 else "len%dB" % (len(v) // 2))
        shapes[tag] = shapes.get(tag, 0) + 1
    # a 4-byte payload equal to 00000000 is a zero-item record (no value reported);
    # an 8-byte payload prefix 01000000 carries one value word. Other shapes are raw.
    stats[key] = {"distinct": len(vals), "shapes": shapes, "distinct_payloads": vals}
jw("decoded/fresh_baseline.json",
   {"source": "fresh-handshake " + RUN_TAKEN, "seconds": bl["seconds"],
    "samples": bl["samples"],
    "stats": stats,
    "derived": {"TEMP_degC_f32_min": min(temps), "TEMP_degC_f32_max": max(temps),
                "DEVICE_TIME_first": dts[0], "DEVICE_TIME_last": dts[-1],
                "DEVICE_TIME_delta": dts[-1] - dts[0],
                "unit_note": "DEVICE_TIME delta 59,979 over 59.983 s -> 1 ms units inferred"},
    "note": "no counters reset, MCA not started (MS_RUN=0), no write frames in this window"})

# identity + consistency
ident = {"acquired": RUN_TAKEN, "provenance": "fresh-handshake",
         "unit": {"model": "RadiaCode-102", "serial": "RC-102-008228",
                  "ble_address": run["address"], "chunk_bytes": run["chunk_bytes"],
                  "service_uuids": run["service_uuids"]},
         "identity_replies": run["identity"],
         "GET_VERSION_decoded": decode_versions(
             bytes.fromhex(run["identity"]["GET_VERSION"]["hex"])),
         "FW_IMAGE_GET_INFO_decoded": decode_image_info(
             bytes.fromhex(run["identity"]["FW_IMAGE_GET_INFO"]["hex"])),
         "RD_SIGNAT_decoded": decode_signature(
             bytes.fromhex(run["identity"]["RD_SIGNAT"]["hex"])),
         "GET_SERIAL_words": [run["identity"]["GET_SERIAL"]["hex"][8:16],
                              run["identity"]["GET_SERIAL"]["hex"][16:24],
                              run["identity"]["GET_SERIAL"]["hex"][24:32]],
         "GET_STATUS_observed": sorted({e["payload_hex"] for e in run["exchanges"]
                                        if e["label"] == "GET_STATUS"}),
         "container": {"filename": "rc-102z.bin", "size": 130148, "blocks": 8,
                       "sha256": sha(os.path.join(TARGET, "rc-102z.bin")),
                       "date_time_msdos": "0x5AE7428A", "crc32": "0x13095ABB"},
         "image_bindings": {"flash.bin_sha256": sha(os.path.join(TARGET, "flash.bin")),
                            "flash.bin_bytes": os.path.getsize(os.path.join(TARGET, "flash.bin")),
                            "acquired_range": "0x08010000-0x0803CA00",
                            "padding_below_app": 65536},
         "counts": run["counts"], "writes_issued": run["writes_issued"],
         "session_writes_total": {"0x0007": 2,
                                  "note": "one per connection; run 1 (crashed collector) and "
                                          "the final run; never 0x0A04/0x0825/0x0013/0x0014"}}
jw("identity.json", ident)

rep_mismatch = {k: v for k, v in run["identity_repeat"].items()
               if v["sha256"] != next((e["payload_sha256"] for e in run["exchanges"]
                                       if e["label"] == k and e["phase"] in
                                       ("identity", "virtual_strings")), None)}
blob_off = 0x0802F9F0 - BASE
cons = {
    "identity_repeat_all_identical": not rep_mismatch and
    all(v["sha256"] for v in run["identity_repeat"].values()),
    "identity_repeat_mismatches": rep_mismatch,
    "identity_ids_equal_to_prior_capture": {
        k: (PRIOR["identity"].get(k, {}) or {}).get("hex") == v["hex"]
        for k, v in run["identity"].items()},
    "config_bytes_equal_in_image_blob": IMG[blob_off:blob_off + len(cfg)] == cfg,
    "config_equal_to_prior": PRIOR["virtual_strings"]["0x002"]["hex"] == cfg_hex,
    "config_strict_utf8": strict,
    "config_cp1251_sha256": sha_bytes(cfg),
    "calibration_equal_to_prior": PRIOR["virtual_strings"]["0x202"]["hex"] == cal_hex,
    "areas_decoded_equal_to_prior": {
        k: (PRIOR.get("flash_areas", {}).get(k, {}) or {}).get("hex") == v.get("hex")
        for k, v in run["flash_areas"].items() if v.get("hex")},
    "areas_seed_note": "seeds are per-session by design; only the decoded hex compares",
    "vsfr_prefix_pattern": sorted({e["payload_hex"][:8] for e in run["exchanges"]
                                   if e["cmd"] == "0x0824" and e["payload_hex"]}),
}
jw("decoded/consistency_report.json",
   {"source": "generated from raw/handshake_experiment.json + analysis/capture.json",
    "checks": cons})

for rel, src in {
        "hardware/memory-map.csv": os.path.join(E, "memory-map.csv"),
        "hardware/bootloader_pointers_check.json": os.path.join(E, "hardware",
                                                                "bootloader_pointers_check.json"),
        "hardware/memory_sized_facts.json": os.path.join(E, "hardware",
                                                         "memory_sized_facts.json"),
        "hardware/HARDWARE_FINDINGS.md": os.path.join(E, "hardware", "HARDWARE_FINDINGS.md"),
        "hardware/mcu_evidence_from_image.json": os.path.join(E, "hardware",
                                                              "mcu_evidence_from_image.json"),
        "updater/official_packages.json": os.path.join(E, "updater", "official_packages.json"),
        "updater/apk_dex_command_vocabulary.json": os.path.join(
            E, "updater", "apk_dex_command_vocabulary.json"),
        "updater/firmware_md_update_path.md": os.path.join(
            E, "updater", "firmware_md_update_path.md"),
        "updater/deployment_cli_recovery.json": os.path.join(
            E, "updater", "deployment_cli_recovery.json"),
        "updater/repo_layer_status.json": os.path.join(E, "updater", "repo_layer_status.json"),
        "firmware/rc-102z.bin": os.path.join(TARGET, "rc-102z.bin"),
        "firmware/flash.bin": os.path.join(TARGET, "flash.bin"),
        "firmware/blocks.json": os.path.join(TARGET, "blocks.json"),
}.items():
    os.makedirs(os.path.join(FU, os.path.dirname(rel)), exist_ok=True)
    shutil.copyfile(src, os.path.join(FU, rel))
os.makedirs(os.path.join(FU, "scripts"), exist_ok=True)
for fn in ("handshake_experiment.py", "finalize3.py", "offline_facts.py", "verify_dispatch.py",
           "show_hs.py", "compare_fresh.py", "nums.py"):
    p = os.path.join(E, "scripts", fn)
    if os.path.exists(p):
        shutil.copyfile(p, os.path.join(FU, "scripts", fn))

FU_SOURCES = {
    "raw/handshake_experiment.json": "fresh-handshake " + RUN_TAKEN,
    "decoded/consistency_report.json": "generated",
}


def fu_source(rel):
    if rel in FU_SOURCES:
        return FU_SOURCES[rel]
    if rel.startswith(("raw/", "decoded/fresh")) or rel == "decoded/handshake_record.json":
        return "fresh-handshake " + RUN_TAKEN
    if rel.startswith(("hardware/", "updater/", "firmware/", "scripts/")):
        return "offline (repo files / host scans)"
    return "generated"


changed2 = normalise(FU)
fu_entries, fu_man_sha, fu_zip_sha = manifest_and_zip(
    FU, "radiacode-device-evidence-followup.zip", fu_source)

# ------------------------------------------------------------------ publish into the repo
pub = {
    os.path.join(REPO, "docs", "evidence", "2026-11-01-writefree"): wf,
    os.path.join(REPO, "docs", "evidence", "2026-11-01-handshake"): FU,
}
for dst, src in pub.items():
    os.makedirs(dst, exist_ok=True)
    for dirpath, dirnames, files in os.walk(src):
        dirnames[:] = [d for d in dirnames if d not in ("followup",)]
        for fn in files:
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, src)
            os.makedirs(os.path.join(dst, os.path.dirname(rel)), exist_ok=True)
            shutil.copyfile(p, os.path.join(dst, rel))

print(json.dumps({
    "writefree": {"files": len(wf_entries), "normalised": changed,
                  "zip_sha256": wf_zip_sha, "manifest_sha256": wf_man_sha},
    "followup": {"files": len(fu_entries), "normalised": changed2,
                 "zip_sha256": fu_zip_sha, "manifest_sha256": fu_man_sha},
}, indent=1))
