"""Hardware/MCU identification evidence taken from the acquired application image only.

Everything here is a count or an address list computed from firmware/rc-102/hw1-fw4.14/flash.bin
plus the repository's vectors/strings analysis; interpretation is labelled.
"""

import json
import os
import re
import struct

ROOT = r"C:\Users\ryans\source\repos\radiacode"
TARGET = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14")
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\hardware"
os.makedirs(OUT, exist_ok=True)

img = open(os.path.join(TARGET, "flash.bin"), "rb").read()
BASE = 0x08000000
out = {}

# 1. vector table as acquired
vec = json.load(open(os.path.join(TARGET, "analysis", "vectors.json"), encoding="utf-8"))
out["vector_table"] = {"vtor_claimed": vec.get("vtor"), "count_claimed": vec.get("count"),
                       "entries_sample": (vec.get("entries") or [])[:16],
                       "distinct_targets": sorted({e.get("target") for e in vec["entries"]})
                       if isinstance(vec.get("entries"), list) and vec["entries"]
                       and isinstance(vec["entries"][0], dict) else None}

# 2. literals in the image grouped by address class
ranges = {
    "bootloader_region_0x08000000_0x0800FFFF": (0x08000000, 0x08010000),
    "application_region_0x08010000_0x0803CA00": (0x08010000, 0x0803CA01),
    "sram_0x20000000_0x2002FFFF": (0x20000000, 0x20030000),
    "peripheral_0x40000000_0x4013FFFF": (0x40000000, 0x40140000),
    "system_memory_0x1FFF0000_0x1FFFFFFF": (0x1FFF0000, 0x20000000),
    "systick_ppm_0xE000E000_0xE004FFFF": (0xE000E000, 0xE0050000),
}
counts = {k: 0 for k in ranges}
first_seen = {}
for off in range(0x10000, len(img) - 3, 4):
    w = struct.unpack_from("<I", img, off)[0]
    for name, (lo, hi) in ranges.items():
        if lo <= w < hi:
            counts[name] += 1
            if name not in first_seen:
                first_seen[name] = []
            if len(first_seen[name]) < 40 and (name != "application_region_0x08010000_0x0803CA00"
                                               or len(first_seen[name]) < 12):
                first_seen[name].append({"at": "0x%08X" % (BASE + off), "value": hex(w)})
out["word_literals_by_range"] = {"counts": counts, "examples": first_seen}

# 3. specific landmarks worth naming
def find_bytes(pattern, limit=8):
    return ["0x%08X" % (BASE + m) for m in
            [i for i in range(len(img)) if img[i:i + len(pattern)] == pattern][:limit]]


out["constants"] = {
    "AIRCR_0x05FA0004": find_bytes(struct.pack("<I", 0x05FA0004)),
    "VTOR_value_0x08010000": find_bytes(struct.pack("<I", 0x08010000), 6),
    "sign_0xFF12FF01": find_bytes(struct.pack("<I", 0xFF12FF01), 6),
    "crc_poly_0x04C11DB7": find_bytes(struct.pack("<I", 0x04C11DB7), 6),
    "unique_device_id_base_0x1FFF7590": find_bytes(struct.pack("<I", 0x1FFF7590), 6),
    "devicecode_reg_0x1FFF75E0": find_bytes(struct.pack("<I", 0x1FFF75E0), 6),
    "flash_base_0x40023C00": find_bytes(struct.pack("<I", 0x40023C00), 6),
    "initial_sp_0x20000800": find_bytes(struct.pack("<I", 0x20000800), 6),
}

# 4. highest used addresses (image end, RAM extent from the index)
stats = json.load(open(os.path.join(TARGET, "analysis", "stats.json"), encoding="utf-8"))
out["image"] = {"sha256": stats.get("image_sha256"), "bytes": stats.get("image_bytes"),
                "base": stats.get("base"), "end": stats.get("end"),
                "instructions": stats.get("instructions"),
                "functions": stats.get("functions"), "strings": stats.get("strings")}

# 5. peripheral names actually present as text in the image
strings = json.load(open(os.path.join(TARGET, "analysis", "strings.json"), encoding="utf-8"))
vals = strings if isinstance(strings, list) else (strings.get("strings") or [])
flat = []
for s in vals:
    if isinstance(s, dict):
        flat.append((s.get("address") or s.get("addr"), s.get("value") or s.get("text") or ""))
    else:
        flat.append((None, str(s)))
pat = re.compile(r"^(LPUART\d|LPTIM\d|QUADSPI|DMA2D|JPEG|LCD|FMC|QSPI|SAI\d|CAMERI|AES|"
                 r"RNG|COMP|USB|SPI\d|I2C\d|USART\d|TIM\d)$")
periph = sorted({v for _, v in flat if pat.match(v.strip())})
out["peripheral_names_in_image"] = periph
out["strings_total"] = len(flat)
out["strings_matching_part"] = sorted({v for _, v in flat
                                       if re.search(r"STM32|L4\d\d|Phyton|RadiaCode", v)})[:40]

with open(os.path.join(OUT, "mcu_evidence_from_image.json"), "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=2)
print(json.dumps({k: out[k] for k in ("image", "word_literals_by_range", "constants",
                                      "peripheral_names_in_image", "strings_matching_part")},
                 indent=2)[:3500])
