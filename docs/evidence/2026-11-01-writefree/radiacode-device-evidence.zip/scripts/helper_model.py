import sys
sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
import emulate

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()


def call(s_byte, t):
    uc, trace = emulate.new_emulator(img)
    emulate.preset(uc, [(0x080293FC, (0x2000E000).to_bytes(4, "little")),
                        (0x2000E00D, bytes([s_byte]))])
    r = emulate.run_function(uc, trace, 0x08029370 | 1, args=(t, 0, 0, 0))
    return r["r0"], r["stopped"], len(trace.writes)


for s, t, why in ((0xA1, 0xA1, "T==S"), (0xA2, 0xA1, "T!=S"), (0x00, 0x55, "S==0"),
                  (2, 2, "S=2,T=2"), (2, 0, "S=2,T=0"), (0, 0, "S=0,T=0")):
    r0, st, w = call(s, t)
    print("S=0x%02X T=0x%02X (%s): r0=0x%08X %s writes=%d" % (s, t, why, r0, st, w))
