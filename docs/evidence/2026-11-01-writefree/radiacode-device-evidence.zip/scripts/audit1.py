import json
import os

D = r"C:\Users\ryans\source\repos\radiacode\docs\evidence\2026-11-01-writefree"
ST = D  # unzipped copies live here too
repo = r"C:\Users\ryans\source\repos\radiacode"
an = os.path.join(repo, "firmware", "rc-102", "hw1-fw4.14", "analysis")

cap = json.load(open(os.path.join(an, "capture.json"), encoding="utf-8"))
vs = cap["virtual_strings"]
print("capture taken:", cap.get("taken"))
for k in ("0x002", "0x202"):
    r = vs[k]
    print(k, "name", r.get("name"), "version", r.get("version"), "size", r.get("size"),
          "body_bytes", r.get("body_bytes"), "hex[:48]", r["hex"][:48], "text?",
          repr(r.get("text", "<none>"))[:90])

cfg = os.path.join(D, "decoded", "prior_capture_configuration_text.txt")
print("cfg txt size:", os.path.getsize(cfg) if os.path.exists(cfg) else "MISSING")
ec = os.path.join(D, "decoded", "energy_calibration.json")
print("energy_calibration.json:", os.path.getsize(ec) if os.path.exists(ec) else "MISSING")
print("decoded dir:", sorted(os.listdir(os.path.join(D, "decoded"))))

man = json.load(open(os.path.join(D, "manifest.json"), encoding="utf-8"))
ents = {e["path"]: e for e in man["files"]}
print("manifest entries:", len(man["files"]), "self included:", "manifest.json" in ents)
for p in sorted(ents):
    if p.startswith("raw/") or p.startswith("decoded/fresh"):
        print("  ", p, ents[p]["source"], ents[p]["bytes"])

img = os.path.join(an, "..", "listing.s")
print("listing lines:", sum(1 for _ in open(img, encoding="utf-8", errors="replace")))
ptr = json.load(open(os.path.join(D, "hardware", "bootloader_pointers_check.json"), encoding="utf-8"))
print("ptr keys:", list(ptr))
print(json.dumps(ptr, indent=1)[:900])
