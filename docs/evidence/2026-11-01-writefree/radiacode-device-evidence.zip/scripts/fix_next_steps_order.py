P = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\NEXT_STEPS.md"
t = open(P, encoding="utf-8").read()
start = t.index("## N8. Repository-side items")
end = t.index("## N7. Small documentation corrections")
block = t[start:end]
rest = t[end:]
# rest starts with the N7 heading; find where that section ends (next "## " after it, or EOF)
nxt = rest.find("\n## ", len("## N7. Small documentation corrections found during this pass"))
tail = rest[nxt:] if nxt != -1 else ""
head = rest[:nxt] if nxt != -1 else rest
open(P, "w", encoding="utf-8", newline="\n").write(head.rstrip() + "\n\n" + block.rstrip() + "\n" + tail)
print([l for l in open(P, encoding="utf-8").read().split("\n") if l.startswith("## ")])
