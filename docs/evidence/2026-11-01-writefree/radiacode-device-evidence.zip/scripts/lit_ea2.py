import re
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()
BASE = 0x08000000
md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)


def w(a):
    return int.from_bytes(img[a - BASE:a - BASE + 4], "little")


# Ghidra's own C for the two functions gives the authoritative pool words it used.
src = open(T + r"\decompiled.c", encoding="utf-8", errors="replace").read().split("\n")
for lo, hi, label in ((0x08029370, 0x08029388, "FUN_08029370"), (0x08027490, 0x08027518, "FUN_08027490")):
    print("=====", label)
    for ins in md.disasm(img[lo - BASE:hi - BASE], lo):
        m = re.search(r"\[pc, #0x([0-9a-f]+)\]", ins.op_str)
        if not m:
            continue
        imm = int(m.group(1), 16)
        for base_pc in (ins.address + 8, ins.address + 10):
            print("  %08x size=%d imm=0x%X  PC=+8->0x%08X  PC=+10->0x%08X" %
                  (ins.address, ins.size, imm, base_pc + imm, base_pc + imm + 2))
idx = {}
for ln in src:
    for mm in re.finditer(r"DAT_(08[0-9A-Fa-f]{6})", ln):
        idx[int(mm.group(1), 16)] = idx.get(int(mm.group(1), 16), 0) + 1
print("DAT_ refs in the two C blocks:")
for a in sorted(idx):
    if 0x08027D60 <= a <= 0x08029410:
        print("  DAT_%08X = 0x%08X" % (a, w(a)))
