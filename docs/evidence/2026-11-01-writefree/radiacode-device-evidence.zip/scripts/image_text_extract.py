"""Offline extraction: in-image text blobs (config text, VSFR map) and the sized memory facts."""

import json
import os

ROOT = r"C:\Users\ryans\source\repos\radiacode"
TARGET = os.path.join(ROOT, "firmware", "rc-102", "hw1-fw4.14")
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
img = open(os.path.join(TARGET, "flash.bin"), "rb").read()
BASE = 0x08000000


def blob(addr, n):
    off = addr - BASE
    return img[off:off + n]


def cstr(addr, limit=4096):
    raw = blob(addr, limit)
    end = raw.find(b"\x00")
    return raw[:end if end >= 0 else limit]


os.makedirs(os.path.join(OUT, "decoded"), exist_ok=True)
os.makedirs(os.path.join(OUT, "hardware"), exist_ok=True)

cfg = cstr(0x0802F9F0)
with open(os.path.join(OUT, "decoded", "image_config_text_0x0802F9F0.txt"), "w",
          encoding="utf-8") as fh:
    fh.write(cfg.decode("cp1251", "replace"))

vsfr = blob(0x080306AC, 4587)
with open(os.path.join(OUT, "decoded", "image_vsfr_map_0x080306AC.txt"), "wb") as fh:
    fh.write(vsfr)

facts = {
    "application_image": {"bytes": len(img), "base": hex(BASE), "end": "0x0803CA00",
                          "sha256": None},
    "sized_facts": {
        "initial_sp_vector0": "0x20000800",
        "reset_vector_vector1": "0x0803BA71",
        "vector_count": 98,
        "container_buffer_size_u32": 32768,
        "container_write_chunk_u32": 4096,
        "highest_addressed_flash_in_container": "0x0803CA00",
        "lowest_addressed_flash_in_container": "0x08010000",
        "bootloader_gap_bytes": 65536,
    },
    "unresolved_by_read_only_evidence": {
        "physical_flash_size": "no answering id reports it (VSFR_SYS_RX_SIZE/TX_SIZE and the "
                               "0xFFFF0000 block stay silent without the session write)",
        "physical_ram_size": "only the linker's InitialSP 0x20000800 is observed",
        "erase_page_and_bank_layout": "not exposed by any read-only id",
        "option_bytes_rdp": "no read-only id",
        "candidate_link_address_0x08070000": "used by the emulator harness "
                                             "(reconstruction/HYBRID.md, validate_*.py); no "
                                             "read-only source confirms that this address is "
                                             "implemented flash/RAM on the physical part",
    },
    "observed_max_referenced_addresses": {},
}
import struct
mx_flash = mx_sram = 0
for off in range(0x10000, len(img) - 3, 4):
    w = struct.unpack_from("<I", img, off)[0]
    if 0x08010000 <= w <= 0x0803CA00:
        mx_flash = max(mx_flash, w)
    elif 0x20000000 <= w < 0x20040000:
        mx_sram = max(mx_sram, w)
facts["observed_max_referenced_addresses"] = {
    "max_flash_literal_seen_in_image": hex(mx_flash),
    "max_sram_literal_seen_in_image": hex(mx_sram),
    "note": "4-byte-aligned word scan of the image; instruction encodings can coincidentally "
            "fall in these ranges, so the values are upper-bound hints only",
}
with open(os.path.join(OUT, "hardware", "memory_sized_facts.json"), "w", encoding="utf-8") as fh:
    json.dump(facts, fh, indent=2)
print(json.dumps(facts, indent=2)[:1500])
print("config text bytes:", len(cfg), "vsfr map bytes:", len(vsfr))
