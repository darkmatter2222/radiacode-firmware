import sys
sys.path.insert(0, r"C:\Users\ryans\source\repos\radiacode\pipeline")
import emulate

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()
# candidate pool words for 0x08029370's ldr: FC vs 00 -> distinct pointer values
# P1 at 0x2000E000 with byte+0xd = 0xA1 ; P2 at 0x2000E100 with byte+0xd = 0xA2
uc, trace = emulate.new_emulator(img)
emulate.preset(uc, [
    (0x080293FC, (0x2000E000).to_bytes(4, "little")),
    (0x08029400, (0x2000E100).to_bytes(4, "little")),
    (0x2000E00D, b"\xa1"),
    (0x2000E10D, b"\xa2"),
])
r = emulate.run_function(uc, trace, 0x08029370 | 1, args=(0xA2, 0, 0, 0))
print("call with r0=0xA2:", hex(r["r0"]), r["stopped"], "reads:", trace.reads[:8])
# 0xA201 -> used 0x2000E100 (pool @00); 0xA101 would mean E-path impossible; 0xA2 -> S from E100 no match
r2 = emulate.run_function(uc, emulate.Trace(), 0x08029370 | 1, args=(0xA1, 0, 0, 0))
print("call with r0=0xA1:", hex(r2["r0"]), r2["stopped"], "reads:", r2["reads"][:8])
r3 = emulate.run_function(uc, emulate.Trace(), 0x08029370 | 1, args=(0x00, 0, 0, 0))
print("call with r0=0x00:", hex(r3["r0"]), r3["stopped"], "reads:", r3["reads"][:8])
