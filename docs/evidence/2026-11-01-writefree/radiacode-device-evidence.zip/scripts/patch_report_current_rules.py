import json

P = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\REPORT.md"
lines = open(P, encoding="utf-8").read().split("\n")

# ---- §5 tail: deployment CLI + validator/gate status
i = next(k for k, l in enumerate(lines) if l.startswith("`deployment` CLI (offline"))
j = next(k for k, l in enumerate(lines) if k > i and l.startswith("those software checks is not hardware certification."))
assert lines[j].startswith("those software checks"), lines[j][:40]
new = """`deployment` CLI (offline, `updater/deployment_cli_*.json`): `plan` returns `status: BLOCKED`,
`device_commands_sent: 0`, `complete_device_backup: false`, `restore_supported: false`, missing
`[bootloader, device calibration, device settings, option bytes, complete device flash readback]`, and
five blockers.

Validator and gate status on this host (captured as `updater/repo_unit_tests.txt`,
`updater/release_gate.txt`, `updater/repo_layer_status.json`):

| command | exit | reading |
| --- | --- | --- |
| `python -m unittest discover -s tests -v` | 1 | 53 tests, `FAILED (failures=1, errors=2)`; all three are environment artifacts on this machine (symlink privilege `WinError 1314`, cp1252 decode of a generated markdown file, generated guides differing after regeneration) |
| `python pipeline/release_gate.py` | **2** | `status: INCONCLUSIVE`, `release_ready: false`, 30 blocker lines - `firmware equivalence not established` and `original-vs-rebuilt hardware evidence absent` per target, plus per-artifact hash mismatches because the generated files were rewritten after the last manifest |

Per `docs/VALIDATION.md` and the current working rules in `agents.md`, **exit 2 means inconclusive /
evidence unavailable, not success** - the gate fails closed and a green test suite does not override
it. `ROADMAP.md` counts the reconstruction as seven compiled candidates (3,152 differential cases),
one floating-point predicate (10,947 bounded comparisons including full FPSCR) and one
emulator-only replacement bridge (1,424 direct and caller cases); the confidence roll-up for this
build is `extraction PASS`, `container_roundtrip PASS` (format only), `decoder_comparison
INCONCLUSIVE` (445 identical / 7,236 format-only / 1,830 unresolved), `python_differential PASS 8/8`,
`formal PASS 10/10` auxiliary model properties, `hardware SKIP`, with
`firmware_equivalence: NOT_ESTABLISHED`. Passing those software checks is not hardware certification."""
lines[i:j + 1] = new.split("\n")

# ---- §8 differential row
txt = "\n".join(lines)
old_row = "| only a small set of compiled C candidates | unchanged: `reconstruction/` still holds the leaf/hybrid/calibration candidates; 8 differential cases pass in the emulator (`analysis/differential.json`, `analysis/confidence.json` `python_differential: PASS 8/8`, 81 unique instructions) |"
assert old_row in txt
new_row = ("| only a small set of compiled C candidates | unchanged: `reconstruction/` still holds the "
           "leaf/hybrid/calibration candidates. In the emulator 8/8 cases pass (`analysis/confidence.json` "
           "`python_differential: PASS 8/8`): three constants (`0x080166CE`, `0x08017EF2`, `0x08017EF6`), "
           "three `0x08017EB4` transfer-state branches, the `0x0502` accessor push at `0x080275C4`, and "
           "`0x08028A4C` frame serialise - the last one labelled *partial execution to a substituted "
           "call*; 81 unique instruction addresses, no fault and no budget exhaustion, and the format "
           "layer passes 12/12 CRC-32/MPEG-2, 128/128 Mangle-inverse, 16/16 block round-trip, 8/8 LZSS "
           "decode, 13/13 MS-DOS date and 6/6 Borland-LCG vectors. Case applicability is bound to the "
           "**full image SHA-256** in `differential.json:provenance.inputs` "
           "(`flash 23c31b7d…157f6`), not to a byte prefix |")
txt = txt.replace(old_row, new_row)

# ---- §8 closing paragraph: add the observer/FP regression note
marker = ("The same file’s `unclassified_bytes: 157956` is the\n"
          "honest size of the un-disassembled remainder.")
assert marker in txt
txt = txt.replace(marker, marker + "\nThe execution harness records two further constraints (both in `docs/VALIDATION.md`): read observers are\n"
                    "restricted to MMIO because a global RAM-read hook in Unicorn 2.1.4 changed the execution of\n"
                    "a conditional VFP load (pinned regression), and MMIO is plain RAM in that harness, so passing\n"
                    "MMIO cases cannot certify peripheral behaviour. Both are why the `hardware` layer stays `SKIP`.")
open(P, "w", encoding="utf-8", newline="\n").write(txt)
print("patched, lines:", txt.count("\n") + 1)
