import json

p = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\REPORT.md"
lines = open(p, encoding="utf-8").read().split("\n")

raw = json.load(open(r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
                     r"\raw\session_single_connection.json", encoding="utf-8"))
b = raw["baseline"]
n = len(b["samples"])
first, last = b["samples"][0], b["samples"][-1]
print("baseline samples:", n, "window", b["seconds"], "span", last["elapsed_s"])
print(json.dumps(first)[:400])

assert lines[204].startswith("The baseline loop is")
assert lines[208].strip().endswith("not from this baseline.")
new = f"""The baseline loop is `scripts/collect_single_conn.py --baseline {b['seconds']}`: inside one BLE
connection, alternate a `0x0005 GET_STATUS` read with the rate/temperature/charger/timestamp VSFR
reads and the spectrum window strings, {n} samples, {b['seconds']} s window. Result
(`decoded/fresh_baseline.json`, raw in `raw/session_single_connection.json`):

| field | sample 0 | sample 1 | note |
| --- | --- | --- | --- |
| `GET_STATUS` (0x0005) | `{first['GET_STATUS']}` | `{last['GET_STATUS']}` | the only id that answers |
| CPS `0x00008020`, DR `0x00008021`, DS `0x00008022`, TEMP `0x00008024`, CHARGER `0x0000C200`, DEV_TIME `0x00000504`, MS_RUN `0x00000603` | `null` | `null` | `0x0006` NAK frames |
| LIVE_WINDOW `VS 0x220`, SPECTRUM `VS 0x200`, DATA_BUF `VS 0x100` | `null` | `null` | `0x0006` NAK frames |

The two samples are `{last['elapsed_s']}` s apart (the request/response round trips inside the
connection fill the window). No numeric baseline was obtainable write-free, so the
count-rate/dose-rate/spectrum values quoted in section 3 are from the prior capture, not from this
baseline, and the fresh pass adds only the status word plus the NAK shapes."""
lines[204:209] = new.split("\n")

txt = "\n".join(lines)
txt = txt.replace("| BLE GATT | service `e63215e5-…b901`, write `…e6`, notify `…e7`, 18-byte host writes | `raw/session_writefree_v2.json` |",
                  "| BLE GATT | service `e63215e5-…b901`, write `…e6`, notify `…e7`, 18-byte host writes | `raw/session_single_connection.json` |")
txt = txt.replace("* This pass: **no device writes at all** (`writes_issued: []` in `raw/session_writefree_v2.json`).",
                  "* This pass: **no device writes at all** (`writes_issued: []` in all four `raw/session_*.json`\n  files; 314 logged requests).")
open(p, "w", encoding="utf-8", newline="\n").write(txt)
print("ok")
