import hashlib
import io
import json
import os
import zipfile

D = r"C:\Users\ryans\source\repos\radiacode\docs\evidence\2026-11-01-writefree"
z = zipfile.ZipFile(os.path.join(D, "radiacode-device-evidence.zip"))
names = z.namelist()
print("entries:", len(names))


def sha_of(name):
    return hashlib.sha256(z.read(name)).hexdigest()


# defect 1+2: empty config text / missing calibration file
for n in ("decoded/prior_capture_configuration_text.txt", "decoded/energy_calibration.json",
          "decoded/prior_capture_virtual_strings.json", "decoded/fresh_baseline.json"):
    if n in names:
        b = z.read(n)
        print("IN ", n, len(b), "bytes", repr(b[:60]))
    else:
        print("MISSING", n)

# defect 3/4: manifest labels + self hash
m = json.loads(z.read("manifest.json"))
ents = {e["path"]: e for e in m["files"]}
print("manifest entries", len(m["files"]), "| self in entries:", "manifest.json" in ents)
for p in ("raw/prior_capture.json", "raw/sweep_noarg.json", "raw/sweep_witharg.json",
          "raw/vsfr_readout_prior.json", "decoded/prior_capture_virtual_strings.json",
          "decoded/fresh_baseline.json", "manifest.json"):
    if p in ents:
        print("   ", p, "->", ents[p]["source"])
bad = [e["path"] for e in m["files"] if e["path"] in names and sha_of(e["path"]) != e["sha256"]]
print("hash mismatches:", bad[:6], "of", len(m["files"]))

# REPORT references vs presence
rep = z.read("REPORT.md").decode("utf-8")
import re
refs = sorted(set(re.findall(r"`((?:decoded|raw|hardware|updater|firmware)/[A-Za-z0-9_.\-]+)`", rep)))
missing = [r for r in refs if r not in names]
print("REPORT references", len(refs), "files; not in zip:", missing)

# ptr check artifact
pj = json.loads(z.read("hardware/bootloader_pointers_check.json"))
print("ptr json keys:", list(pj))
print(json.dumps(pj)[:700])
