import json
import os

P = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\raw\handshake_experiment.json"
j = json.load(open(P, encoding="utf-8"))
print("started/finished:", j["started"], "->", j["finished"], j["counts"])
print("\n== handshake ==", json.dumps({k: j["handshake"][k] for k in
      ("label", "cmd", "answered", "payload_hex", "matches_repo_probe")}, indent=1))
print("attempt:", json.dumps(j["handshake"]["attempts"][0]))

print("\n== pre vs post handshake ==")
for e in j["exchanges"]:
    if e["phase"] in ("pre_handshake", "post_handshake"):
        print(" ", e["phase"], e["label"], "seq", e["attempts"][0]["seq"], "payload",
              e["payload_hex"], "decoded", json.dumps(e.get("decoded"))[:120])

print("\n== identity ==")
for k, v in j["identity"].items():
    print(" ", k, "len", v["len"], "sha", (v["sha256"] or "")[:12], "hex", (v["hex"] or "")[:70])
    if v.get("decoded"):
        print("     decoded:", json.dumps(v["decoded"], ensure_ascii=False)[:230])

print("\n== identity_repeat consistency ==")
for k, v in j["identity_repeat"].items():
    first = (j["identity"].get(k) or {}).get("sha256") or (
        j["virtual_strings"].get("0x002" if k == "VS_002" else "0x202", {}).get("body_sha256"))
    print(" ", k, "answered", v["answered"], "same_sha", first is not None and first == v["sha256"],
          (v["sha256"] or "")[:12], "vs", (first or "")[:12])

print("\n== virtual strings ==")
for k, v in j["virtual_strings"].items():
    t = v.get("text_utf8")
    print(" ", k, "declared", v.get("declared_size"), "body", v.get("body_bytes"),
          "sha", (v.get("body_sha256") or "")[:12], "| text:", (t or "")[:64].replace("\n", "\\n"),
          "| calib:", json.dumps(v.get("calib"))[:120] if v.get("calib") else "")

print("\n== flash areas ==")
for k, v in j["flash_areas"].items():
    print(" ", k, {kk: (str(vv)[:120] if isinstance(vv, str) else vv)
                  for kk, vv in v.items() if kk != "raw_payload_hex"})

print("\n== vsfr (nonzero) ==")
for k, v in j["vsfr"].items():
    print(" ", k, v["addr"], v["hex"], "=", v["u32le"])

print("\n== baseline ==")
b = j["baseline"]
print(" seconds", b["seconds"], "samples", len(b["samples"]))
for s in b["samples"][:4] + b["samples"][-2:]:
    print("  ", s["elapsed_s"], {k: (v if v is None or len(str(v)) < 26 else str(v)[:26] + "...")
                                for k, v in s.items()})
