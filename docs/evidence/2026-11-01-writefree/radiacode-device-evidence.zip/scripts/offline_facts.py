"""Offline facts: listing coverage by real spans, geometry, literal-pool scans."""
import json
import os
import re
import struct

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
OUT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence\hardware"
os.makedirs(OUT, exist_ok=True)
img = open(os.path.join(T, "flash.bin"), "rb").read()
BASE = 0x08000000

# ---------- 1. parse listing.s into real (start, end, kind, text) spans ----------
row_re = re.compile(r"^([0-9A-Fa-f]{8})\s\s(.*)$")
spans = []          # (start, end, kind, text)
for line in open(os.path.join(T, "listing.s"), encoding="utf-8", errors="replace"):
    m = row_re.match(line.rstrip("\n"))
    if not m:
        continue
    addr = int(m.group(1), 16)
    body = m.group(2).strip()
    if body.startswith(".fill"):
        n = int(re.search(r"\.fill\s+0x([0-9a-f]+)|\.fill\s+(\d+)", body).group(1)
                or re.search(r"\.fill\s+0x([0-9a-f]+)|\.fill\s+(\d+)", body).group(2), 0) \
            if re.search(r"\.fill\s+0x", body) else int(re.search(r"\.fill\s+(\d+)", body).group(1))
        spans.append((addr, addr + n, "padding(.fill)", body[:110]))
    elif body.startswith(".byte"):
        n = len(re.findall(r"0x[0-9a-f]{2}", body)) or 16
        spans.append((addr, addr + n, "unclassified_data(.byte)", body[:110]))
    elif body.startswith(".word"):
        n = 4 * len(re.findall(r"0x[0-9a-f]{8}", body)) or 4
        spans.append((addr, addr + n, "data(.word)", body[:110]))
    else:
        hexpart = body.split("  ")[0]
        nbytes = len(re.findall(r"[0-9a-f]{2}", hexpart)) // 2 or 2
        spans.append((addr, addr + max(2, nbytes), "instruction", body[:110]))
spans.sort()
starts = [s[0] for s in spans]


def cover(addr, size=4):
    """Return the span whose [start,end) contains addr..addr+size, else None."""
    import bisect
    i = bisect.bisect_right(starts, addr) - 1
    for k in range(max(0, i - 2), min(len(spans), i + 3)):
        st, en, kind, text = spans[k]
        if st <= addr and addr + size <= en:
            return kind, st, en, text
        if st <= addr < en:            # partial coverage
            return kind + "(partial)", st, en, text
    return None, None, None, None


# ---------- 2. the 0x0800xxxx words ----------
words = {}
for off in range(0x10000, len(img) - 3, 4):
    w = struct.unpack_from("<I", img, off)[0]
    if 0x08000000 <= w < 0x08010000:
        words[BASE + off] = w
items = []
for addr in sorted(words):
    kind, st, en, text = cover(addr, 4)
    items.append({"address": "0x%08X" % addr, "word": "0x%08X" % words[addr],
                  "listing_coverage": kind or "NOT_IN_LISTING",
                  "span": None if st is None else "0x%08X-0x%08X" % (st, en),
                  "span_text": text or ""})
from collections import Counter  # noqa: E402
ptr = {"method": "listing.s spans (start<=addr and addr+4<=end); missing evidence stays "
                  "NOT_IN_LISTING",
       "total_words_in_0x0800_range": len(items),
       "by_coverage": dict(Counter(i["listing_coverage"] for i in items)),
       "note": ("a word inside an instruction span is part of an instruction encoding; "
                "a word inside a .byte/.word span is a data candidate. Neither proves or "
                "disproves a runtime pointer: pointer tracking would require execution."),
       "items": items}
with open(os.path.join(OUT, "bootloader_pointers_check.json"), "w", encoding="utf-8",
          newline="\n") as fh:
    json.dump(ptr, fh, indent=1)
print("coverage classes:", ptr["by_coverage"])

# ---------- 3. geometry / literal scans ----------
blocks = json.load(open(os.path.join(T, "blocks.json"), encoding="utf-8"))
bs = blocks["blocks"] if isinstance(blocks, dict) else blocks
maxaddr = max(int(b["addr"], 16) + int(b.get("plain_size", b.get("size", 0))) for b in bs)
lit = {"0x08070000": [], "flash_range_above_container": []}
for off in range(0, len(img) - 3, 4):
    w = struct.unpack_from("<I", img, off)[0]
    if w == 0x08070000:
        lit["0x08070000"].append("0x%08X" % (BASE + off))
    if 0x0803CA00 < w < 0x08080000:
        lit["flash_range_above_container"].append(
            {"at": "0x%08X" % (BASE + off), "word": "0x%08X" % w})
geom = {"image_file_bytes": len(img), "image_base": "0x08000000",
        "acquired_range": "0x08010000-0x%08X" % maxaddr,
        "acquired_bytes": maxaddr - 0x08010000,
        "zero_padding_bytes_below_app": 0x10000,
        "container_blocks": len(bs), "max_decoded_address": "0x%08X" % maxaddr,
        "initial_sp_from_vector_table": "0x20000800",
        "literal_scan": {"count_0x08070000_words": len(lit["0x08070000"]),
                         "addresses_with_that_word": lit["0x08070000"][:12],
                         "words_between_0x0803CA00_and_0x08080000":
                             lit["flash_range_above_container"][:12],
                         "count_words_between_container_end_and_0x08080000":
                             len(lit["flash_range_above_container"])},
        "interpretation": {
            "physical_flash_size": "UNKNOWN (no read-only id reports it; the STM32L4-class "
                                   "inference gives a family, not a capacity)",
            "0x08070000_availability": "UNPROVEN (no read-only source; not referenced by any "
                                       "literal in the image if count is 0)",
            "erase_page_geometry": "UNKNOWN from read-only evidence"}}
with open(os.path.join(OUT, "memory_sized_facts.json"), "w", encoding="utf-8",
          newline="\n") as fh:
    json.dump(geom, fh, indent=1)
print(json.dumps(geom["literal_scan"], indent=1))
print(json.dumps({k: v for k, v in geom.items() if k != "literal_scan"}, indent=1))
