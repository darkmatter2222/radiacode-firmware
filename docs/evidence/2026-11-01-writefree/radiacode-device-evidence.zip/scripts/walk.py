"""Exact Thumb instruction walks for the corrected handshake analysis (offline)."""
import json
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS

T = r"C:\Users\ryans\source\repos\radiacode\firmware\rc-102\hw1-fw4.14"
img = open(T + r"\flash.bin", "rb").read()
BASE = 0x08000000
md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)
md.detail = True


def walk(lo, hi, label):
    print("=====", label, "0x%08X-0x%08X" % (lo, hi))
    code = img[lo - BASE:hi - BASE]
    for ins in md.disasm(code, lo):
        print("  %08x  %-10s %s %s" % (ins.address, ins.bytes.hex(), ins.mnemonic, ins.op_str))


def words(addrs):
    for a in addrs:
        print("  word @0x%08X = 0x%08X" % (a, int.from_bytes(img[a - BASE:a - BASE + 4], "little")))


walk(0x08029370, 0x08029388, "FUN_08029370 (return-only helper)")
walk(0x08027490, 0x08027518, "FUN_08027490 (0x0007 handler)")
print("literals:")
words([0x080293FC, 0x08027D6C, 0x08027DA0, 0x08027DA4, 0x08027DA8, 0x08027D98, 0x08027DB0])
# the two function-size records from analysis
idx = json.load(open(T + r"\index.json", encoding="utf-8"))
for f in idx["functions"]:
    if f["address"].lower() in ("0x08029370", "0x08027490", "0x08029086", "0x08022e60", "0x08016780"):
        print("index.json:", f)
