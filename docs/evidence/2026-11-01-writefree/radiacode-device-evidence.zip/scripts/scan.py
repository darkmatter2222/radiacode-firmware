"""Read-only BLE advertisement scan (no connection, so no GATT writes at all)."""

import asyncio
import json

from bleak import BleakScanner


def norm(v):
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    if isinstance(v, dict):
        return {str(k): norm(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [norm(x) for x in v]
    return v


async def main():
    found = await BleakScanner.discover(timeout=8.0)
    out = []
    for d in found:
        rec = {"address": d.address, "name": d.name}
        details = getattr(d, "details", None)
        if details is not None:
            rec["extra"] = {}
            for attr in ("rssi", "manufacturer_data", "service_data", "service_uuids",
                         "tx_power", "structured"):
                val = getattr(details, attr, None)
                if val is not None:
                    rec["extra"][attr] = norm(val)
        out.append(rec)
    print(json.dumps(out, indent=2))


asyncio.run(main())
