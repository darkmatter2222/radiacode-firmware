"""Read-only evidence collection from a RadiaCode unit over BLE (NUS service).

Design notes (see also pipeline/rcble.py, which this transport mirrors exactly):
  * the transport performs no implicit writes: every wire frame is one of the
    commands listed in CALLS below, and `0x0007` / `0x0A04` / `0x0825` (the three
    writes the official `radiacode` library issues inside its constructor) are
    only issued when the `--with-session-writes` flag is passed explicitly;
  * every request and response is logged with wall-clock timestamps, the exact
    on-wire bytes (u32 LE length prefix included) and a SHA-256 of the payload.

Usage:
    python collect_reads.py            # pure read-only pass
    python collect_reads.py --with-session-writes
    python collect_reads.py --baseline 60
"""

import asyncio
import datetime
import hashlib
import json
import os
import struct
import sys

from bleak import BleakClient

ROOT = r"C:\Users\ryans\AppData\Local\Temp\opencode\radiacode-evidence"
RAW = os.path.join(ROOT, "raw")
DEC = os.path.join(ROOT, "decoded")
REPO = r"C:\Users\ryans\source\repos\radiacode\pipeline"
sys.path.insert(0, REPO)

from protocol import (CMD, VS, SIGN, decode_calib, decode_flash_area,  # noqa: E402
                      decode_image_info, decode_signature, decode_versions,
                      serial_from_address, split)

SERVICE_UUID = "e63215e5-7003-49d8-96b0-b024798fb901"
WRITE_UUID = "e63215e6-7003-49d8-96b0-b024798fb901"
NOTIFY_UUID = "e63215e7-7003-49d8-96b0-b024798fb901"
CHUNK = 18
ADDRESS = "52:43:06:60:20:24"

VS_IDS = [0x002, 0x003, 0x008, 0x00D, 0x00F, 0x0F0, 0x100, 0x101, 0x200, 0x202,
          0x203, 0x205, 0x206, 0x207, 0x208, 0x220]

# selected VSFR addresses, named from the in-image map at 0x080306AC
VSFRS = [
    ("VSFR_DEVICE_CTRL", 0x00000500), ("VSFR_DEVICE_LANG", 0x00000502),
    ("VSFR_DEVICE_ON", 0x00000503), ("VSFR_DEVICE_TIME", 0x00000504),
    ("VSFR_BLE_TX_PWR", 0x00000700), ("VSFR_DISP_CTRL", 0x00000510),
    ("VSFR_DISP_BRT", 0x00000511), ("VSFR_DISP_CONTR", 0x00000512),
    ("VSFR_DISP_OFF_TIME", 0x00000513), ("VSFR_DISP_ON", 0x00000514),
    ("VSFR_DISP_DIR", 0x00000515), ("VSFR_DISP_BACKLT_ON", 0x00000516),
    ("VSFR_SOUND_CTRL", 0x00000520), ("VSFR_SOUND_VOL", 0x00000521),
    ("VSFR_SOUND_ON", 0x00000522), ("VSFR_VIBRO_CTRL", 0x00000530),
    ("VSFR_VIBRO_ON", 0x00000531), ("VSFR_ALARM_MODE", 0x000005E0),
    ("VSFR_MS_RUN", 0x00000603), ("VSFR_CHARGER_STATE", 0x0000C200),
    ("RC_VSFR_DR_LEV1_uR_h", 0x00008000), ("RC_VSFR_DR_LEV2_uR_h", 0x00008001),
    ("RC_VSFR_DS_LEV1_100uR", 0x00008002), ("RC_VSFR_DS_LEV2_100uR", 0x00008003),
    ("RC_VSFR_DS_UNITS", 0x00008004), ("RC_VSFR_CPS_FILTER", 0x00008005),
    ("RC_VSFR_DOSE_RESET", 0x00008007), ("RC_VSFR_CR_LEV1_cp10s", 0x00008008),
    ("RC_VSFR_CR_LEV2_cp10s", 0x00008009), ("RC_VSFR_USE_nSv_h", 0x0000800C),
    ("RC_VSFR_CHN_TO_keV_A0", 0x00008010), ("RC_VSFR_CHN_TO_keV_A1", 0x00008011),
    ("RC_VSFR_CHN_TO_keV_A2", 0x00008012), ("RC_VSFR_CR_UNITS", 0x00008013),
    ("RC_VSFR_DS_LEV1_uR", 0x00008014), ("RC_VSFR_DS_LEV2_uR", 0x00008015),
    ("RC_VSFR_TEMP_UNITS", 0x00008016),
    ("RC_VSFR_CPS", 0x00008020), ("RC_VSFR_DR_uR_h", 0x00008021),
    ("RC_VSFR_DS_uR", 0x00008022), ("RC_VSFR_TEMP_degC", 0x00008024),
    ("RC_VSFR_ACC_X", 0x00008025), ("RC_VSFR_ACC_Y", 0x00008026),
    ("RC_VSFR_ACC_Z", 0x00008027), ("RC_VSFR_OPT", 0x00008028),
    ("RC_VSFR_RAW_TEMP_degC", 0x00008033), ("RC_VSFR_TEMP_UP_degC", 0x00008034),
    ("RC_VSFR_TEMP_DN_degC", 0x00008035),
    ("RC_VSFR_VBIAS_mV", 0x0000C000), ("RC_VSFR_COMP_LEV", 0x0000C001),
    ("RC_VSFR_CALIB_MODE", 0x0000C002), ("RC_VSFR_DPOT_RDAC", 0x0000C004),
    ("RC_VSFR_DPOT_RDAC_EEPROM", 0x0000C005), ("RC_VSFR_DPOT_TOLER", 0x0000C006),
    ("VSFR_SYS_MCU_ID0", 0xFFFF0000), ("VSFR_SYS_MCU_ID1", 0xFFFF0001),
    ("VSFR_SYS_MCU_ID2", 0xFFFF0002), ("VSFR_SYS_DEVICE_ID", 0xFFFF0005),
    ("VSFR_SYS_SIGNATURE", 0xFFFF0006), ("VSFR_SYS_RX_SIZE", 0xFFFF0007),
    ("VSFR_SYS_TX_SIZE", 0xFFFF0008), ("VSFR_SYS_BOOT_VERSION", 0xFFFF0009),
    ("VSFR_SYS_TARGET_VERSION", 0xFFFF000A), ("VSFR_SYS_STATUS", 0xFFFF000B),
    ("VSFR_SYS_MCU_VREF", 0xFFFF000C), ("VSFR_SYS_MCU_TEMP", 0xFFFF000D),
]

RECORDS = []
_SEQ = [0]
_STATE = {"chunks": [], "client": None}


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="milliseconds")


def sha(b):
    return hashlib.sha256(b).hexdigest() if b else None


async def _collect(timeout, header):
    """Accumulate notifications and return (all_bytes, matching_payload, skipped_frames).

    The device interleaves asynchronous event frames (command id 0x0006) with the
    answer to a request, so frames whose 4-byte header does not echo the request are
    recorded separately instead of being treated as the response.
    """
    buf = b""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    skipped = []
    whole = b""
    while loop.time() < deadline:
        while _STATE["chunks"]:
            buf += _STATE["chunks"].pop(0)
        while len(buf) >= 4:
            total = 4 + struct.unpack_from("<I", buf)[0]
            if len(buf) < total:
                break
            frame, buf = buf[:total], buf[total:]
            whole += frame
            payload = frame[4:]
            if len(payload) >= 4 and payload[:4] == header:
                return whole, payload[4:], skipped
            skipped.append(payload.hex())
        await asyncio.sleep(0.005)
    return whole, None, skipped


def _on_notify(handle, data):
    _STATE["chunks"].append(bytes(data))


async def xfer(cmd, args=b"", timeout=2.5, name=None, decoded=None, note=""):
    """One request/response exchange, fully logged."""
    seq = 0x80 + _SEQ[0]
    _SEQ[0] = (_SEQ[0] + 1) % 32
    request = struct.pack("<HBB", int(cmd), 0, seq) + bytes(args)
    full = struct.pack("<I", len(request)) + request
    _STATE["chunks"].clear()
    t0 = now()
    for pos in range(0, len(full), CHUNK):
        await _STATE["client"].write_gatt_char(WRITE_UUID, full[pos:pos + CHUNK])
    whole, data, skipped = await _collect(timeout, request[:4])
    t1 = now()
    header_ok = data is not None
    rec = {
        "t_request": t0, "t_response": t1, "transport": "bluetooth-le/gatt",
        "address": ADDRESS, "service": SERVICE_UUID,
        "write_char": WRITE_UUID, "notify_char": NOTIFY_UUID,
        "cmd_id": "0x%04X" % int(cmd), "cmd_name": name or CMD.get(int(cmd), "?"),
        "seq": "0x%02X" % seq,
        "args_hex": bytes(args).hex(),
        "request_wire_hex": full.hex(),
        "response_wire_hex": whole.hex(),
        "response_header_echo": header_ok,
        "interleaved_frames_hex": skipped,
        "payload_hex": data.hex() if data is not None else None,
        "payload_len": len(data) if data is not None else 0,
        "payload_sha256": sha(data), "note": note,
    }
    if decoded is not None:
        if callable(decoded):
            try:
                rec["decoded"] = decoded(data)
            except Exception as exc:  # noqa: BLE001
                rec["decode_error"] = repr(exc)
        else:
            rec["decoded"] = decoded
    RECORDS.append(rec)
    return data if header_ok else None


async def read_vs(vs):
    data = await xfer(0x0826, struct.pack("<I", vs), name="RD_VIRT_STRING",
                      note="VS 0x%03X %s" % (vs, VS.get(vs, "?")))
    if not data or len(data) < 8:
        return None
    version, size, body = split(data)
    return {"vs": "0x%03X" % vs, "name": VS.get(vs, "?"), "version": version,
            "size": size, "body_bytes": len(body), "body_hex": body.hex(),
            "body_sha256": sha(body)}


def parse_data_buf(body):
    """Best-effort decode of VS 0x100 per firmware.md SS20 (45 B / 21 B alternating records)."""
    out, pos, kind = [], 0, (45, 21)
    n = 0
    while pos + kind[n % 2] <= len(body):
        ln = kind[n % 2]
        rec = body[pos:pos + ln]
        item = {"index": n, "stride": ln, "seq": rec[0], "groupId": rec[1],
                "channelId": rec[2], "tag": rec[3],
                "tick": int.from_bytes(rec[4:7], "little"), "hex": rec.hex()}
        if ln == 45:
            item["pairs"] = [
                {"raw": struct.unpack_from("<I", rec, 13)[0],
                 "f32": struct.unpack_from("<f", rec, 17)[0],
                 "ripple": struct.unpack_from("<f", rec, 21)[0],
                 "stamp": struct.unpack_from("<I", rec, 25)[0]},
                {"raw": struct.unpack_from("<I", rec, 29)[0],
                 "f32": struct.unpack_from("<f", rec, 33)[0],
                 "ripple": struct.unpack_from("<f", rec, 37)[0],
                 "stamp": struct.unpack_from("<I", rec, 41)[0]},
            ]
        else:
            item["window_word"] = struct.unpack_from("<I", rec, 7)[0]
            item["f32"] = struct.unpack_from("<f", rec, 11)[0]
            item["flags"] = rec[15]
            item["tail"] = rec[16:21].hex()
        out.append(item)
        pos += ln
        n += 1
    return {"records": out, "tail_bytes": len(body) - pos,
            "grammar": "firmware.md SS20 (45B A-record / 21B B-record alternating)"}


async def collect(baseline_seconds=0):
    _STATE["client"] = BleakClient(ADDRESS, timeout=10.0)
    await _STATE["client"].connect()
    await _STATE["client"].start_notify(NOTIFY_UUID, _on_notify)
    session = {"started": now(), "address": ADDRESS, "writes_issued": []}
    try:
        if "--with-session-writes" in sys.argv[1:]:
            d = await xfer(0x0007, SIGN, name="SET_EXCHANGE", note="session open (write)")
            session["writes_issued"].append({"cmd": "0x0007", "args_hex": SIGN.hex(),
                                             "reply_hex": d.hex() if d else None})
            n = datetime.datetime.now()
            clock = struct.pack("<BBBBBBBB", n.day, n.month, n.year - 2000, 0,
                                n.second, n.minute, n.hour, 0)
            d = await xfer(0x0A04, clock, name="SET_LOCAL_TIME", note="wall clock (write)")
            session["writes_issued"].append({"cmd": "0x0A04", "args_hex": clock.hex(),
                                             "reply_hex": d.hex() if d else None})
        # --- identity: the six documented read-only identification commands
        for cid in (0x0005, 0x000A, 0x000B, 0x0012, 0x0101, 0x0807):
            dec = {0x000A: decode_versions, 0x0012: decode_image_info,
                   0x0101: decode_signature}.get(cid)
            data = await xfer(cid, decoded=dec)
            if data is None:
                session.setdefault("no_response", []).append(CMD[cid])
        session["ble_name_from_address"] = serial_from_address(ADDRESS)

        # --- virtual strings (the only bulk data channel)
        strings = {}
        for vs in VS_IDS:
            r = await read_vs(vs)
            if r:
                if VS.get(vs) in ("CONFIGURATION", "SERIAL_NUMBER", "EVENT_LOG"):
                    r["text"] = r["body_hex"] and bytes.fromhex(r["body_hex"]) \
                        .split(b"\x00")[0].decode("cp1251", "replace")
                if vs == 0x100:
                    r["parsed"] = parse_data_buf(bytes.fromhex(r["body_hex"]))
                if vs in (0x202,):
                    r["calib"] = decode_calib(bytes.fromhex(r["body_hex"]))
                strings[r["vs"]] = r
        session["virtual_strings"] = strings

        # --- parameter areas (XOR-obfuscated, seeded; raw payload preserved)
        areas = {}
        for area in range(4):
            data = await xfer(0x081C, struct.pack("<I", area),
                              decoded=decode_flash_area, note="flash area index %d" % area)
            if data:
                try:
                    dec = decode_flash_area(data)
                except Exception as exc:  # noqa: BLE001
                    dec = {"decode_error": repr(exc)}
                areas[str(area)] = {"payload_hex": data.hex(), "decoded": dec}
        session["flash_areas"] = areas

        # --- VSFR single reads (u32 address form)
        vsfrs = {}
        for label, addr in VSFRS:
            data = await xfer(0x0824, struct.pack("<I", addr), name="RD_VIRT_SFR",
                              timeout=1.2, note=label)
            if not data:
                continue
            rec = {"hex": data.hex()}
            if len(data) >= 8:
                rec["u32"] = struct.unpack_from("<I", data, 4)[0]
                rec["f32"] = struct.unpack_from("<f", data, 4)[0]
            elif len(data) == 4:
                rec["u32"] = struct.unpack("<I", data)[0]
                rec["f32"] = struct.unpack("<f", data)[0]
            vsfrs.setdefault(label, {})[hex(addr)] = rec
        session["vsfr"] = vsfrs

        # --- repeated stable-region reads (identity + calibration twice more)
        repeat = []
        for i in range(3):
            snap = {}
            for cid in (0x000A, 0x0012, 0x0101, 0x0807):
                d = await xfer(cid, note="repeat %d" % i)
                snap[CMD[cid]] = d.hex() if d else None
            for vs in (0x002, 0x202, 0x0F0):
                d = await xfer(0x0826, struct.pack("<I", vs), name="RD_VIRT_STRING",
                               note="repeat %d VS 0x%03X" % (i, vs))
                snap["VS_%03X" % vs] = sha(d) if d else None
            for area in (0, 1):
                d = await xfer(0x081C, struct.pack("<I", area),
                               note="repeat %d area %d" % (i, area))
                snap["area%d" % area] = sha(d) if d else None
            repeat.append(snap)
        session["repeat_stability"] = repeat

        # --- 60 s baseline of already-available outputs
        if baseline_seconds:
            samples = []
            t0 = asyncio.get_running_loop().time()
            k = 0
            while asyncio.get_running_loop().time() - t0 < baseline_seconds:
                s = {"t": now(), "elapsed_s": round(asyncio.get_running_loop().time() - t0, 3)}
                d = await xfer(0x0005, note="baseline %d status" % k)
                s["status"] = d.hex() if d else None
                for label, addr in (("CPS", 0x8020), ("DR_uR_h", 0x8021), ("DS_uR", 0x8022),
                                    ("TEMP_degC", 0x8024), ("CHARGER", 0xC200),
                                    ("DEVICE_TIME", 0x0504), ("MS_RUN", 0x0603)):
                    d = await xfer(0x0824, struct.pack("<I", addr), name="RD_VIRT_SFR",
                                   timeout=1.2, note="baseline %d %s" % (k, label))
                    s[label] = struct.unpack_from("<f", d, 4)[0] if d and len(d) >= 8 else None
                    s[label + "_hex"] = d.hex() if d else None
                for vs, key in ((0x220, "LIVE_WINDOW"), (0x200, "SPECTRUM"),
                                (0x202, "ENERGY_CALIB"), (0x100, "DATA_BUF")):
                    d = await xfer(0x0826, struct.pack("<I", vs), name="RD_VIRT_STRING",
                                   note="baseline %d VS 0x%03X" % (k, vs))
                    if d and len(d) > 8:
                        _, size, body = split(d)
                        s[key] = {"size": size, "hex": body.hex(), "sha256": sha(body)}
                samples.append(s)
                k += 1
                await asyncio.sleep(max(0.0, 2.0 - (asyncio.get_running_loop().time() - t0) % 2.0))
            session["baseline"] = {"seconds": baseline_seconds, "samples": samples}
    finally:
        session["finished"] = now()
        await _STATE["client"].disconnect()
    return session


def main():
    os.makedirs(RAW, exist_ok=True)
    os.makedirs(DEC, exist_ok=True)
    args = sys.argv[1:]
    baseline = 0
    if "--baseline" in args:
        baseline = int(args[args.index("--baseline") + 1])
    session = asyncio.run(collect(baseline))
    with open(os.path.join(RAW, "session_reads.json"), "w", encoding="utf-8") as fh:
        json.dump({"session": session, "exchanges": RECORDS}, fh, indent=2, ensure_ascii=False)
    # decoded artifacts (configuration text, calibration, baseline series)
    cfg = session.get("virtual_strings", {}).get("0x002")
    if cfg and cfg.get("text"):
        with open(os.path.join(DEC, "configuration_text.txt"), "w", encoding="utf-8") as fh:
            fh.write(cfg["text"])
    cal = session.get("virtual_strings", {}).get("0x202")
    if cal:
        with open(os.path.join(DEC, "energy_calibration.json"), "w", encoding="utf-8") as fh:
            json.dump({"source": "RD_VIRT_STRING 0x0826 VS 0x202", "raw_hex": cal["body_hex"],
                       "decoded": cal.get("calib")}, fh, indent=2)
    print(json.dumps({"exchanges": len(RECORDS), "vs": sorted(session.get("virtual_strings", {})),
                      "no_response": session.get("no_response", []),
                      "baseline_samples": len(session.get("baseline", {}).get("samples", []))},
                     indent=2))


if __name__ == "__main__":
    main()
