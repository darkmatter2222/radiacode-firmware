## 2. Memory model

| region | range | content |
| --- | --- | --- |
| boot (absent from container) | `0x08000000`-`0x0800FFFF` | 64 KiB of zeros in the image; vendor bootloader |
| application | `0x08010000`-`0x0803CA00` | 178.5 KiB: vector table, code, literal pools, embedded config text |
| SRAM | `0x20000000`-`0x2000FFFF` | 64 KiB; `InitialSP = 0x20000800` (small stack at the bottom), pool/heap control literals at the top (`0x2000f3bc`...`0x2000ffbc`) |

Data blobs living inside the code image:

| address | size | content |
| --- | --- | --- |
| `0x0802F9F0` | 3256 B | `[DeviceParams]` + `[DataStructure]` text (§9, §10) |
| `0x080306AC` | 4587 B | `[VSFR_*]` register map, 67 records (§8) |
| `0x08035EBE` +0x49 x7 | 72 B each | seven monotonic byte ramps (0x20-0x7E, step 1-3) — quantised log / gamma-style curves *(inferred)* |
| `0x08036C10` | 44 pairs | `{u32 id, u32 handler}` table; ids `0x0`-`0x6`, `0x400`-`0x40A`, `0x800`-`0x80A`, `0xC01`-`0xC18` |
| `0x08038D9C` | 36 B | base-36 digit alphabet `0123456789abcdefghijklmnopqrstuvwxyz` |
| `0x08022F4C`, `0x08038454`, `0x08038494`, `0x08038CD4`, `0x0803943C`, `0x0803A3FC`, `0x08020A18` | 4-10 pairs | further `{id, handler}` runs (`analysis/tables.json`) |



## 3. Decoded block layout

All 8 blocks decrypt and CRC-verify; stored size = LZSS + 8-byte alignment, `plain` = size in flash.

| # | address | stored | decompressed | crc | instructions |
| --- | --- | --- | --- | --- | --- |
| 0 | `0x08010000` | 17838 | 28672 | `7f0ef5e3` | 10686 |
| 1 | `0x08017000` | 16726 | 20224 | `d87719e6` | 7599 |
| 2 | `0x0801bf00` | 12536 | 16384 | `affad014` | 6193 |
| 3 | `0x0801ff00` | 26080 | 31232 | `91a0e8c8` | 11986 |
| 4 | `0x08027900` | 22141 | 25600 | `a87ba0d5` | 9714 |
| 5 | `0x0802dd00` | 10496 | 20224 | `3a567504` | 5872 |
| 6 | `0x08032c00` | 11128 | 22272 | `c758d839` | 8555 |
| 7 | `0x08038300` | 8945 | 18176 | `f790ccd9` | 6673 |



## 4. Container format (how the firmware is packed)

```
header   : "Phyton\0\0" | u32 header_size(52) | u32 date_time | u32 buffer_size | u8[16] serial
           | u8 version_low | u8 version_high | u32 file_count | u32 fw_header_size
           | u8 compressed | u8 reserved | u32 crc32
blocks[] : u32 header_size | u32 size ^ 0xCE27A932 | u32 addr ^ 0xB2D5A864
           | u8 key_block[512] | u8 data[align8(size)]
```

* `key_block`: unmangle with hardcoded key-table slot 0; index at `[0:2]`, 16-byte data key at `[2:18]`,
  equal CRC pair at `[18:26]`; that region is unmangled a second time with the table selected by `index`
  (`0-7` hardcoded, `8-15` zero table, `0xFFFF` device-id key).
* Mangle cipher: 48-round Feistel over 8-byte little-endian blocks, four round keys (`key[rnd & 3]`),
  round function `B' = rnd + key + ((B>>8)^(B<<6)) + B + A`.
* CRC: MPEG-2 polynomial `0x04C11DB7`, no reflection, init `0xFFFFFFFF`, fed as 4-byte LE chunks.
* Payload: LZSS — 2048-byte window pre-filled with `0x20`, initial index `2031` (`2048-0x10-1`), flag
  bit 1 = literal, 0 = match (11-bit offset + 4-bit length, `+2`, so match length `2..17`), MSB-first.
* The small flash areas returned by cmd `0x081C` use a *different* stream cipher: Borland LCG keystream
  (`seed * 0x015A4E35 + 1`, XOR of the low 8 bits of `seed >> 16`, one continuous state across the size
  word and the payload).

All four primitives are implemented and test-vector-verified in `pipeline/rcfmt.py`, and self-tested by `pipeline/step1_validate.py`.



## 23. Storage budget

| region | range / size | note |
| --- | --- | --- |
| bootloader | `0x08000000`-`0x0800FFFF`, 65536 B | not present in any container |
| application | `0x08010000`-`0x0803CA00`, 182784 B | 8 blocks, individually CRC'd |
| unused flash tail | `0x0803CA00`-`0x08040000`, 13824 B | free |
| RAM (modelled) | `0x20000000`-`0x2000FFFF`, 65536 B | stack top `0x20000800` |
| container on the wire | 130148 B | 8 Mangle/LZSS blocks, header 52 B, `buffer_size` 32768 |
| parameter area 0 | 72 B | magic + size + `0xFF` filler |
| parameter area 1 | 448 B | magic + size `0x1C0` + serial / file / product strings + `05 01 da da da` + 3000 |



## 24. App-side persistence model

The official APK ships `assets/DatabaseInit.sql`; the tables are `Log`, `Tracks`, `TracksData`,
`Backgrounds`, `Spectrograms`, `SpgSpectrums`, `DeviceProfiles`, `Folders`, `Dictionary`. The `Log` table
is the mirror of the channel model:

```
 Log(Id, Timestamp, LastModified, DeviceSN, DeviceFW, GroupId, Channels, Event, EventParam1,
     PulseCount, CountRate, DoseRate, DoseRateError, CountRateError, AlarmDoseRate, AlarmDose,
     AlarmCountRate, AlarmTemp, DAcDuration, Dose, Temp, Charge, Flags, Latitude, Longitude,
     Comment, SystemComment)
      ^^^^^^^^^^  ^^^^^^^^^  ^^^^^^^^  ^^^^^^^^  ^^^^      ^^^^^^  ^^^^^^
        id 2        id 3       id 4      id 5/16   id 7     id 8    id 9     <- [DataStructure] ids
```

plus `Tracks`/`TracksData` (GPS traces), `Spectrograms`/`SpgSpectrums` (stored histograms), `Backgrounds`
(reference spectra) and `Dictionary` (id/string pairs). `GroupId` is the `GRP_*` id and `Flags` is
`CHN_Flags`, so a row is one group snapshot - which matches the group-oriented wire protocol rather than
per-channel rows.


