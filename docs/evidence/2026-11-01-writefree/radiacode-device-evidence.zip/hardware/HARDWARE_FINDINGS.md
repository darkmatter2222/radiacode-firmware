# Hardware identification — observed vs inferred

Evidence files: `mcu_evidence_from_image.json`, `bootloader_pointers_check.json`,
`memory_sized_facts.json`, `usb_and_host_pnp.json`, `repo_artifact_summary.json`,
`firmware_md_identity_capability.md`.

## Observed (from the acquired image bytes or the host’s own enumeration)

| item | value | where |
| --- | --- | --- |
| instruction set | Thumb-2 / ARMv7E-M, 32-bit little-endian image | `listing.s`, decoded blocks |
| flash base / application base | `0x08000000` / `0x08010000` | `blocks.json`, vector table |
| image extent | `0x08010000`-`0x0803CA00` (8 container blocks), 248 320 B padded file | `blocks.json`, `analysis/stats.json` |
| vector table | 98 entries, `InitialSP 0x20000800`, `Reset 0x0803BA71` | `analysis/vectors.json` |
| FPU present | VFP arithmetic appears in the decoded instructions (single-precision, `f32` fields decode as IEEE-754 in the VSFR/record data) | differential harness + records |
| system-memory constants used | `0x1FFF7590` (96-bit unique ID) at `0x08019EC4`, `0x08028810`, `0x08028E90`; `0x1FFF75A8`, `0x1FFF75AA`, `0x1FFF75E0` | `hardware/mcu_evidence_from_image.json` |
| software reset path | `SCB->AIRCR = 0x05FA0004` literal at `0x08027DC4` | same |
| CRC engine semantics | CRC-32/MPEG-2 tables at `0x0801F424`, `0x0802ACD8`, `0x0802D748` | same |
| USB identity | VID `0x0483`, PID `0xF123`, bcdDevice `0x0200`, class FF/FF/FF, iProduct `RadiaCode-102`, iSerialNumber `RC-102-008228`, driver `PHUSBDEV` | `usb_and_host_pnp.json` |
| BLE identity | advertised name `RadiaCode-102#RC-102-008228`, NUS-style 3-UUID service | `raw/ble_scan.json` |

## Inferred (labelled as inference)

* **MCU family.** The image’s own peripheral names (`LPUART2`, `LPTIM3/4/5`, `QUADSPI`, `DMA2D`, `LCD`,
  `AES`, `COMP`) together with the IRQ numbering (LPUART2 = 65, LPTIM3/4/5 = 66/67/68) and the
  `0x1FFF75xx` system-memory layout ⇒ STM32L4 with JPEG/DMA2D/LCD, i.e. the L4 7x/8x-class group
  (L475/L476/L485/L486/L496/L4A6 family). **The exact orderable part number is not established by any
  read-only source in this package**: `VSFR_SYS_MCU_ID0..2` (`0xFFFF0000..2`) stayed silent in the
  write-free pass, and no answering id reports flash/RAM capacity.
* **RAM.** Only the linker’s `InitialSP 0x20000800` is observed; the highest SRAM word literal seen is
  `0x2003FF47`, which is an upper-bound hint only because instruction encodings fall in that range too.
* **Erase geometry.** STM32L4 parts use 2048-byte pages, but nothing read from the device confirms it.
  Recorded as unknown.

## Does the application depend on the missing bootloader region?

* 33 four-byte-aligned words in the image have values inside `0x08000000`-`0x0800FFFF`. Cross-checked
  against the disassembly: **all 33 are in instruction rows**, e.g. `0x0801F448 → 0x0800C00C`, so they
  are Thumb encodings, not pointers (`hardware/bootloader_pointers_check.json`).
* No `.word` data item and no `b`/`bl` target in the current listing resolves below `0x08010000`
  (1334 listed tokens land in `0x08010000`-`0x0803CA00`, 6 in the peripheral range, 3 in SRAM).
* Reading of this result: within the disassembled portion the application is self-contained; the
  dependency on the bootloader is the entry jump itself (the boot code at `0x08000000` jumps to the
  application’s reset at `0x0803BA70`). Caveat: 157 956 image bytes are still unclassified, so
  absence in the listing is not proof of absence in the image.

## Not established at all in this session

Board revision; exact part number; flash/RAM capacity and bank/page layout; the presence of external
NVM or a separate radio co-processor (the NUS service is provided by the MCU in STM32L4 parts with an
integrated radio, but no read-only id names the part here); SWD/JTAG pad locations; whether RDP is set.
These need either the session write for the `0xFFFF0000` VSFR block or a photographed board / SWD read
(see `NEXT_STEPS.md`).
