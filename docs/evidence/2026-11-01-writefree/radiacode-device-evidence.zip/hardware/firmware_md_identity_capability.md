## 1. Identity

| item | value | evidence |
| --- | --- | --- |
| device | RadiaCode-102 (scintillation dosimeter / radiometer) | string `RadiaCode-102` @ `0x08019F1C` |
| hardware id | `2BDDP-102` | @ `0x080149F8` |
| firmware version | 4.14 (`version_high 4`, `version_low 14`) | container header; format `v%02d.%02d` @ `0x08014A04` |
| firmware build | `Jul  7 2025 11:19:22` = `date_time 0x5AE7428A` | @ `0x08028F14`, cmd `0x000A` |
| bootloader build | `Feb  6 2023 15:49:14` | cmd `0x000A` |
| container | `Phyton\0\0`, 130148 B, whole-file CRC `0x13095ABB`, 8 blocks | `blocks.json` |
| flat image | 248320 B, `0x08000000`-`0x0803CA00` | `flash.bin` |
| MCU | STM32L47x/L48x-class, Cortex-M4F, ARMv7E-M, Thumb-2 | vector names + IRQ numbering (LPUART2=65, LPTIM3/4/5=66/67/68, JPEG/DMA2D/LCD exist) |
| BLE name | `RC-102-%06.6X` | @ `0x08019F0C` |
| GATT | Nordic UART service `e63215e5-7003-49d8-96b0-b024798fb901`, write `...e6`, notify `...e7` | live probing (`rcsession.py`) |

Image-vs-unit identity is proven by four independent matches (size, `date_time`, CRC, and the 3256-byte
config string read back byte-identically from the device): `analysis/verification.json`.



## 5. Execution model

**Reset** — `handler_1_reset` @ `0x0803BA70` (3 instructions + literal pool):

1. `if (isCurrentModePrivileged()) setMainStackPointer(0x20000800)` — SP from the vector table.
2. `bl` to `0x08038A59` (`FUN_08038a58`) — clock bring-up: enable the internal RC oscillator
   (`CR |= 0xF00000`), program the PLL block (multiplier `0x1000`, prescaler word cleared), then write the
   clock-selector word. Three register blocks, in that order.
3. `bl` to `0x0803C459` (`FUN_0803c458`) — enter the event loop.

**Event loop** (`FUN_0803c458`): `FUN_0803a978()`, then spin on `FUN_0803aee0()` until it returns a
message block; decode the 8-byte block header (size in bits 3+, type in bits 0-1) and tail-jump to the
pool processor at `0x08023F92`. That processor is a size-class, first-fit allocator with coalescing and
an integrity checker (`FUN_0802d368` on corruption) — a `malloc`/`free` pair over a pool whose control
block sits near `0x2000fxxx`. ISRs only post message blocks; all real work happens in the main loop.

**Driver framework.** The dispatcher `sub_0801F474` (right after the string `Start Main loop` @
`0x0801F464`) walks a table of descriptors: `n = [dev + 0x14]`, entry `i` at `table[i * 4]`, class
selected by `flags & 0x7000` (`0x1000` = "call slot `+0x18` of the descriptor's vtable"), then per-id
post-processing (sub-ids 2 and 6 observed). A static-vtable peripheral model *(inferred)*.

**Library.** Compact stdio with bounds-checked variants: `printf_s` / `wprintf_s`
(`bad %s argument`, `bad %ls argument`, `%n disallowed` @ `0x08021CF4`-`0x0802EE44`) and a
`constraint handler: bad message` assert path @ `0x0802C4AF`. Time/duration formats:
`%02d:%02d:%02d` @ `0x0803BFE0`, `%dd %02d:%02d` @ `0x0803BFF0`; integer-to-text uses the base-36
alphabet at `0x08038D9C`.



## 6. Interrupt usage

98 vector entries. Nine exception stubs at `0x080363FD`-`0x0803640D` (2-byte `b` each). Only these IRQs
have their own code; every other entry points at `0x0803C4D9`, a 4-byte self-loop (`b.w` to itself —
idle/trap), which also appears 66 times as a literal.

| IRQ | handler | IRQ | handler | IRQ | handler |
| --- | --- | --- | --- | --- | --- |
| 7 EXTI1 | `0x0803640F` | 11 DMA1_CH0 | `0x08036455` | 40 DMA2_CH0 | `0x080364F9` |
| 8 EXTI2 | `0x08036423` | 12 DMA1_CH1 | `0x08036475` | 50 AES | `0x0803651B` |
| 9 EXTI3 | `0x0803654B` | 18 ADC1_2 | `0x080364A1` | 54 TIM12 | `0x0803651F` |
| 10 EXTI4 | `0x08036437` | 23 USART1 | `0x080364BF` | 65 LPUART2 | `0x08036523` |
| — | — | 66 LPTIM3 | `0x0803653B` | 67 LPTIM4 | `0x0803655B` |

Each real ISR is a 3-6 instruction trampoline: read a peripheral status word, OR a bit into a shadow
status (`0x20`, `0x40`, `0x80`, ...), post an event (e.g. `FUN_08036474` -> `FUN_080191f0`). The
IRQ-numbered trampolines at `0x0803C4B6`+ load the id (`movs r1, #n`) and tail-jump into the shared entry
at `0x0803C4B2`. Used peripherals implied by this list: USART1 + DMA (BLE link), ADC1/2 (battery / analog),
LPTIM3/4 + TIM12 (timebase / wake), EXTI (buttons, radio INT), AES (hardware crypto).



## 14. Static-analysis facts

| metric | value |
| --- | --- |
| decoded instructions (capstone linear sweep) | 66,745 over 69,209 listing lines, 100 % byte coverage |
| function candidates | 1,867 |
| decompiled function blocks (Ghidra 12.2) | 1,895 (`seeded 1172`, `decompiled 1893`, `failed 2`) |
| unresolved stubs | `0x08016cc6`, `0x0802abf8` (data-table slots; code only in the listing) |
| functions reachable from a vector handler | 99 of 1,867 (the rest via tables / indirect calls) |
| deepest reachability | `Reset` -> 33 functions, depth 7 |
| most-called | `0x08017FA8` (163), `0x0801953C` (110), `0x08017FCC` (85), `0x080194F4` (63) |
| static `{id, handler}` runs | 8, 85 handlers, all present in the C output |
| ASCII strings | 1,906 |
| strings reached by a literal / functions with string refs | 87 / 38 (step 8) |



## 25. Capability matrix

| # | capability | path | status |
| --- | --- | --- | --- |
| 1 | identity: serial, product, build stamps, versions | `0x000A`, `0x000B`, `0x0101` | read - works |
| 2 | image identity (`size/date_time/crc32/chunk`) | `0x0012` | read - works |
| 3 | staged frame count | `0x0013` | read - works |
| 4 | full configuration + channel model text | `0x0826` VS `0x002` | read - 3256 B, byte-identical to flash |
| 5 | calibration polynomial, spectrum header, window | `0x0826` VS `0x200`-`0x220` | read - works |
| 6 | real-time record stream | `0x0826` VS `0x100` | read - grammar in §20 |
| 7 | event log ring | `0x0826` VS `0x00F` | read - works |
| 8 | per-unit parameter areas | `0x081C` 0/1 | read - XOR-unwrapped |
| 9 | device/display/sound/vibro/alarm/charger settings | `0x0824` + VSFR addr | read - 20 entries, §README 5.4 |
| 10 | measurement + system VSFR block at idle | `0x0824` `0x8000`+, `0xFFFF0000`+ | **zero word** (rare-data cycle) |
| 11 | 1024-channel spectrum array | - | **locked out**, no id returns it |
| 12 | raw memory read | - | **locked out**, no such id (two full sweeps) |
| 13 | bulk image bytes from the device | - | **locked out** by design; vendor file + CRC triple instead |
| 14 | write calibration/parameter (VSFR/string/batch) | `0x0825`, `0x0827`, `0x082B` | named by the SDK, **not exercised** here |
| 15 | wall clock | `0x0A04` | write - idempotent, used by the pipeline |
| 16 | open the session | `0x0007` | write - idempotent sign |
| 17 | batch VSFR reads | `0x082A` | partial - plain `u32` address form only |
| 18 | numbered item table through the index form | `0x0824` `0x00`-`0x5A` | **no data**, recovered statically (step 10) |
| 19 | SWD/JTAG dump | - | locked out, BLE-only workflow |


