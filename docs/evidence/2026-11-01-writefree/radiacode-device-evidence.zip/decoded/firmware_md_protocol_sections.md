## 7. BLE transport and packet framing

* Host writes in 18-byte chunks; every frame = `u32 LE total_length` + payload.
* Payload starts with a 4-byte header `cmd:u16 LE | 0x00 | seq`; the host uses `seq = 0x80 + (counter % 32)`
  and matches replies by comparing the echoed header.
* Validation is `sub_08027D06`, whose failure strings are:
  `Error: S%d Packet size corrupted! PacketSize = 0x%08X` (`0x08037267`),
  `Error: S%d Command corrupted! Cmd = 0x%08X` (`0x080372A0`),
  `Error: S%d Valid sign corrupted! Sgn = 0x%08X` (`0x080372CC`),
  `Error: S%d Packet or String size corrupted! PacketSize = ..., StringSize = ...` (`0x080372FC`),
  `Error: S%d Data frame corrupted!` (`0x08037354`) — `S%d` is the slot/sequence index.
  Overruns report `%d message(s) lost!` @ `0x0803BD3C`.
* Link lifecycle strings: `BLE: client connected` (`0x08038124`), `BLE: connection timeout expired`
  (`0x0803813C`), `BLE: HW error/SPI|Radio|Timer overrun|Unknown` (`0x0803815C`-`0x080381A0`),
  `BLE: disconnected by remote user` / `by reason 0x%0.2X` (`0x08038E5C`, `0x08038E80`),
  `BLE: Connection parameter update error #0x%0.2X! Interval is %d.` (`0x08039008`),
  `BLE: error packet received => ...` (`0x080392DC`), and the state machine's
  `BLE: Hardware initialization` / `BLE: Start` / `BLE: Stop` / `BLE: Init sequence error!` /
  `BLE: Start sequence error!` (`0x08022EE0`-`0x08022F34`). The radio is SPI-attached (`HW error/SPI`).
* Inside the firmware, per-item access is one big address switch, `sub_080275C4`, built as a `subs`/`beq`
  chain over the 16-bit VSFR address: `0x500`, `0x502`, `0x503`, `0x504`, `0x505`-`0x50D`, `0x510`-`0x516`,
  `0x520`-`0x522`, `0x530`, `0x531`, `0x5E0`, `0x603`, `0x700`, then `+0x7900` for the `0x8000`-`0x8035`
  measurement block, the `0xC000`-`0xC200` calibration block, and `0xFFFF0000`+ for the system block —
  exactly the four address ranges declared in the config text. Callers pass an item count and an
  8-byte-per-item result buffer.



## 8. Register interface (VSFR map, 67 records @ `0x080306AC`)

All records are `Virtual=1` (software-decoded, not memory-mapped). Fields per record: `Addr`, `Size`
(bytes), `Type=float` (IEEE-754), `Signed=1`, `DisplayFormat=1` (LCD-formatted), `Min`/`Max` (enum bounds).

| # | VSFR | Addr | Size | flags |
| --- | --- | --- | --- | --- |
| 1 | `VSFR_DEVICE_CTRL` | `0x00000500` | 1 | — |
| 2 | `VSFR_DEVICE_LANG` | `0x00000502` | 1 | fmt |
| 3 | `VSFR_DEVICE_ON` | `0x00000503` | 1 | fmt, 0..1 |
| 4 | `VSFR_DEVICE_TIME` | `0x00000504` | 4 | fmt |
| 5 | `VSFR_BLE_TX_PWR` | `0x00000700` | 1 | fmt |
| 6 | `VSFR_DISP_CTRL` | `0x00000510` | 1 | — |
| 7 | `VSFR_DISP_BRT` | `0x00000511` | 1 | fmt |
| 8 | `VSFR_DISP_CONTR` | `0x00000512` | 1 | fmt |
| 9 | `VSFR_DISP_OFF_TIME` | `0x00000513` | 4 | fmt |
| 10 | `VSFR_DISP_ON` | `0x00000514` | 1 | fmt, 0..1 |
| 11 | `VSFR_DISP_DIR` | `0x00000515` | 1 | fmt |
| 12 | `VSFR_DISP_BACKLT_ON` | `0x00000516` | 1 | fmt, 0..1 |
| 13 | `VSFR_SOUND_CTRL` | `0x00000520` | 2 | — |
| 14 | `VSFR_SOUND_VOL` | `0x00000521` | 1 | fmt |
| 15 | `VSFR_SOUND_ON` | `0x00000522` | 1 | fmt, 0..1 |
| 16 | `VSFR_VIBRO_CTRL` | `0x00000530` | 1 | — |
| 17 | `VSFR_VIBRO_ON` | `0x00000531` | 1 | fmt, 0..1 |
| 18 | `VSFR_ALARM_MODE` | `0x000005E0` | 1 | fmt |
| 19 | `VSFR_MS_RUN` | `0x00000603` | 1 | fmt, 0..1 |
| 20 | `VSFR_PLAY_SIGNAL` | `0x000005E1` | 1 | fmt |
| 21 | `VSFR_CHARGER_STATE` | `0x0000C200` | 1 | fmt, signed |
| 22 | `RC_VSFR_DR_LEV1_uR_h` | `0x00008000` | 4 | fmt |
| 23 | `RC_VSFR_DR_LEV2_uR_h` | `0x00008001` | 4 | fmt |
| 24 | `RC_VSFR_DS_LEV1_100uR` | `0x00008002` | 4 | fmt |
| 25 | `RC_VSFR_DS_LEV2_100uR` | `0x00008003` | 4 | fmt |
| 26 | `RC_VSFR_DS_LEV1_uR` | `0x00008014` | 4 | fmt |
| 27 | `RC_VSFR_DS_LEV2_uR` | `0x00008015` | 4 | fmt |
| 28 | `RC_VSFR_DS_UNITS` | `0x00008004` | 1 | fmt, 0..1 |
| 29 | `RC_VSFR_USE_nSv_h` | `0x0000800C` | 1 | fmt, 0..1 |
| 30 | `RC_VSFR_CR_UNITS` | `0x00008013` | 1 | fmt, 0..1 |
| 31 | `RC_VSFR_CPS_FILTER` | `0x00008005` | 1 | fmt |
| 32 | `RC_VSFR_CR_LEV1_cp10s` | `0x00008008` | 4 | fmt |
| 33 | `RC_VSFR_CR_LEV2_cp10s` | `0x00008009` | 4 | fmt |
| 34 | `RC_VSFR_TEMP_UNITS` | `0x00008016` | 1 | fmt, 0..1 |
| 35 | `RC_VSFR_DOSE_RESET` | `0x00008007` | 1 | fmt, 0..1 |
| 36 | `RC_VSFR_CHN_TO_keV_A0` | `0x00008010` | 4 | float |
| 37 | `RC_VSFR_CHN_TO_keV_A1` | `0x00008011` | 4 | float |
| 38 | `RC_VSFR_CHN_TO_keV_A2` | `0x00008012` | 4 | float |
| 39 | `RC_VSFR_CPS` | `0x00008020` | 4 | fmt |
| 40 | `RC_VSFR_DR_uR_h` | `0x00008021` | 4 | fmt |
| 41 | `RC_VSFR_DS_uR` | `0x00008022` | 4 | fmt |
| 42 | `RC_VSFR_TEMP_degC` | `0x00008024` | 4 | float |
| 43 | `RC_VSFR_RAW_TEMP_degC` | `0x00008033` | 4 | float |
| 44 | `RC_VSFR_TEMP_UP_degC` | `0x00008034` | 4 | float |
| 45 | `RC_VSFR_TEMP_DN_degC` | `0x00008035` | 4 | float |
| 46 | `RC_VSFR_ACC_X` | `0x00008025` | 2 | fmt, signed |
| 47 | `RC_VSFR_ACC_Y` | `0x00008026` | 2 | fmt, signed |
| 48 | `RC_VSFR_ACC_Z` | `0x00008027` | 2 | fmt, signed |
| 49 | `RC_VSFR_OPT` | `0x00008028` | 2 | fmt |
| 50 | `RC_VSFR_VBIAS_mV` | `0x0000C000` | 2 | fmt |
| 51 | `RC_VSFR_COMP_LEV` | `0x0000C001` | 2 | fmt, signed |
| 52 | `RC_VSFR_CALIB_MODE` | `0x0000C002` | 1 | fmt, 0..1 |
| 53 | `VSFR_SYS_MCU_ID0` | `0xFFFF0000` | 4 | — |
| 54 | `VSFR_SYS_MCU_ID1` | `0xFFFF0001` | 4 | — |
| 55 | `VSFR_SYS_MCU_ID2` | `0xFFFF0002` | 4 | — |
| 56 | `VSFR_SYS_DEVICE_ID` | `0xFFFF0005` | 4 | — |
| 57 | `VSFR_SYS_SIGNATURE` | `0xFFFF0006` | 4 | — |
| 58 | `VSFR_SYS_RX_SIZE` | `0xFFFF0007` | 2 | fmt |
| 59 | `VSFR_SYS_TX_SIZE` | `0xFFFF0008` | 2 | fmt |
| 60 | `VSFR_SYS_BOOT_VERSION` | `0xFFFF0009` | 4 | — |
| 61 | `VSFR_SYS_TARGET_VERSION` | `0xFFFF000A` | 4 | — |
| 62 | `VSFR_SYS_STATUS` | `0xFFFF000B` | 4 | — |
| 63 | `VSFR_SYS_MCU_VREF` | `0xFFFF000C` | 4 | fmt, signed |
| 64 | `VSFR_SYS_MCU_TEMP` | `0xFFFF000D` | 4 | fmt, signed |
| 65 | `RC_VSFR_DPOT_RDAC` | `0x0000C004` | 1 | fmt |
| 66 | `RC_VSFR_DPOT_RDAC_EEPROM` | `0x0000C005` | 1 | fmt |
| 67 | `RC_VSFR_DPOT_TOLER` | `0x0000C006` | 1 | fmt |

Address-space meaning *(inferred from the names and the switch)*: `0x500`-block = device/display/sound/
vibration UI settings, `0x700` = radio TX power, `0x8000`-block = measurement + alarm values,
`0xC000`-block = analog front-end and calibration (bias, comparator, digital-potentiometer codes),
`0xFFFF0000`-block = system/debug mirror (MCU ID/signature, MTU sizes, versions, VREF, die temp).



## 11. Command set (observed on the live unit)

A complete sweep of `0x0000`-`0x0FFF`, repeated with and without a `u32` argument, produced answers only
from these ids. Payloads are the bytes after the 4-byte header.

| cmd | role | request | response (hex) | decoded |
| --- | --- | --- | --- | --- |
| `0x0005` | status | — | `02000000` | `u32 2` |
| `0x0007` | exchange / negotiation | `01 ff 12 ff` | ack | sets the framing tuple |
| `0x000A` | versions | — | `0000040014` + `Feb  6 2023 15:49:14` + `0e0004 0015` + `Jul  7 2025 11:19:22` + `00` | array of `{u16 id, u16 major, u8 len, chars}`; id `0` = bootloader (4.x), id `0x0E` = firmware (4.x) |
| `0x000B` | serial | — | `0c000000` `29002d0001` `503232423931 20` | `u32 len=12`, then the container's 16-byte serial field; printable part `P22B91 `; human-readable id `RC-102-008228` (`RC-102-%06.6X`) |
| `0x0012` | image info | — | `64fc0100 00100000 8a42e75a bb5a0913` | size `130148`, buffer `4096`, `date_time 0x5AE7428A`, crc `0x13095ABB` |
| `0x0013` | block/frame count | — | `13000000` | `u32 19` |
| `0x0101` | image descriptor | — | `8a42e75a` `0a` + `rc-102.bin` + `10` + `RadiaCode RC-102` + `01` `30` | `date_time`, 8-bit-length-prefixed file name, product name, `01`, `0x30` |
| `0x0807` | flash area info | `u32 area` | small record | paired with `0x081C` |
| `0x081C` | read flash area | `u32 area` (0, 1) | `{u32 status, u32 seed, u32 enc_size, enc_data}` | Borland-LCG XOR (§4); yields the `PublicAPI` struct + device parameters |
| `0x0824`-`0x082B` | virtual-SFR / string batch | index, optional `u32` | text / values | serves `VS CONFIGURATION`, the VSFR map (§8) |
| `0x0A04` | set time | `8 x u8`: `day, month, year-2000, 0, sec, min, hour, 0` | ack | the only write-style id found |

There is **no** raw memory/image read command, so bulk bytes come from the vendor `.bin`; the device only
confirms the `size / date_time / crc32` triple and the two XOR-obfuscated config areas.



## 20. Record-stream grammar (VS `0x100`, `DATA_BUF`)

Observed on a live unit; two record sizes alternate, and the record counter byte increments once per
record, so the stride is derived from the anchor positions (45, 21, 45, 21, ...; 14 full frames + a
65-byte tail in a 1010-byte capture, and the same stride in a second 1058-byte capture).

```
 A-record, 45 B   header(13) + 2 x {u32 raw, f32 value, f32 ripple, u32 stamp} + 0
   [0] u8      seq                                   0x22
   [1] u8      groupId                               0x01  GRP_RawData
   [2] u8      channelId                             0x02  CHN_Count
   [3] u8      tag                                   0x2d
   [4] u8[3]   tick, 24-bit LE                        0xE6A994
   [7] u8 0x02, [8] u8 0x00, [9..12] u32 9600
  [13] u32 475, [17] f32 4.947917, [21] f32 7.438e-06, [25] u32 stamp 33 01 00 b0
  [29] u32 468, [33] f32 4.875,    [37] f32 8.399e-06, [41] u32 stamp 3a 01 00 b0

 B-record, 21 B   header(4) + tick(3) + u32 + f32 + u8 + 5 B tail
   [0] u8      seq                                   0x23
   [1] u8      groupId                               0x00  GRP_RealTimeData
   [2] u8      channelId                             0x03  CHN_CountRate
   [3] u8      tag                                   0x40
   [4] u8[3]   tick                                   0xE6A9F3   (+95 from A)
   [7] u32      28403139                               window/uptime word
  [11] f32      0.0595957                              the sample
  [15] u8       0x8f                                   flags
  [16] u8[5]    11 10 27 40 b0                          constant tail
```

The `f32` of the B-record equals the value the `0x8021` VSFR reports, so the two read paths are two views
of the same sample set. The buffer grows with uptime (1004 -> 1058 bytes observed across reads 1 s apart)
and is the only place the per-frame series is exposed.



## 21. Live readout, decoded

Three structures worth naming precisely, all captured in `analysis/capture.json`.

**The 76-byte `DEVICE_INFO` record (VS `0x0F0`, duplicated at `0x203`)**

```
 [0..3]   u32 magic 0x19601217          (same magic opens both RD_FLASH areas)
 [4..]    repeating {u16 count, u16 tag} groups, then IEEE-754 floats
          observed:  {1, 0x50} {1, 0x10} {0} {3, 0x20} 5.158747 9.502541 0.005710896
                     {9, 0x42} 25401.26 46.20266 -0.08978523 16.45725 -0.1268294
                              0.0001654905 0.07347484 0.00061069 1.228892e-07
          5.158747 is VS 0x202's A0, so this record carries the factory calibration set
```

**The window record (VS `0x220`)**: `{u32 counts = 64573, u32 ms = 184233, u32 us = 30612653, u32 0}` -
the accumulation window the current rate is computed over, which is why the 500-ms and 3-min cadences are
visible in one record.

**The spectrum headers (VS `0x200`, `0x205`)**: 22 bytes = `{u32 0, f32 A0, f32 A1, f32 A2, u16 0x4000}`.
`0x206`/`0x207` (10 B each) are the accumulator pairs, zero at idle. `0x208` (104 B) is a fixed descending
power-of-two table used by the scale/rounding code, not measurement data.



## 22. Timings and intervals (the device's own numbers)

| key | value | consequence |
| --- | --- | --- |
| `FrameTimeStep_us` | 10000 | 100 kHz tick grid; the record ticks advance ~90 between A and B |
| `MinFrmPeriod_ms` | 500 | 2 Hz real-time ceiling |
| `DBLag_ms` | 180000 | 3 min for the `GRP_RareData` / DB-backed group |
| `CR_AlarmsNum` / band | 2 / `1e-1`-`50e3` cps | two count-rate alarm levels |
| `DR_AlarmsNum` / band | 2 / `1e-6`-`1e-1` R/h | two dose-rate levels |
| `DS_AlarmsNum` / band | 2 / `1e-6`-`1e3` R | two accumulated-dose levels |
| `VSFR_DISP_OFF_TIME` | 6-entry enum | live index 5 = 5 min |
| `DispBacklight` | 0-9 | live value 9 |


